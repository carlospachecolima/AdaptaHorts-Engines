# AIGIS Agent (protótipo)

Ferramenta de linha de comando que formaliza, em código, o método de
**engenharia e encadeamento de prompts** aplicado ao geoprocessamento
automatizado, já publicado pelo time de Inteligência Climática da Embrapa
Hortaliças:

- Fontenelle, M.R.; Amorim, J.R.A.; Cruz, M.A.S.; Lima, C.E.P. (2025).
  *Prompt Engineering and Prompt Chaining in Artificial Intelligence: Tools
  for Mapping Future Climate Scenarios as Mechanisms of Adaptation and
  Climate Justice and Just Transition Promotion.* Revista de Derecho y
  Cambio Social, v.22, n.83, p.01-17. DOI: 10.54899/dcs.v22i83.3456
- Lima, C.E.P.; Fontenelle, M.R.; Braga, M.B.; Suinaga, F.A.; Guedes,
  I.M.R.; Silva, J. (2025). *Thermal Severity on Brazilian Lettuce Crops
  under Two Global Climate Change Scenarios.* Revista Caderno Pedagógico,
  v.22, n.11, p.01-34. DOI: 10.54033/cadpedv22n11-105

O nome vem da palavra-chave "AIGIS" (Automated GIS) usada no primeiro
artigo para descrever o método.

## Por que isso existe

Assim como o PFBCIA Agent formaliza o método de fenotipagem por IA descrito
nos artigos de alface e batata-doce, este agente formaliza o **motor de
mapeamento** descrito nos dois artigos acima: em vez de operar o QGIS
manualmente mapa a mapa, uma pessoa pesquisadora usa IA generativa (ChatGPT
para gerar os scripts, GitHub Copilot para corrigi-los) para produzir
scripts Python que rodam no ambiente PyQGIS e automatizam, em lote, todo o
fluxo — recorte, separação de bandas, renomeação padronizada, simbologia,
estatísticas, reclassificação de vulnerabilidade, Índice de Severidade
Térmica, layouts dinâmicos e exportação.

O agente cobre os dois artigos com duas frentes complementares:

1. **`chain`** — reproduz a cadeia de 8 prompts para ChatGPT + 2 prompts de
   revisão para o GitHub Copilot do primeiro artigo (Tabela 1), e a cadeia
   de prompts de reclassificação/Índice de Severidade Térmica do segundo
   artigo, parametrizadas pela fonte de dados e cultura escolhidas. Não
   precisa de QGIS nem de chave de API — é só para gerar/adaptar os scripts.
2. **`map`** e **`vulnerability`** — implementam diretamente, em PyQGIS, o
   que esses prompts pedem para gerar: `map` cobre o fluxo genérico de
   mapeamento de variáveis climáticas (artigo 1); `vulnerability` cobre a
   reclassificação por faixas e a combinação Tmed × Tmax no Índice de
   Severidade Térmica (artigo 2, hoje com o perfil da alface já carregado).

Hoje há duas fontes de dados prontas (`worldclim_cmip6`, usada no estudo do
Baixo São Francisco, e `inpe_eta_hadgem2es`, usada no estudo da alface) e um
perfil de vulnerabilidade (`alface`). Adicionar uma nova fonte ou cultura é
criar um novo `ClimateSource` ou `VulnerabilityProfile` em `aigis_agent.py`
— não é preciso mexer no resto do código.

## Uso rápido — modo `chain` (sem QGIS, sem chave de API)

```bash
# Cadeia de prompts para gerar os scripts de mapeamento de Tmax e precipitação
# a partir do WorldClim/CMIP6 (ACCESS-CM2), como no primeiro artigo:
python3 aigis_agent.py chain --source worldclim_cmip6 --variables tmax prec

# A mesma cadeia, incluindo também os prompts de vulnerabilidade/Índice de
# Severidade Térmica para alface, como no segundo artigo:
python3 aigis_agent.py chain --source inpe_eta_hadgem2es --vulnerability-crop alface --out cadeia.json
```

Isso imprime (ou salva em JSON) a cadeia de prompts pronta para colar, em
ordem, numa conversa com o ChatGPT (geração dos scripts) e depois com o
GitHub Copilot (revisão e correção) — exatamente o fluxo descrito nos dois
artigos, testado depois no Google Colab / Visual Studio Code antes de rodar
no QGIS.

## Uso completo — modos `map` e `vulnerability` (requer PyQGIS)

Esses comandos importam `qgis.core` e `processing`, e por isso só rodam
dentro do Console Python do QGIS, via `qgis_process`, ou em um interpretador
com PyQGIS instalado (mesma limitação, em espírito, das chaves de API do
PFBCIA Agent).

```bash
# Recorte + separação de bandas mensais (artigo 1)
python3 aigis_agent.py map --source worldclim_cmip6 \
  --raster tmax_2081-2100_ssp585.tif \
  --mask baixo_sao_francisco.shp \
  --clipped-out tmax_recortado.tif \
  --output-dir ./bandas_mensais

# Reclassificação de vulnerabilidade + Índice de Severidade Térmica (artigo 2)
# (as camadas de Tmed e Tmax já precisam estar carregadas no projeto QGIS)
python3 aigis_agent.py vulnerability --crop alface \
  --tmean-layer temperatura_media_rcp85_2071-2100_verao \
  --tmax-layer temperatura_maxima_rcp85_2071-2100_verao \
  --tmean-out tmed_vulnerabilidade.tif \
  --tmax-out tmax_vulnerabilidade.tif \
  --severity-out indice_severidade_termica.tif \
  --out resultado.json
```

O `resultado.json` do modo `vulnerability` já traz um bloco
`adaptahorts_submission` formatado nos campos do formulário de contribuição
do AdaptaHorts (título, módulo do pipeline, resumo e métricas), igual ao que
o PFBCIA Agent gera para a fenotipagem.

## Limitações conhecidas (protótipo)

- As funções PyQGIS (`clip_raster_by_mask`, `split_bands`,
  `reclassify_raster`, `combine_severity_index`, `compute_statistics`,
  `generate_dynamic_layout`) reproduzem fielmente os scripts de exemplo e a
  metodologia descritos nos dois artigos, mas não foram testadas dentro de
  uma instalação real do QGIS neste ambiente — recomenda-se rodar primeiro
  num caso pequeno antes de aplicar em lote.
- `generate_dynamic_layout` monta um layout básico (mapa, título dinâmico,
  legenda, escala, rodapé); os artigos também mencionam rosa dos ventos e
  grade de coordenadas, que podem ser adicionados com
  `QgsLayoutItemPicture`/`QgsLayoutItemMapGrid` conforme a necessidade do
  projeto.
- O Índice de Severidade Térmica está implementado como soma das duas
  classes de vulnerabilidade (Tmed + Tmax), que é exatamente o que a matriz
  da Figura 2 do segundo artigo reproduz — validado numericamente contra a
  matriz publicada (2 a 9).
- Hoje só há um perfil de vulnerabilidade pronto (alface); os thresholds de
  outras culturas precisam ser adicionados manualmente conforme a literatura
  correspondente.
- Não envia nada ao AdaptaHorts automaticamente — o bloco
  `adaptahorts_submission` é pensado para ser colado manualmente no
  formulário de contribuição.
