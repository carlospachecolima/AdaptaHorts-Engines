#!/usr/bin/env python3
"""
AIGIS Agent — Motor de Mapeamento Automatizado de Cenários Climáticos (protótipo)
============================================================================

Formaliza, como ferramenta reutilizável de linha de comando, o método de
"engenharia e encadeamento de prompts" (prompt engineering / prompt chaining)
aplicado ao geoprocessamento automatizado, já validado e publicado pelo time
de Inteligência Climática da Embrapa Hortaliças:

  - Fontenelle, M.R.; Amorim, J.R.A.; Cruz, M.A.S.; Lima, C.E.P. (2025).
    Prompt Engineering and Prompt Chaining in Artificial Intelligence: Tools
    for Mapping Future Climate Scenarios as Mechanisms of Adaptation and
    Climate Justice and Just Transition Promotion. Revista de Derecho y
    Cambio Social, v.22, n.83, p.01-17. DOI: 10.54899/dcs.v22i83.3456

  - Lima, C.E.P.; Fontenelle, M.R.; Braga, M.B.; Suinaga, F.A.; Guedes,
    I.M.R.; Silva, J. (2025). Thermal Severity on Brazilian Lettuce Crops
    under Two Global Climate Change Scenarios. Revista Caderno Pedagógico,
    v.22, n.11, p.01-34. DOI: 10.54033/cadpedv22n11-105

A ideia central dos dois artigos é a mesma: em vez de operar manualmente o
QGIS mapa a mapa, uma pessoa pesquisadora usa IA generativa (ChatGPT para
gerar os scripts, GitHub Copilot para corrigi-los) para produzir scripts
Python que rodam no ambiente PyQGIS e automatizam, em lote, todo o fluxo de
mapeamento climático: recorte -> separação de bandas -> renomeação padronizada
-> simbologia -> estatísticas -> reclassificação de vulnerabilidade -> índice
de severidade térmica -> layouts dinâmicos -> exportação.

Este agente formaliza os DOIS artigos em uma única ferramenta com duas
frentes complementares:

1) `chain`  — modo "prompt chaining": gera e imprime, sem nenhuma chamada de
   API, a cadeia de prompts especializados (a mesma metodologia do primeiro
   artigo) pronta para colar manualmente no ChatGPT (geração do script) e no
   GitHub Copilot (correção do script), permitindo adaptar o método a novas
   fontes de dados, cenários, variáveis ou regiões sem reescrever a lógica
   do zero.

2) `map` e `vulnerability` — modo "execução real": as funções PyQGIS que os
   scripts gerados pela cadeia de prompts de fato implementam. `map` cobre o
   fluxo genérico de mapeamento de variáveis climáticas (artigo 1: recorte,
   separação de bandas mensais, renomeação, simbologia, estatísticas,
   layouts, exportação). `vulnerability` cobre o fluxo de classificação de
   vulnerabilidade e cálculo do Índice de Severidade Térmica (artigo 2:
   reclassificação por faixas + combinação Tmed x Tmax).

IMPORTANTE: os comandos `map` e `vulnerability` importam `qgis.core` e por
isso só podem ser executados de fato dentro do Console Python do QGIS, via
`qgis_process`, ou em um ambiente com PyQGIS instalado — exatamente como nos
dois artigos, em que os scripts eram gerados por IA e depois testados no
Google Colab / Visual Studio Code antes de rodar no QGIS. O comando `chain`
não tem essa dependência e funciona em qualquer Python 3.10+.

Princípios FAIR: este script é feito para ser versionado e depositado (ex.:
Zenodo), como os demais scripts do grupo (Lima et al., 2025a-c), e para ser
lido e adaptado por outras pessoas — não só executado.
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


# ---------------------------------------------------------------------------
# Perfis de fonte de dados climáticos: cada um encapsula a estrutura dos
# rasters (bandas, cenários, períodos, variáveis) usada pelos artigos.
# ---------------------------------------------------------------------------

@dataclass
class VariableSpec:
    key: str
    display_name: str
    unit: str
    palette_hint: str  # descrição da paleta sugerida (para o prompt de simbologia)


@dataclass
class ClimateSource:
    key: str
    label: str
    model: str
    provider: str
    provider_url: str
    scenarios: list[str]         # códigos de cenário (SSP ou RCP + "historical")
    periods: list[str]           # janelas temporais
    variables: dict[str, VariableSpec]
    band_labels: list[str] | None  # None = já vem em banda única por arquivo
    naming_pattern: str
    notes: str = ""

    def band_count(self) -> int:
        return len(self.band_labels) if self.band_labels else 1


SOURCES: dict[str, ClimateSource] = {
    "worldclim_cmip6": ClimateSource(
        key="worldclim_cmip6",
        label="WorldClim v2.1 / CMIP6 (ACCESS-CM2)",
        model="ACCESS-CM2",
        provider="WorldClim",
        provider_url="https://worldclim.org/data/cmip6/cmip6_clim30s.html",
        scenarios=["historical", "ssp126", "ssp245", "ssp370", "ssp585"],
        periods=["historical", "2021-2040", "2041-2060", "2061-2080", "2081-2100"],
        variables={
            "tmin": VariableSpec("tmin", "Temperatura mínima", "°C", "azul (frio) -> branco (ameno)"),
            "tmax": VariableSpec("tmax", "Temperatura máxima", "°C", "amarelo (ameno) -> vermelho (quente)"),
            "prec": VariableSpec("prec", "Precipitação", "mm", "branco (seco) -> azul escuro (úmido)"),
        },
        band_labels=["jan", "fev", "mar", "abr", "mai", "jun",
                     "jul", "ago", "set", "out", "nov", "dez"],
        naming_pattern="{period}_{scenario}_{variable}({unit})_{band}",
        notes=(
            "Resolução espacial de 1 km². Fluxo validado no estudo de caso do "
            "Baixo São Francisco (SE-AL) (Fontenelle et al., 2025)."
        ),
    ),
    "inpe_eta_hadgem2es": ClimateSource(
        key="inpe_eta_hadgem2es",
        label="Portal de Projeções Climáticas do INPE / ETA-HadGEM2-ES",
        model="ETA-HadGEM2-ES",
        provider="INPE",
        provider_url="http://pclima.inpe.br/analise/",
        scenarios=["historical", "rcp4.5", "rcp8.5"],
        periods=["1961-2005", "present-2040", "2041-2070", "2071-2100"],
        variables={
            "tmean": VariableSpec("tmean", "Temperatura média", "°C", "verde (ameno) -> vermelho (quente)"),
            "tmax": VariableSpec("tmax", "Temperatura máxima", "°C", "amarelo (ameno) -> vermelho escuro (quente)"),
        },
        band_labels=["verao", "outono", "inverno", "primavera"],
        naming_pattern="{period}_{scenario}_{variable}({unit})_{band}",
        notes=(
            "Resolução espacial de 5-20 km. Fluxo validado no estudo de caso da "
            "alfacicultura brasileira (Lima et al., 2025), com reclassificação "
            "de vulnerabilidade e Índice de Severidade Térmica."
        ),
    ),
}


# ---------------------------------------------------------------------------
# Perfis de vulnerabilidade: thresholds de reclassificação + fórmula do
# Índice de Severidade Térmica (IS), tal como definidos no segundo artigo
# para a cultura da alface. Novas culturas podem ser adicionadas criando um
# novo VulnerabilityProfile, sem alterar o resto do código.
# ---------------------------------------------------------------------------

@dataclass
class ClassBreak:
    lo: float | None   # None = sem limite inferior
    hi: float | None   # None = sem limite superior
    label: str
    value: int          # classe numérica (1 = menos vulnerável)

    def to_expression(self, raster_ref: str) -> str:
        conds = []
        if self.lo is not None:
            conds.append(f"{raster_ref} > {self.lo}")
        if self.hi is not None:
            conds.append(f"{raster_ref} <= {self.hi}")
        cond = " AND ".join(conds) if conds else "1=1"
        return f"(({cond}) * {self.value})"


@dataclass
class VulnerabilityProfile:
    key: str
    crop_display_name: str
    tmean_breaks: list[ClassBreak]
    tmax_breaks: list[ClassBreak]
    severity_note: str = (
        "Índice de Severidade Térmica (IS) = classe de vulnerabilidade de "
        "Tmed + classe de vulnerabilidade de Tmax (Lima et al., 2025, Fig. 2)."
    )

    def severity_index(self, tmean_class: int, tmax_class: int) -> int:
        """Combina as duas classes de vulnerabilidade no Índice de Severidade
        Térmica (IS), reproduzindo a matriz da Figura 2 do artigo — que
        equivale a uma soma simples das duas classes."""
        return tmean_class + tmax_class

    def tmean_expression(self, raster_ref: str) -> str:
        return " + ".join(b.to_expression(raster_ref) for b in self.tmean_breaks)

    def tmax_expression(self, raster_ref: str) -> str:
        return " + ".join(b.to_expression(raster_ref) for b in self.tmax_breaks)


VULNERABILITY_PROFILES: dict[str, VulnerabilityProfile] = {
    "alface": VulnerabilityProfile(
        key="alface",
        crop_display_name="alface (Lactuca sativa)",
        # Tabela 2 do artigo: classes de vulnerabilidade para Tmed
        tmean_breaks=[
            ClassBreak(None, 5.00, "muito alta", 5),
            ClassBreak(5.00, 10.00, "alta", 4),
            ClassBreak(10.00, 15.00, "baixa", 2),
            ClassBreak(15.00, 25.00, "muito baixa", 1),
            ClassBreak(25.00, 30.00, "moderada", 3),
            ClassBreak(30.00, 35.00, "alta", 4),
            ClassBreak(35.00, None, "muito alta", 5),
        ],
        # Tabela 3 do artigo: classes de vulnerabilidade para Tmax
        tmax_breaks=[
            ClassBreak(None, 25.00, "baixa", 1),
            ClassBreak(25.00, 30.00, "moderada", 2),
            ClassBreak(30.00, 35.00, "alta", 3),
            ClassBreak(35.00, None, "muito alta", 4),
        ],
    ),
}


# ---------------------------------------------------------------------------
# Utilidades de nomenclatura padronizada (idêntica à convenção validada nos
# dois artigos): Período_Cenário_Variável(Unidade)_MêsOuEstação
# ---------------------------------------------------------------------------

def standard_filename(source: ClimateSource, period: str, scenario: str,
                       variable_key: str, band_label: str, ext: str) -> str:
    var = source.variables[variable_key]
    name = source.naming_pattern.format(
        period=period, scenario=scenario, variable=var.display_name.replace(" ", ""),
        unit=var.unit, band=band_label,
    )
    return f"{name}.{ext}"


# ---------------------------------------------------------------------------
# MODO 1 — "chain": engenharia e encadeamento de prompts (dry-run, sem IA)
# Reproduz a Tabela 1 do artigo 1 (prompts ChatGPT + Copilot) e a
# metodologia de reclassificação do artigo 2, parametrizados pela fonte de
# dados e pelo perfil de vulnerabilidade escolhidos.
# ---------------------------------------------------------------------------

def build_mapping_chain(source: ClimateSource, variable_keys: list[str]) -> list[str]:
    """Cadeia de 8 prompts para ChatGPT + 2 prompts de revisão para o
    GitHub Copilot, exatamente na sequência validada no artigo 1 (Tabela 1),
    parametrizada para a fonte de dados escolhida."""
    variables = [source.variables[k] for k in variable_keys]
    var_list = ", ".join(f"{v.display_name} ({v.unit})" for v in variables)
    n_bands = source.band_count()
    band_word = "mensal" if source.band_labels and n_bands == 12 else "sazonal/por arquivo"

    chain = [
        # 1. Recorte
        (
            "Prepare um script Python para ser executado no ambiente PyQGIS "
            "que recorte uma imagem raster multibanda (GeoTIFF) usando a "
            "camada vetorial de máscara correspondente à área de estudo. "
            "Garanta que o raster de saída preserve a estrutura original de "
            "bandas."
        ),
        # 2. Separação de bandas (só faz sentido quando há múltiplas bandas)
        (
            f"Prepare um script Python para ser executado no ambiente "
            f"PyQGIS que separe um raster multibanda (GeoTIFF) em "
            f"{n_bands} camadas raster de banda única, cada uma "
            f"correspondendo a um recorte temporal {band_word} "
            f"({', '.join(source.band_labels)}). Salve cada raster de "
            "saída usando as três primeiras letras do rótulo "
            "correspondente."
            if source.band_labels
            else (
                "Esta fonte de dados já entrega um arquivo de banda única "
                "por variável/cenário/período/recorte temporal — esta etapa "
                "pode ser pulada."
            )
        ),
        # 3. Renomeação padronizada
        (
            "Renomeie cada camada raster de banda única seguindo a "
            f"estrutura padronizada: {source.naming_pattern}\n\n"
            "Onde:\n"
            "  Período: corresponde ao intervalo de tempo "
            f"({', '.join(source.periods)}).\n"
            "  Cenário: corresponde ao cenário do IPCC "
            f"({', '.join(source.scenarios)}).\n"
            f"  Variável climática: corresponde a {var_list}.\n"
            "  Rótulo do recorte temporal: corresponde à abreviação de três "
            "letras do mês ou estação correspondente."
        ),
        # 4. Simbologia
        (
            f"Escolha uma paleta de cores adequada para cada uma das "
            f"variáveis climáticas analisadas ({var_list}) — sugestão: "
            + "; ".join(f"{v.display_name}: {v.palette_hint}" for v in variables)
            + ". Em seguida, prepare um script Python a ser executado no "
            "ambiente PyQGIS que aplique a paleta de cores escolhida a cada "
            "camada raster de acordo com a variável climática. Garanta que "
            "a simbologia seja consistente entre todos os recortes "
            "temporais, escalas e variáveis."
        ),
        # 5. Salvar projeto QGIS
        (
            "Prepare um script Python a ser executado no ambiente PyQGIS "
            "que salve o espaço de trabalho atual como um arquivo de "
            "projeto QGIS (.qgz). O arquivo deve ter um nome padronizado "
            "no formato variável_período_cenário.qgz."
        ),
        # 6. Estatísticas
        (
            "Prepare um script Python a ser executado no ambiente PyQGIS "
            "que calcule estatísticas básicas para cada camada aberta no "
            "QGIS, incluindo média, mediana, desvio padrão, intervalo de "
            "confiança de 95% e área ocupada por classes de valor "
            "predefinidas. Exporte os resultados como um arquivo .txt, "
            f"seguindo o padrão de nome: {source.naming_pattern}.txt"
        ),
        # 7. Layouts dinâmicos
        (
            "Prepare um script Python a ser usado no ambiente PyQGIS que "
            "crie layouts dinâmicos com elementos cartográficos completos "
            "para todas as imagens raster abertas no QGIS, atualizando "
            "automaticamente o cenário do IPCC, o período, a variável "
            "climática e o rótulo do recorte temporal de acordo com o nome "
            "de cada camada raster aberta. Todos os layouts devem conter "
            "rosa dos ventos, barra de escala, grades e coordenadas "
            f"geográficas, legenda, e o modelo climático ({source.model}) e "
            f"a base de dados utilizada ({source.provider}) como rodapé."
        ),
        # 8. Exportação
        (
            "Prepare um script Python a ser executado no ambiente PyQGIS "
            "que exporte todos os layouts como imagem PNG em resolução de "
            "qualidade de publicação. Os arquivos exportados devem seguir "
            f"a nomenclatura padronizada: {source.naming_pattern}.png"
        ),
        # 9. Copilot — revisão de erros
        (
            "[GitHub Copilot] Analise o script anexo e identifique "
            "quaisquer erros ou inconsistências antes de rodá-lo no "
            "ambiente PyQGIS."
        ),
        # 10. Copilot — correção
        (
            "[GitHub Copilot] Corrija os erros identificados e melhore a "
            "estrutura do script para que ele rode de forma modular e "
            "robusta no ambiente PyQGIS. Faça testes preliminares em um "
            "ambiente colaborativo (ex.: Google Colab) e em um editor de "
            "código (ex.: Visual Studio Code) antes da execução final."
        ),
    ]
    return chain


def _describe_break_range(b: ClassBreak) -> str:
    if b.lo is None and b.hi is not None:
        return f"valores <= {b.hi}"
    if b.lo is not None and b.hi is not None:
        return f"valores > {b.lo} e <= {b.hi}"
    if b.lo is not None and b.hi is None:
        return f"valores > {b.lo}"
    return "quaisquer valores"


def build_vulnerability_chain(profile: VulnerabilityProfile) -> list[str]:
    """Cadeia de prompts para o fluxo de reclassificação de vulnerabilidade
    e cálculo do Índice de Severidade Térmica (artigo 2)."""
    tmean_rules = "; ".join(
        f"{b.label} (classe {b.value}) para {_describe_break_range(b)}"
        for b in profile.tmean_breaks
    )
    tmax_rules = "; ".join(
        f"{b.label} (classe {b.value}) para {_describe_break_range(b)}"
        for b in profile.tmax_breaks
    )
    return [
        (
            "Prepare um script Python para ser executado no ambiente "
            "PyQGIS que aplique álgebra de mapas (raster calculator) para "
            "reclassificar uma camada raster de temperatura média (Tmed) "
            f"em classes de vulnerabilidade para {profile.crop_display_name}, "
            f"segundo as faixas: {tmean_rules}. Salve o raster reclassificado "
            "com sufixo '_vulnerabilidade' e carregue-o automaticamente no "
            "QGIS."
        ),
        (
            "Repita o processo anterior para uma camada raster de "
            "temperatura máxima (Tmax), reclassificando-a segundo as "
            f"faixas: {tmax_rules}."
        ),
        (
            "Prepare um script Python que combine as duas camadas de "
            "vulnerabilidade (Tmed e Tmax) pixel a pixel, somando suas "
            "classes numéricas, para produzir o Índice de Severidade "
            "Térmica (IS). Aplique uma paleta de cores sequencial (azul "
            "para os valores mais baixos, vermelho para os mais altos) e "
            "gere estatísticas de área por classe de IS."
        ),
        (
            "Prepare um script Python que gere layouts dinâmicos e exporte "
            "em PNG tanto os mapas de vulnerabilidade (Tmed e Tmax) quanto "
            "o mapa do Índice de Severidade Térmica, com título, legenda, "
            "escala, grade de coordenadas e metadados do cenário/período "
            "no rodapé."
        ),
        (
            "[GitHub Copilot] Revise os quatro scripts acima quanto a "
            "erros de sintaxe, consistência de nomes de camada e "
            "compatibilidade com a API do PyQGIS 3.4x, e proponha versões "
            "corrigidas e modularizadas."
        ),
    ]


# ---------------------------------------------------------------------------
# MODO 2 — execução real em PyQGIS. Cada função é uma implementação direta
# do que os prompts acima pedem para gerar; import tardio de `qgis.core`
# para que o restante do agente (modo `chain`) funcione sem QGIS instalado.
# ---------------------------------------------------------------------------

class PyQgisUnavailableError(RuntimeError):
    pass


def _require_qgis():
    try:
        import qgis.core  # noqa: F401
        import processing  # noqa: F401
    except ImportError as e:
        raise PyQgisUnavailableError(
            "Este comando precisa rodar dentro do ambiente PyQGIS (Console "
            "Python do QGIS, `qgis_process`, ou um interpretador com PyQGIS "
            "instalado). Use o comando `chain` para gerar a cadeia de "
            "prompts e adaptar/gerar o script fora do QGIS."
        ) from e


def clip_raster_by_mask(raster_path: str, mask_path: str, output_path: str) -> None:
    """Prompt 1 do artigo 1: recorte de um raster multibanda por uma
    camada vetorial de máscara, preservando a estrutura de bandas."""
    _require_qgis()
    from qgis.core import QgsProcessingFeedback
    import processing

    params = {
        "INPUT": raster_path,
        "MASK": mask_path,
        "NODATA": 10000000,
        "DATA_TYPE": 0,
        "ALPHA_BAND": False,
        "CROP_TO_CUTLINE": True,
        "KEEP_RESOLUTION": True,
        "OUTPUT": output_path,
    }
    feedback = QgsProcessingFeedback()
    processing.run("gdal:cliprasterbymasklayer", params, feedback=feedback)


def split_bands(raster_path: str, band_labels: list[str], output_dir: str) -> list[str]:
    """Prompt 2 do artigo 1: separa um raster multibanda em N rasters de
    banda única, um por rótulo temporal (mês ou estação)."""
    _require_qgis()
    import os
    import processing

    outputs = []
    for i, label in enumerate(band_labels, start=1):
        out_path = os.path.join(output_dir, f"{label[:3]}.tif")
        processing.run(
            "gdal:extractband",
            {"INPUT": raster_path, "BAND": i, "OUTPUT": out_path},
        )
        outputs.append(out_path)
    return outputs


def build_reclass_expression(raster_ref: str, breaks: list[ClassBreak]) -> str:
    """Monta a expressão da calculadora raster para reclassificar por
    faixas de valor, no mesmo padrão do script de exemplo do artigo 2
    (Tabela 1): soma de indicadores booleanos multiplicados pela classe."""
    return " + ".join(b.to_expression(raster_ref) for b in breaks)


def reclassify_raster(raster_layer_ref: str, breaks: list[ClassBreak],
                       output_path: str):
    """Reclassifica um raster já carregado no QGIS segundo `breaks`,
    reproduzindo o script de exemplo da Tabela 1 do artigo 2."""
    _require_qgis()
    from qgis.core import QgsProject, QgsProcessingFeedback, QgsRasterLayer
    import processing

    project = QgsProject.instance()
    layer = project.mapLayersByName(raster_layer_ref)
    if not layer:
        raise ValueError(f"Camada raster '{raster_layer_ref}' não encontrada no projeto QGIS.")
    layer = layer[0]

    raster_calc_name = f"'{layer.name()}@1'"
    expression = build_reclass_expression(raster_calc_name, breaks)

    params = {
        "EXPRESSION": expression,
        "LAYERS": layer,
        "CELLSIZE": 0,
        "EXTENT": layer.extent(),
        "CRS": layer.crs(),
        "OUTPUT": output_path,
    }
    feedback = QgsProcessingFeedback()
    result = processing.run("qgis:rastercalculator", params, feedback=feedback)
    if result and "OUTPUT" in result:
        out_layer = QgsRasterLayer(output_path, f"{layer.name()}_vulnerabilidade")
        project.addMapLayer(out_layer)
    return result


def combine_severity_index(tmean_vuln_ref: str, tmax_vuln_ref: str,
                            profile: VulnerabilityProfile, output_path: str):
    """Soma pixel a pixel as duas camadas de vulnerabilidade já
    reclassificadas (Tmed e Tmax) para produzir o Índice de Severidade
    Térmica (IS), reproduzindo a matriz da Figura 2 do artigo 2."""
    _require_qgis()
    from qgis.core import QgsProject, QgsProcessingFeedback, QgsRasterLayer
    import processing

    project = QgsProject.instance()
    tmean_layer = project.mapLayersByName(tmean_vuln_ref)
    tmax_layer = project.mapLayersByName(tmax_vuln_ref)
    if not tmean_layer or not tmax_layer:
        raise ValueError("Camadas de vulnerabilidade de Tmed e/ou Tmax não encontradas.")
    tmean_layer, tmax_layer = tmean_layer[0], tmax_layer[0]

    expression = f"'{tmean_layer.name()}@1' + '{tmax_layer.name()}@1'"
    params = {
        "EXPRESSION": expression,
        "LAYERS": [tmean_layer, tmax_layer],
        "CELLSIZE": 0,
        "EXTENT": tmean_layer.extent(),
        "CRS": tmean_layer.crs(),
        "OUTPUT": output_path,
    }
    feedback = QgsProcessingFeedback()
    result = processing.run("qgis:rastercalculator", params, feedback=feedback)
    if result and "OUTPUT" in result:
        out_layer = QgsRasterLayer(output_path, "indice_severidade_termica")
        project.addMapLayer(out_layer)
    return result


def compute_statistics(raster_layer_ref: str) -> dict:
    """Prompt 6 do artigo 1: estatísticas básicas de uma camada raster
    (média, mediana, desvio padrão, IC 95%, área por classe)."""
    _require_qgis()
    from qgis.core import QgsProject
    import numpy as np

    project = QgsProject.instance()
    layers = project.mapLayersByName(raster_layer_ref)
    if not layers:
        raise ValueError(f"Camada '{raster_layer_ref}' não encontrada.")
    layer = layers[0]
    provider = layer.dataProvider()
    stats = provider.bandStatistics(1)

    pixel_area = abs(layer.rasterUnitsPerPixelX() * layer.rasterUnitsPerPixelY())
    n = max(stats.elementCount, 1)
    std_err = stats.stdDev / (n ** 0.5) if n else 0.0
    ci95 = 1.96 * std_err

    return {
        "mean": stats.mean,
        "std_dev": stats.stdDev,
        "min": stats.minimumValue,
        "max": stats.maximumValue,
        "ci95_low": stats.mean - ci95,
        "ci95_high": stats.mean + ci95,
        "pixel_count": stats.elementCount,
        "area_total": stats.elementCount * pixel_area,
    }


def save_qgis_project(output_path: str) -> None:
    """Prompt 5 do artigo 1: salva o workspace atual como projeto QGIS."""
    _require_qgis()
    from qgis.core import QgsProject
    QgsProject.instance().write(output_path)


def generate_dynamic_layout(raster_layer_ref: str, title: str, footer: str,
                             output_png: str) -> None:
    """Prompts 7 e 8 do artigo 1: monta um layout cartográfico completo
    (mapa, título dinâmico, legenda, escala, rosa dos ventos, grade,
    rodapé com metadados) e exporta em PNG."""
    _require_qgis()
    from qgis.core import (
        QgsProject, QgsPrintLayout, QgsLayoutItemMap, QgsLayoutItemLegend,
        QgsLayoutItemScaleBar, QgsLayoutItemLabel, QgsLayoutSize,
        QgsLayoutPoint, QgsUnitTypes, QgsLayoutExporter,
    )
    from PyQt5.QtGui import QFont

    project = QgsProject.instance()
    layers = project.mapLayersByName(raster_layer_ref)
    if not layers:
        raise ValueError(f"Camada '{raster_layer_ref}' não encontrada.")
    layer = layers[0]

    manager = project.layoutManager()
    layout_name = f"layout_{raster_layer_ref}"
    existing = manager.layoutByName(layout_name)
    if existing:
        manager.removeLayout(existing)

    layout = QgsPrintLayout(project)
    layout.initializeDefaults()
    layout.setName(layout_name)
    manager.addLayout(layout)

    # Mapa
    map_item = QgsLayoutItemMap(layout)
    map_item.attemptSetSceneRect(
        __import__("PyQt5.QtCore", fromlist=["QRectF"]).QRectF(10, 20, 200, 150)
    )
    map_item.setExtent(layer.extent())
    map_item.setLayers([layer])
    map_item.setFrameEnabled(True)
    map_item.attemptMove(QgsLayoutPoint(10, 20, QgsUnitTypes.LayoutMillimeters))
    layout.addLayoutItem(map_item)

    # Título dinâmico
    title_item = QgsLayoutItemLabel(layout)
    title_item.setText(title)
    title_item.setFont(QFont("Arial", 14))
    title_item.adjustSizeToText()
    title_item.attemptMove(QgsLayoutPoint(10, 5, QgsUnitTypes.LayoutMillimeters))
    layout.addLayoutItem(title_item)

    # Legenda
    legend = QgsLayoutItemLegend(layout)
    legend.setLinkedMap(map_item)
    legend.attemptMove(QgsLayoutPoint(215, 20, QgsUnitTypes.LayoutMillimeters))
    layout.addLayoutItem(legend)

    # Barra de escala
    scalebar = QgsLayoutItemScaleBar(layout)
    scalebar.setLinkedMap(map_item)
    scalebar.applyDefaultSize()
    scalebar.attemptMove(QgsLayoutPoint(10, 175, QgsUnitTypes.LayoutMillimeters))
    layout.addLayoutItem(scalebar)

    # Rodapé com metadados (modelo climático + base de dados)
    footer_item = QgsLayoutItemLabel(layout)
    footer_item.setText(footer)
    footer_item.setFont(QFont("Arial", 7))
    footer_item.adjustSizeToText()
    footer_item.attemptMove(QgsLayoutPoint(10, 190, QgsUnitTypes.LayoutMillimeters))
    layout.addLayoutItem(footer_item)

    exporter = QgsLayoutExporter(layout)
    exporter.exportToImage(output_png, QgsLayoutExporter.ImageExportSettings())


# ---------------------------------------------------------------------------
# Bloco de submissão formatado para o AdaptaHorts (módulo "Tecnologias de
# Informação e Comunicação" do pipeline).
# ---------------------------------------------------------------------------

def build_adaptahorts_submission(source: ClimateSource | None,
                                  profile: VulnerabilityProfile | None,
                                  n_products: dict[str, int]) -> dict:
    if profile is not None:
        title = f"Mapeamento de vulnerabilidade térmica — {profile.crop_display_name}"
        module = "tic"
        summary = (
            f"Mapas de vulnerabilidade climática e Índice de Severidade "
            f"Térmica para {profile.crop_display_name}, gerados via "
            "geoprocessamento automatizado com IA (engenharia e "
            "encadeamento de prompts, PyQGIS)."
        )
    else:
        assert source is not None
        title = f"Mapeamento de cenários climáticos futuros — {source.label}"
        module = "tic"
        summary = (
            f"Mapas de variáveis climáticas ({', '.join(v.display_name for v in source.variables.values())}) "
            f"para os cenários {', '.join(source.scenarios)}, gerados via "
            "geoprocessamento automatizado com IA (engenharia e "
            "encadeamento de prompts, PyQGIS)."
        )

    metrics = [{"k": k.replace("_", " "), "v": str(v)} for k, v in n_products.items()]
    metrics.append({"k": "ferramentas de IA utilizadas", "v": "ChatGPT + GitHub Copilot"})

    return {
        "title": title,
        "authors": "(preencher — pesquisador(a) responsável pelo mapeamento)",
        "venue": "AdaptaHorts — contribuição via AIGIS Agent",
        "module": module,
        "doi": "",
        "summary": summary,
        "metrics": metrics,
    }


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def cmd_chain(args: argparse.Namespace) -> int:
    source = SOURCES[args.source]
    variable_keys = args.variables or list(source.variables)
    for k in variable_keys:
        if k not in source.variables:
            print(f"Erro: variável '{k}' não existe na fonte '{source.key}'. "
                  f"Opções: {list(source.variables)}", file=sys.stderr)
            return 1

    mapping_chain = build_mapping_chain(source, variable_keys)
    payload: dict[str, Any] = {
        "source": source.key,
        "variables": variable_keys,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "note": (
            "Modo chain: nenhuma chamada de IA foi feita. Cole estes prompts, "
            "em ordem, numa conversa com o ChatGPT para gerar os scripts "
            "Python/PyQGIS, e depois use o(s) prompt(s) finais com o GitHub "
            "Copilot (ou colando o script gerado) para revisão e correção."
        ),
        "mapping_prompt_chain": mapping_chain,
    }
    if args.vulnerability_crop:
        if args.vulnerability_crop not in VULNERABILITY_PROFILES:
            print(f"Erro: perfil de vulnerabilidade '{args.vulnerability_crop}' "
                  f"não existe. Opções: {list(VULNERABILITY_PROFILES)}", file=sys.stderr)
            return 1
        profile = VULNERABILITY_PROFILES[args.vulnerability_crop]
        payload["vulnerability_crop"] = profile.key
        payload["vulnerability_prompt_chain"] = build_vulnerability_chain(profile)

    _emit(payload, args.out)
    return 0


def cmd_map(args: argparse.Namespace) -> int:
    source = SOURCES[args.source]
    try:
        clip_raster_by_mask(args.raster, args.mask, args.clipped_out)
        current = args.clipped_out
        band_paths = []
        if source.band_labels:
            band_paths = split_bands(current, source.band_labels, args.output_dir)
        else:
            band_paths = [current]

        products = []
        for i, path in enumerate(band_paths):
            label = source.band_labels[i] if source.band_labels else "unico"
            products.append({"band": label, "path": path})

        payload = {
            "source": source.key,
            "clipped_raster": current,
            "bands": products,
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "note": (
                "Recorte e separação de bandas concluídos. Para simbologia, "
                "estatísticas e layouts, chame as funções correspondentes "
                "(apply nas camadas já carregadas no QGIS) a partir do "
                "Console Python do QGIS, ou use este script como módulo."
            ),
        }
        _emit(payload, args.out)
        return 0
    except PyQgisUnavailableError as e:
        print(f"Erro: {e}", file=sys.stderr)
        return 1


def cmd_vulnerability(args: argparse.Namespace) -> int:
    if args.crop not in VULNERABILITY_PROFILES:
        print(f"Erro: perfil '{args.crop}' não existe. "
              f"Opções: {list(VULNERABILITY_PROFILES)}", file=sys.stderr)
        return 1
    profile = VULNERABILITY_PROFILES[args.crop]
    try:
        reclassify_raster(args.tmean_layer, profile.tmean_breaks, args.tmean_out)
        reclassify_raster(args.tmax_layer, profile.tmax_breaks, args.tmax_out)
        result = combine_severity_index(
            f"{args.tmean_layer}_vulnerabilidade",
            f"{args.tmax_layer}_vulnerabilidade",
            profile, args.severity_out,
        )
        payload = {
            "crop": profile.key,
            "tmean_vulnerability": args.tmean_out,
            "tmax_vulnerability": args.tmax_out,
            "severity_index": args.severity_out,
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }
        submission = build_adaptahorts_submission(
            None, profile, {"camadas geradas": 3}
        )
        payload["adaptahorts_submission"] = submission
        _emit(payload, args.out)
        return 0
    except PyQgisUnavailableError as e:
        print(f"Erro: {e}", file=sys.stderr)
        return 1


def _emit(payload: dict, out: Path | None) -> None:
    text = json.dumps(payload, ensure_ascii=False, indent=2, default=str)
    if out:
        out.write_text(text, encoding="utf-8")
        print(f"Resultado salvo em {out}", file=sys.stderr)
    else:
        print(text)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description=(
            "AIGIS Agent — formaliza o método de mapeamento de cenários "
            "climáticos e de vulnerabilidade térmica por engenharia e "
            "encadeamento de prompts (Fontenelle et al., 2025; Lima et "
            "al., 2025) em uma ferramenta de linha de comando."
        )
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_chain = sub.add_parser(
        "chain", help="Gera a cadeia de prompts (dry-run, sem chamar nenhuma IA)."
    )
    p_chain.add_argument("--source", choices=sorted(SOURCES), required=True,
                          help="Fonte de dados climáticos.")
    p_chain.add_argument("--variables", nargs="*", default=None,
                          help="Variáveis a incluir (padrão: todas da fonte).")
    p_chain.add_argument("--vulnerability-crop", choices=sorted(VULNERABILITY_PROFILES),
                          default=None,
                          help="Inclui também a cadeia de prompts de vulnerabilidade/IS para esta cultura.")
    p_chain.add_argument("--out", type=Path, default=None)
    p_chain.set_defaults(func=cmd_chain)

    p_map = sub.add_parser(
        "map", help="Executa o recorte + separação de bandas em PyQGIS (requer QGIS)."
    )
    p_map.add_argument("--source", choices=sorted(SOURCES), required=True)
    p_map.add_argument("--raster", required=True, help="Caminho do raster multibanda de entrada.")
    p_map.add_argument("--mask", required=True, help="Caminho do shapefile de máscara (área de estudo).")
    p_map.add_argument("--clipped-out", required=True, help="Caminho do raster recortado de saída.")
    p_map.add_argument("--output-dir", required=True, help="Diretório para as bandas separadas.")
    p_map.add_argument("--out", type=Path, default=None)
    p_map.set_defaults(func=cmd_map)

    p_vuln = sub.add_parser(
        "vulnerability",
        help="Reclassifica Tmed/Tmax e calcula o Índice de Severidade Térmica (requer QGIS).",
    )
    p_vuln.add_argument("--crop", choices=sorted(VULNERABILITY_PROFILES), required=True)
    p_vuln.add_argument("--tmean-layer", required=True, help="Nome da camada de Tmed já carregada no QGIS.")
    p_vuln.add_argument("--tmax-layer", required=True, help="Nome da camada de Tmax já carregada no QGIS.")
    p_vuln.add_argument("--tmean-out", required=True)
    p_vuln.add_argument("--tmax-out", required=True)
    p_vuln.add_argument("--severity-out", required=True)
    p_vuln.add_argument("--out", type=Path, default=None)
    p_vuln.set_defaults(func=cmd_vulnerability)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
