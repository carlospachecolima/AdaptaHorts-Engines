"""Monta o complemento (copia o motor para dentro) e gera o ZIP instalável determinístico com hashes."""
import hashlib, pathlib, shutil, sys, zipfile

aqui = pathlib.Path(__file__).parent
motor = aqui.parent / "motor_adaptahorts" / "motor_mapeamento"
build = aqui / "build" / "adaptahorts"
if build.exists():
    shutil.rmtree(build)
shutil.copytree(aqui / "adaptahorts", build, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
shutil.copytree(motor, build / "motor_mapeamento", ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
versao = next(l.split("=", 1)[1].strip() for l in (build / "metadata.txt").read_text().splitlines() if l.startswith("version="))
arquivos = sorted(p for p in build.rglob("*") if p.is_file() and p.name != "SHA256SUMS.txt")
h = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
(build / "SHA256SUMS.txt").write_text("".join(f"{h(p)}  {p.relative_to(build).as_posix()}\n" for p in arquivos))
destino = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else aqui / "dist"
destino.mkdir(parents=True, exist_ok=True)
z = destino / f"adaptahorts_qgis_v{versao}.zip"
with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
    for p in sorted(arquivos + [build / "SHA256SUMS.txt"]):
        info = zipfile.ZipInfo(f"adaptahorts/{p.relative_to(build).as_posix()}", date_time=(2026, 10, 1, 0, 0, 0))
        info.external_attr = 0o644 << 16
        info.compress_type = zipfile.ZIP_DEFLATED
        zf.writestr(info, p.read_bytes(), compresslevel=9)
(destino / f"{z.name}.sha256").write_text(f"{h(z)}  {z.name}\n")
print(z, h(z), len(arquivos) + 1)
