import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyBboxPatch

W, H = 7.6, 5.35
fig = plt.figure(figsize=(W, H), dpi=200)
ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, W); ax.set_ylim(0, H); ax.axis("off")
INK, MUTED, GRID = "#1f2328", "#57606a", "#d0d7de"
REQ, HEAD, OK, BAD = "#dbeafe", "#f6f8fa", "#1a7f37", "#cf222e"

ax.text(0.15, H - 0.25, "Como a planilha deve ficar: uma linha para cada valor mensal", fontsize=11.5,
        fontweight="bold", color=INK, va="center")
ax.text(0.15, H - 0.52, "Exemplo para Brasília (valores ilustrativos). Colunas em azul são obrigatórias.",
        fontsize=8, color=MUTED, va="center")

cols = ["estacao_id", "nome", "local_id", "lon", "lat", "variavel", "tipo_dado", "ano", "mes", "valor", "unidade",
        "periodo_normal"]
req = {"estacao_id", "lon", "lat", "variavel", "tipo_dado", "mes", "valor", "unidade"}
wid = [0.68, 0.72, 0.52, 0.52, 0.52, 0.56, 0.62, 0.42, 0.34, 0.46, 0.54, 0.86]
rows = [["83377", "Brasília", "BSB", "-47,93", "-15,79", "tmax", "serie", "1985", "1", "27,1", "°C", ""],
        ["83377", "Brasília", "BSB", "-47,93", "-15,79", "tmax", "serie", "1985", "2", "27,6", "°C", ""],
        ["83377", "Brasília", "BSB", "-47,93", "-15,79", "prec", "serie", "1985", "1", "245,3", "mm", ""],
        ["⋮", "", "", "", "", "", "", "", "", "", "", ""],
        ["A001", "Brasília A", "BSB", "-47,93", "-15,79", "tmin", "serie", "2001", "7", "12,8", "°C", ""],
        ["83xxx", "Estação B", "", "-48,1", "-15,6", "tmin", "normal", "", "1", "17,6", "°C", "1961-1990"],
        ["83xxx", "Estação B", "", "-48,1", "-15,6", "tmin", "normal", "", "1", "17,4", "°C", "1981-2010"]]
x0, y0, rh = 0.15, H - 0.78, 0.27
xs = [x0]
for w in wid:
    xs.append(xs[-1] + w)
for j, c in enumerate(cols):
    ax.add_patch(Rectangle((xs[j], y0 - rh), wid[j], rh, fc=REQ if c in req else HEAD, ec=GRID, lw=0.6))
    ax.text(xs[j] + wid[j] / 2, y0 - rh / 2, c, ha="center", va="center", fontsize=6.6, fontweight="bold",
            color=INK, family="DejaVu Sans Mono")
for i, r in enumerate(rows):
    yy = y0 - rh * (i + 2)
    for j, v in enumerate(r):
        ax.add_patch(Rectangle((xs[j], yy), wid[j], rh, fc="white", ec=GRID, lw=0.6))
        ax.text(xs[j] + wid[j] / 2, yy + rh / 2, v, ha="center", va="center", fontsize=7, color=INK)
yb = y0 - rh * (len(rows) + 1)

# notas
notas = [
    ("variavel", "tmin, tmax ou prec (corrigidas); tmed e etp também, para tendências"),
    ("tipo_dado", "serie (um valor por ano e mês) ou normal (normal climatológica)"),
    ("ano", "obrigatório para serie; vazio para normal"),
    ("periodo_normal", "normais: uma linha por período (1961-1990, 1981-2010, 1991-2020) → taxa por década"),
    ("valor", "temperatura = média mensal em °C; prec e etp = total mensal em mm; vírgula ou ponto"),
    ("local_id", "opcional: estações no mesmo local (ex.: convencional + automática) contam como uma"),
]
y = yb - 0.24
for k, t in notas:
    ax.text(0.15, y, k, fontsize=7, fontweight="bold", color=INK, family="DejaVu Sans Mono", va="center")
    ax.text(1.25, y, t, fontsize=7.2, color=INK, va="center")
    y -= 0.2

# caixas aceito / não aceito
yb2 = 0.12
bw, bh = 3.55, 0.92
ax.add_patch(FancyBboxPatch((0.15, yb2), bw, bh, boxstyle="round,pad=0,rounding_size=0.06", fc="#dafbe1", ec=OK, lw=0.9))
ax.text(0.28, yb2 + bh - 0.17, "✓  Também vale", fontsize=8.3, fontweight="bold", color=OK, va="center")
for k, t in enumerate(["Colunas em qualquer ordem; colunas extras são ignoradas",
                       "Opcionais: nome, local_id, fonte, dias_faltantes, regiao",
                       "Arquivo .xlsx, .ods ou .csv; várias estações na mesma planilha"]):
    ax.text(0.28, yb2 + bh - 0.4 - 0.19 * k, "•  " + t, fontsize=7, color=INK, va="center")
xb = 0.15 + bw + 0.2
ax.add_patch(FancyBboxPatch((xb, yb2), bw, bh, boxstyle="round,pad=0,rounding_size=0.06", fc="#ffebe9", ec=BAD, lw=0.9))
ax.text(xb + 0.13, yb2 + bh - 0.17, "✗  Não aceito: meses em colunas", fontsize=8.3, fontweight="bold", color=BAD, va="center")
mini = [["estação", "ano", "Jan", "Fev", "…"], ["83377", "1985", "27,1", "27,6", "…"]]
mw = [0.6, 0.42, 0.42, 0.42, 0.28]
mx = [xb + 0.13]
for w in mw:
    mx.append(mx[-1] + w)
for i, r in enumerate(mini):
    yy = yb2 + bh - 0.52 - 0.22 * i
    for j, v in enumerate(r):
        ax.add_patch(Rectangle((mx[j], yy), mw[j], 0.22, fc=HEAD if i == 0 else "white", ec="#e6b8b5", lw=0.6))
        ax.text(mx[j] + mw[j] / 2, yy + 0.11, v, ha="center", va="center", fontsize=6.8, color=INK,
                fontweight="bold" if i == 0 else "normal")
ax.text(mx[-1] + 0.1, yb2 + bh - 0.52, "converta para\numa linha por mês", fontsize=6.6, color=BAD, va="center")
fig.savefig("formato_planilha.png", dpi=200, facecolor="white")
