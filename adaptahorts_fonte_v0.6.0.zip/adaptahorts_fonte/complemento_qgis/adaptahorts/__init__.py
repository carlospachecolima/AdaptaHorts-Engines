"""Complemento QGIS AdaptaHorts — mapeamento climático com correção regional (método Delta)."""


def classFactory(iface):  # noqa: N802 (nome exigido pelo QGIS)
    from .plugin import AdaptaHortsPlugin
    return AdaptaHortsPlugin(iface)
