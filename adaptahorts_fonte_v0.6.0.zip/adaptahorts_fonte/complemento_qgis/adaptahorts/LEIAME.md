# Complemento QGIS AdaptaHorts – Mapeamento Climático (v0.6.0)

## Instalação

1. No QGIS (3.30 ou mais recente): **Complementos › Gerenciar e instalar complementos › Instalar a partir de ZIP**.
2. Escolha `adaptahorts_qgis_v0.6.0.zip` e clique em **Instalar complemento**.
3. Se o QGIS avisar sobre complemento experimental, marque **Mostrar também complementos experimentais** em *Configurações*.

Não é preciso instalar nenhuma biblioteca: o complemento usa apenas o GDAL e o numpy que vêm com o QGIS.

## Uso

Os algoritmos ficam na **Caixa de Ferramentas de Processamento › AdaptaHorts** e também no menu **Complementos › AdaptaHorts**:

0. **Gerar planilha-modelo**: cria a planilha (.xlsx ou .csv) para os dados do INMET. O formulário mostra uma figura de como a planilha deve ficar. Em **Salvar planilha-modelo como…**, clique em **…** → **Salvar em arquivo…** e escolha a pasta.

   **Formato:** uma linha para cada valor mensal (estação × variável × ano × mês), nunca meses em colunas. Colunas obrigatórias: `estacao_id`, `lon`, `lat`, `variavel` (tmin, tmax, prec), `tipo_dado` (serie, normal), `mes`, `valor`, `unidade` (°C, mm); `ano` para séries e `periodo_normal` para normais. Colunas em qualquer ordem; colunas extras são ignoradas.

   **Normais:** uma linha por período disponível (1961-1990, 1981-2010, 1991-2020). Para cada período, o motor faz a média de todas as estações da localidade; a taxa por década é a reta dessas médias, e a referência da correção é o valor em 1985, centro de 1970–2000 (Lima et al., 2026, seção 2.7). `tmed` e `etp` também são aceitas (tendências e avaliação). A coluna opcional `regiao` (ex.: interior, litoral) faz a média por sub-região.
1. **Validar entradas**: confere tudo e mostra os avisos sem processar.
2. **Processar**: correção Delta, avaliação ETA, estatísticas, rasters, mapas, relatório e manifesto.
3. **Processar arquivo de trabalho (JSON)**: repete uma análise ou usa opções avançadas.

No grupo **AdaptaHorts – Risco**:

- **R1. Gerar questionário PAERC**: camada GeoPackage com formulário em abas (para coleta no QGIS ou no QField) e/ou planilha Excel com as mesmas perguntas.
- **R2. PAERC (IPSV-AF) dos questionários**: PAERC por propriedade e por microrregião, com IC 95% por bootstrap. Pesos das dimensões editáveis; padrão = médias do bootstrap, 0,473·CE + 0,388·CT + 0,139·CI.
- **R3. ISOC – ondas de calor**, **R4. ISDH – déficit hídrico**, **R5. ISCC – concentração de chuvas** e **R6. ISSA – salinização**: um algoritmo para cada índice, com os pesos de Intensidade, Duração e Concentração no formulário (padrão = médias do bootstrap: ISOC 0,460/0,352/0,188; ISDH 0,446/0,354/0,200; ISCC 0,372/0,231/0,397; ISSA 0,432/0,406/0,162) e os limiares nos parâmetros avançados. Cada um grava o índice, os componentes I, D e C, a variação entre períodos, mapas e relatório próprio.
- **R7. Ameaça agregada**: os quatro índices juntos e a ameaça (média ponderada, peso de cada índice no formulário).
- **R8. Risco climático**: ISOC, ISDH, ISCC e ISSA (suscetibilidade climática à salinização pelo balanço de sais da FAO-29; com raster de CE do solo medida, vira estresse salino), ameaça, exposição (padrão 0,90 = 1 − 10% de adoção de sistemas conservacionistas), PAERC e Risco = Ameaça × Exposição × (1 − PAERC). A entrada climática é a pasta de resultados do algoritmo 2.

Como são algoritmos de Processamento, também funcionam no Model Builder, em lote e pelo console (`processing.run("adaptahorts:processar", {...})`).

Ao final, os rasters corrigidos são carregados no projeto com a simbologia do AdaptaHorts. Os layouts ficam no projeto `.qgz` gerado em `projeto_qgis/` dentro da pasta de resultados.

## Responsabilidade

O usuário é responsável pela seleção, origem e qualidade dos dados observados fornecidos (séries de estações ou normais climatológicas), bem como por sua representatividade para a área analisada. O processamento só começa com essa confirmação.

## Integridade

`SHA256SUMS.txt` lista o SHA-256 de cada arquivo do complemento. O hash garante integridade, não autoria.
