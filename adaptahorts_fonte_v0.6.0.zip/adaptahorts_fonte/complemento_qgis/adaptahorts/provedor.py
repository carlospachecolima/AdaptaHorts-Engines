from __future__ import annotations

from qgis.core import QgsProcessingProvider
from qgis.PyQt.QtGui import QIcon

from .algoritmos import ICONE, VERSAO_COMPLEMENTO, AlgModeloPlanilha, AlgProcessar, AlgTrabalhoJson, AlgValidar
from .algoritmos_risco import AlgIndices, AlgISCC, AlgISDH, AlgISOC, AlgISSA, AlgPaerc, AlgQuestionario, AlgRisco


class ProvedorAdaptaHorts(QgsProcessingProvider):
    def id(self):
        return "adaptahorts"

    def name(self):
        return "AdaptaHorts"

    def longName(self):  # noqa: N802
        return f"AdaptaHorts – Mapeamento Climático (v{VERSAO_COMPLEMENTO})"

    def icon(self):
        return QIcon(ICONE)

    def versionInfo(self):  # noqa: N802
        return VERSAO_COMPLEMENTO

    def loadAlgorithms(self):  # noqa: N802
        for alg in (AlgModeloPlanilha(), AlgValidar(), AlgProcessar(), AlgTrabalhoJson(),
                    AlgQuestionario(), AlgPaerc(), AlgISOC(), AlgISDH(), AlgISCC(), AlgISSA(),
                    AlgIndices(), AlgRisco()):
            self.addAlgorithm(alg)
