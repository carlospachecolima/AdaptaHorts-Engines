"""Algoritmos do grupo "AdaptaHorts – Risco": questionário PAERC, cálculo do PAERC e risco climático."""

from __future__ import annotations

import json
from pathlib import Path

from qgis.core import (QgsCoordinateTransformContext, QgsProcessing, QgsProcessingContext, QgsProcessingException,
                       QgsProcessingOutputFile, QgsProcessingOutputNumber, QgsProcessingOutputString,
                       QgsProcessingParameterBoolean, QgsProcessingParameterDefinition, QgsProcessingParameterEnum,
                       QgsProcessingParameterField, QgsProcessingParameterFile, QgsProcessingParameterFileDestination,
                       QgsProcessingParameterFolderDestination, QgsProcessingParameterNumber,
                       QgsProcessingParameterRasterLayer, QgsProcessingParameterString,
                       QgsProcessingParameterVectorLayer, QgsProject, QgsRasterLayer, QgsVectorFileWriter,
                       QgsVectorLayer)

from .algoritmos import ICONE, VERSAO_COMPLEMENTO, _Base, _erro_processamento, _Feedback, _tr
from .motor_mapeamento.risco.config_risco import PARAMETROS_RISCO
from .motor_mapeamento.risco.paerc import DESCRICAO_FAIXAS

AJUDA_RISCO = f"""
<p><b>Risco = Ameaça × Exposição × (1 − PAERC)</b>, todos os termos em [0, 1].</p>
<p><b>Ameaça:</b> média ponderada de ISOC (ondas de calor), ISDH (déficit hídrico), ISCC (concentração de
chuvas) e ISSA (salinização). Sem dados de salinidade, o ISSA é a <b>suscetibilidade climática à salinização</b>,
pelo balanço de sais da FAO-29 (a irrigação repõe o déficit, a chuva dilui e lixivia); com um raster de CE do solo
medida, passa a ser o estresse salino. Um produto auxiliar mostra a CE máxima da água de irrigação que mantém o solo
abaixo do limiar da alface (1,5 dS/m). Cada índice combina Intensidade, Duração e Concentração
sazonal com os pesos calibrados por bootstrap (médias, IC 95%): ISOC 0,460/0,352/0,188; ISDH 0,446/0,354/0,200;
ISCC 0,372/0,231/0,397; ISSA 0,432/0,406/0,162 (I/D/C). Os componentes são normalizados por limiares fixos, iguais
para o histórico e para a projeção. Cada índice também tem um algoritmo próprio (ISOC, ISDH, ISCC, ISSA).
ET0 por Hargreaves–Samani, Kc da alface = 1,00.</p>
<p><b>Exposição:</b> 1 − adoção de sistemas conservacionistas (padrão: 10% de adoção → exposição 0,90),
ou um raster/polígonos com valores de 0 a 1.</p>
<p><b>PAERC:</b> questionário estruturado do AdaptaHorts (algoritmo R1), aplicado por propriedade e
agregado por microrregião pela mediana das respostas, com IC 95% por bootstrap.
PAERC (IPSV-AF) = 0,473·CE + 0,388·CT + 0,139·CI (médias do bootstrap).</p>
<p><b>Entrada climática:</b> a pasta de resultados do algoritmo "2. Processar" (histórico e projeção corrigidos).</p>
<p>Complemento v{VERSAO_COMPLEMENTO}</p>
"""

AJUDA_QUESTIONARIO = "<p><b>Faixas de pontuação</b></p><ul>" + "".join(
    f"<li><b>{a}:</b> {b}</li>" for a, b in DESCRICAO_FAIXAS) + "</ul>"


class _BaseRisco(_Base):
    def group(self):
        return _tr("AdaptaHorts – Risco")

    def groupId(self):  # noqa: N802
        return "adaptahorts_risco"


def _exportar_vetor(lyr: QgsVectorLayer, destino: Path) -> Path:
    if destino.exists():
        destino.unlink()
    opc = QgsVectorFileWriter.SaveVectorOptions()
    opc.driverName = "GPKG"
    res = QgsVectorFileWriter.writeAsVectorFormatV3(lyr, str(destino), QgsCoordinateTransformContext(), opc)
    if res[0] != QgsVectorFileWriter.NoError:
        raise QgsProcessingException(f"Não foi possível exportar a camada {lyr.name()}: {res[1]}")
    return destino


class AlgQuestionario(_BaseRisco):
    FORMATOS = ["GeoPackage com formulário (QGIS/QField)", "Planilha Excel (.xlsx)", "Ambos"]

    def name(self):
        return "questionario_paerc"

    def displayName(self):  # noqa: N802
        return _tr("R1. Gerar questionário PAERC")

    def shortHelpString(self):  # noqa: N802
        return ("<p>Gera o questionário estruturado do PAERC para aplicar nas propriedades: uma camada de pontos "
                "GeoPackage com formulário em abas (Identificação, Econômica, Técnica, Institucional), listas de "
                "opções e respostas obrigatórias, pronta para coleta no QGIS ou no QField, e/ou uma planilha "
                "Excel com as mesmas perguntas. Itens do documento ainda sem faixas de pontuação são registrados, "
                "mas não entram no índice.</p>" + AJUDA_QUESTIONARIO)

    def initAlgorithm(self, config=None):  # noqa: N802
        self.addParameter(QgsProcessingParameterEnum("FORMATO", _tr("Formato"), self.FORMATOS, defaultValue=0))
        self.addParameter(QgsProcessingParameterFolderDestination("PASTA", _tr("Pasta de destino")))
        self.addParameter(QgsProcessingParameterBoolean("CARREGAR", _tr("Carregar a camada do questionário no projeto"),
                                                        defaultValue=True))
        self.addOutput(QgsProcessingOutputFile("GPKG", _tr("Questionário GeoPackage")))
        self.addOutput(QgsProcessingOutputFile("XLSX", _tr("Questionário Excel")))

    def flags(self):
        return super().flags() | self.FlagNoThreading  # grava estilo de formulário (PyQGIS)

    def processAlgorithm(self, parameters, context, feedback):  # noqa: N802
        from .motor_mapeamento.risco.formulario_qgis import criar_formulario_gpkg
        from .motor_mapeamento.risco.paerc import criar_modelo_xlsx
        pasta = Path(self.parameterAsString(parameters, "PASTA", context))
        pasta.mkdir(parents=True, exist_ok=True)
        fmt = self.parameterAsEnum(parameters, "FORMATO", context)
        out = {"GPKG": "", "XLSX": ""}
        if fmt in (0, 2):
            g = criar_formulario_gpkg(pasta / "questionario_paerc.gpkg")
            out["GPKG"] = str(g)
            feedback.pushInfo(f"Questionário GeoPackage: {g}")
            if self.parameterAsBool(parameters, "CARREGAR", context):
                det = QgsProcessingContext.LayerDetails("Questionário PAERC", context.project() or QgsProject.instance(), "")
                context.addLayerToLoadOnCompletion(f"{g}|layername=questionario_paerc", det)
        if fmt in (1, 2):
            x = criar_modelo_xlsx(pasta / "questionario_paerc.xlsx")
            out["XLSX"] = str(x)
            feedback.pushInfo(f"Questionário Excel: {x}")
        return out


def _parametros_paerc(alg, parameters, context, entradas: Path) -> dict | None:
    q = alg.parameterAsVectorLayer(parameters, "QUESTIONARIOS_CAMADA", context)
    arq = alg.parameterAsFile(parameters, "QUESTIONARIOS_ARQUIVO", context)
    reg = alg.parameterAsVectorLayer(parameters, "MICRORREGIOES", context)
    if q is None and not arq:
        return None
    if reg is None:
        raise QgsProcessingException("Para o PAERC, informe também a camada de microrregiões.")
    campo = alg.parameterAsString(parameters, "CAMPO_NOME", context)
    if not campo:
        raise QgsProcessingException("Informe o campo com o nome da microrregião.")
    fonte_q = str(_exportar_vetor(q, entradas / "questionarios.gpkg")) if q is not None else arq
    return {"questionarios": fonte_q, "microrregioes": str(_exportar_vetor(reg, entradas / "microrregioes.gpkg")),
            "campo_nome": campo}


def _params_paerc_comuns(alg, obrigatorio: bool):
    alg.addParameter(QgsProcessingParameterVectorLayer(
        "QUESTIONARIOS_CAMADA", _tr("Questionários PAERC – camada de pontos (GeoPackage do R1)"),
        [QgsProcessing.TypeVectorPoint], optional=True))
    alg.addParameter(QgsProcessingParameterFile(
        "QUESTIONARIOS_ARQUIVO", _tr("… ou planilha de questionários (.xlsx, .ods, .csv)"),
        fileFilter="Planilhas (*.xlsx *.ods *.csv)", optional=True))
    alg.addParameter(QgsProcessingParameterVectorLayer(
        "MICRORREGIOES", _tr("Microrregiões (polígonos)"), [QgsProcessing.TypeVectorPolygon], optional=not obrigatorio))
    alg.addParameter(QgsProcessingParameterField(
        "CAMPO_NOME", _tr("Campo com o nome da microrregião"), parentLayerParameterName="MICRORREGIOES",
        type=QgsProcessingParameterField.String, optional=not obrigatorio))
    av = [QgsProcessingParameterEnum("AGREGACAO", _tr("Agregação regional das respostas"), ["Mediana", "Média"],
                                     defaultValue=0),
          QgsProcessingParameterEnum("DIVERSIFICACAO", _tr("Indicador de diversificação"),
                                     ["Nº de espécies", "Índice de Shannon (H')"], defaultValue=0),
          QgsProcessingParameterEnum("PROXIMIDADE", _tr("Indicador de proximidade à CEASA"),
                                     ["Distância (km)", "Tempo (min)"], defaultValue=0),
          QgsProcessingParameterNumber("BOOTSTRAP", _tr("Iterações do bootstrap (IC 95%)"),
                                       QgsProcessingParameterNumber.Integer, defaultValue=10000, minValue=0,
                                       maxValue=1000000)]
    w = PARAMETROS_RISCO["pesos"]["paerc"]
    pesos = [QgsProcessingParameterNumber(f"PESO_{d}", _tr(f"Peso da dimensão {d} ({nome}) – bootstrap"),
                                          QgsProcessingParameterNumber.Double, defaultValue=w[d], minValue=0, maxValue=1)
             for d, nome in (("CE", "econômica"), ("CT", "técnica"), ("CI", "institucional"))]
    if obrigatorio:  # no R2 os pesos ficam à vista; no risco, entre os avançados
        for p in pesos:
            alg.addParameter(p)
    else:
        av = pesos + av
    for p in av:
        p.setFlags(p.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        alg.addParameter(p)


def _pesos(alg, parameters, context, chaves, nome, feedback=None) -> dict:
    """Lê pesos e os normaliza para somar 1 (avisando se foi preciso)."""
    w = {k: alg.parameterAsDouble(parameters, f"PESO_{k}", context) for k in chaves}
    s = sum(w.values())
    if s <= 0:
        raise QgsProcessingException(f"Os pesos de {nome} somam zero.")
    if abs(s - 1) > 1e-6:
        if feedback is not None:
            feedback.pushWarning(f"Pesos de {nome} somavam {s:.3f}; normalizados para somar 1.")
        w = {k: v / s for k, v in w.items()}
    return w


def _params_paerc_valores(alg, parameters, context, feedback=None) -> dict:
    return {"pesos": {"paerc": _pesos(alg, parameters, context, ("CE", "CT", "CI"), "PAERC", feedback)},"paerc_agregacao": ["mediana", "media"][alg.parameterAsEnum(parameters, "AGREGACAO", context)],
            "paerc_diversificacao": ["especies", "shannon"][alg.parameterAsEnum(parameters, "DIVERSIFICACAO", context)],
            "paerc_proximidade": ["distancia", "tempo"][alg.parameterAsEnum(parameters, "PROXIMIDADE", context)],
            "paerc_bootstrap_iteracoes": alg.parameterAsInt(parameters, "BOOTSTRAP", context)}


class AlgPaerc(_BaseRisco):
    def name(self):
        return "calcular_paerc"

    def displayName(self):  # noqa: N802
        return _tr("R2. PAERC (IPSV-AF) dos questionários")

    def shortHelpString(self):  # noqa: N802
        return ("<p>Calcula o PAERC por propriedade e por microrregião a partir dos questionários. Cada resposta "
                "é pontuada pelas faixas do documento; CE, CT e CI são médias das pontuações; na microrregião, as "
                "faixas são aplicadas à mediana das respostas (crédito como % de produtores) e o IC 95% vem de "
                "bootstrap das propriedades. Questionários com coordenadas são atribuídos à microrregião pela "
                "localização; sem coordenadas, pelo nome.</p><p><b>PAERC (IPSV-AF) = 0,473·CE + 0,388·CT + "
                "0,139·CI</b>: médias do bootstrap (10.000 iterações) do Relatório técnico do IPSV-AF; IC 95%: CE "
                "[0,435–0,512], CT [0,348–0,427], CI [0,115–0,165]. Os pesos podem ser alterados; se não somarem 1, "
                "são normalizados.</p>"
                + AJUDA_QUESTIONARIO)

    def initAlgorithm(self, config=None):  # noqa: N802
        _params_paerc_comuns(self, obrigatorio=True)
        self.addParameter(QgsProcessingParameterFolderDestination("SAIDA", _tr("Pasta de resultados")))
        self.addParameter(QgsProcessingParameterBoolean("CARREGAR", _tr("Carregar microrregiões com o PAERC no projeto"),
                                                        defaultValue=True))
        self.addOutput(QgsProcessingOutputFile("MICRORREGIOES_PAERC", _tr("Microrregiões com PAERC (GeoPackage)")))
        self.addOutput(QgsProcessingOutputNumber("N_QUESTIONARIOS", _tr("Número de questionários")))

    def processAlgorithm(self, parameters, context, feedback):  # noqa: N802
        from osgeo import ogr
        from .motor_mapeamento import geo
        from .motor_mapeamento.config import _mesclar
        from .motor_mapeamento.pipeline import _csv
        from .motor_mapeamento.risco.pipeline_risco import _questionarios
        saida = Path(self.parameterAsString(parameters, "SAIDA", context))
        entradas = saida / "entradas"
        entradas.mkdir(parents=True, exist_ok=True)
        pa = _parametros_paerc(self, parameters, context, entradas)
        if pa is None:
            raise QgsProcessingException("Informe a camada ou a planilha de questionários.")
        p = _mesclar(PARAMETROS_RISCO, _params_paerc_valores(self, parameters, context, feedback))
        w = p["pesos"]["paerc"]
        feedback.pushInfo(f"PAERC = {w['CE']:.3f}·CE + {w['CT']:.3f}·CT + {w['CI']:.3f}·CI")
        avisos: list[str] = []
        try:
            r = _questionarios({"paerc": pa}, p, avisos)
        except Exception as exc:  # noqa: BLE001
            raise _erro_processamento(exc, feedback)
        for a in avisos:
            feedback.pushWarning(a)
        _csv(saida / "paerc_propriedades.csv", r["propriedades"])
        _csv(saida / "paerc_microrregioes.csv", r["regioes"])
        gpkg = saida / "microrregioes_paerc.gpkg"
        drv = ogr.GetDriverByName("GPKG")
        if gpkg.exists():
            drv.DeleteDataSource(str(gpkg))
        d = drv.CreateDataSource(str(gpkg))
        lyr = d.CreateLayer("microrregioes_paerc", geo.srs_wgs84(), ogr.wkbMultiPolygon)
        lyr.CreateField(ogr.FieldDefn("microrregiao", ogr.OFTString))
        num = ["n_questionarios", "CE", "CT", "CI", "PAERC", "PAERC_ic95_inf", "PAERC_ic95_sup", "vulnerabilidade"]
        for c in num:
            lyr.CreateField(ogr.FieldDefn(c.lower(), ogr.OFTInteger if c == "n_questionarios" else ogr.OFTReal))
        por_nome = {x["microrregiao"]: x for x in r["regioes"]}
        for g, a in r["feicoes"]:
            ft = ogr.Feature(lyr.GetLayerDefn())
            nome = a[r["campo"]]
            ft.SetField("microrregiao", nome)
            x = por_nome.get(nome)
            if x:
                x = {**x, "vulnerabilidade": 1 - x["PAERC"]}
                for c in num:
                    if x.get(c) is not None:
                        ft.SetField(c.lower(), x[c])
            ft.SetGeometry(ogr.ForceToMultiPolygon(g.Clone()))
            lyr.CreateFeature(ft)
        d = None
        for x in r["regioes"]:
            ic = (f" (IC 95%: {x['PAERC_ic95_inf']:.3f}–{x['PAERC_ic95_sup']:.3f})"
                  if x["PAERC_ic95_inf"] is not None else "")
            feedback.pushInfo(f"{x['microrregiao']}: PAERC {x['PAERC']:.3f}{ic}, n = {x['n_questionarios']}")
        if self.parameterAsBool(parameters, "CARREGAR", context):
            det = QgsProcessingContext.LayerDetails("Microrregiões – PAERC", context.project() or QgsProject.instance(), "")
            context.addLayerToLoadOnCompletion(f"{gpkg}|layername=microrregioes_paerc", det)
        return {"MICRORREGIOES_PAERC": str(gpkg), "N_QUESTIONARIOS": r["n"], "SAIDA": str(saida)}


PRODUTOS_CARREGAR = [
    ("isoc", "ISOC – ondas de calor"), ("isdh", "ISDH – déficit hídrico"),
    ("iscc", "ISCC – concentração de chuvas"), ("issa", "ISSA – salinização"),
    ("ecw_critica", "CE máxima da água de irrigação"), ("ameaca", "Ameaça agregada"),
    ("risco_potencial", "Risco potencial (ameaça × exposição)"), ("risco", "Risco climático"),
    ("risco_classes", "Classes de risco"),
]
INDICES = [("isoc", "ISOC (ondas de calor)"), ("isdh", "ISDH (déficit hídrico)"),
           ("iscc", "ISCC (concentração de chuvas)"), ("issa", "ISSA (salinização)")]


class AlgRisco(_BaseRisco):
    """Risco climático completo. A subclasse AlgIndices calcula só os índices e a ameaça."""

    SO_AMEACA = False
    EXPOSICAO = ["Constante: 1 − adoção de sistemas conservacionistas", "Raster (0–1)", "Polígonos com campo (0–1)"]

    def name(self):
        return "risco_climatico"

    def displayName(self):  # noqa: N802
        return _tr("R8. Risco climático (ameaça × exposição × vulnerabilidade)")

    def shortHelpString(self):  # noqa: N802
        return AJUDA_RISCO + AJUDA_QUESTIONARIO

    def flags(self):
        return super().flags() | self.FlagNoThreading  # layouts PyQGIS no thread principal

    def _produtos(self):
        return PRODUTOS_CARREGAR[:6] if self.SO_AMEACA else PRODUTOS_CARREGAR

    def initAlgorithm(self, config=None):  # noqa: N802
        P = self.addParameter
        P(QgsProcessingParameterFile("MAPEAMENTO", _tr("Pasta de resultados do mapeamento (algoritmo 2. Processar)"),
                                     behavior=QgsProcessingParameterFile.Folder))
        P(QgsProcessingParameterVectorLayer("AREA", _tr("Área de estudo (opcional; padrão: a do mapeamento)"),
                                            [QgsProcessing.TypeVectorPolygon], optional=True))
        for chave, nome in INDICES:
            P(QgsProcessingParameterNumber(f"PESO_{chave.upper()}", _tr(f"Peso do {nome} na ameaça (0 = fora)"),
                                           QgsProcessingParameterNumber.Double,
                                           defaultValue=PARAMETROS_RISCO["pesos_ameaca"][chave], minValue=0, maxValue=1))
        P(QgsProcessingParameterRasterLayer("CE", _tr("CE do solo medida – dS/m (opcional; sem ela, o ISSA é a "
                                                      "suscetibilidade climática)"), optional=True))
        if not self.SO_AMEACA:
            P(QgsProcessingParameterEnum("EXPOSICAO_MODO", _tr("Exposição"), self.EXPOSICAO, defaultValue=0))
            P(QgsProcessingParameterNumber("ADOCAO", _tr("Adoção de sistemas conservacionistas (0–1)"),
                                           QgsProcessingParameterNumber.Double, defaultValue=0.10, minValue=0, maxValue=1))
            P(QgsProcessingParameterRasterLayer("EXPOSICAO_RASTER", _tr("Exposição – raster (0–1)"), optional=True))
            P(QgsProcessingParameterVectorLayer("EXPOSICAO_POLIGONOS", _tr("Exposição – polígonos"),
                                                [QgsProcessing.TypeVectorPolygon], optional=True))
            P(QgsProcessingParameterField("EXPOSICAO_CAMPO", _tr("Campo de exposição (0–1)"),
                                          parentLayerParameterName="EXPOSICAO_POLIGONOS",
                                          type=QgsProcessingParameterField.Numeric, optional=True))
            _params_paerc_comuns(self, obrigatorio=False)
        prods = self._produtos()
        P(QgsProcessingParameterEnum("CAMADAS", _tr("Camadas a carregar no projeto (histórico e projeção)"),
                                     [n for _, n in prods], allowMultiple=True,
                                     defaultValue=list(range(len(prods))) if self.SO_AMEACA else [0, 1, 2, 3, 5, 7, 8]))
        av = [QgsProcessingParameterBoolean("GERAR_MAPAS", _tr("Gerar layouts e exportar mapas"), defaultValue=True),
              QgsProcessingParameterString("PARAMETROS_JSON", _tr("Parâmetros adicionais do módulo de risco (JSON)"),
                                           optional=True, multiLine=True)]
        if not self.SO_AMEACA:
            av.insert(0, QgsProcessingParameterString("CLASSES", _tr("Limites das 5 classes de risco (ex.: 0.2; 0.4; 0.6; 0.8)"),
                                                      optional=True))
        for par in av:
            par.setFlags(par.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
            P(par)
        P(QgsProcessingParameterFolderDestination("SAIDA", _tr("Pasta de resultados (vazia)")))
        self.addOutput(QgsProcessingOutputString("SITUACAO", _tr("Situação")))
        self.addOutput(QgsProcessingOutputFile("RELATORIO", _tr("Relatório")))
        self.addOutput(QgsProcessingOutputFile("MANIFESTO", _tr("Manifesto")))

    def _exposicao(self, parameters, context, entradas):
        if self.SO_AMEACA:
            return {"tipo": "constante"}
        modo = self.parameterAsEnum(parameters, "EXPOSICAO_MODO", context)
        if modo == 0:
            return {"tipo": "constante", "adocao_conservacionista": self.parameterAsDouble(parameters, "ADOCAO", context)}
        if modo == 1:
            r = self.parameterAsRasterLayer(parameters, "EXPOSICAO_RASTER", context)
            if r is None:
                raise QgsProcessingException("Exposição por raster: informe o raster.")
            return {"tipo": "raster", "arquivo": r.source()}
        v = self.parameterAsVectorLayer(parameters, "EXPOSICAO_POLIGONOS", context)
        campo = self.parameterAsString(parameters, "EXPOSICAO_CAMPO", context)
        if v is None or not campo:
            raise QgsProcessingException("Exposição por polígonos: informe a camada e o campo.")
        return {"tipo": "poligonos", "arquivo": str(_exportar_vetor(v, entradas / "exposicao.gpkg")), "campo": campo}

    def processAlgorithm(self, parameters, context, feedback):  # noqa: N802
        from .motor_mapeamento.config import _mesclar
        from .motor_mapeamento.risco.pipeline_risco import executar
        saida = Path(self.parameterAsString(parameters, "SAIDA", context))
        saida.mkdir(parents=True, exist_ok=True)
        entradas = saida / "entradas"
        entradas.mkdir(parents=True, exist_ok=True)
        area = self.parameterAsVectorLayer(parameters, "AREA", context)
        ce = self.parameterAsRasterLayer(parameters, "CE", context)
        params = {} if self.SO_AMEACA else _params_paerc_valores(self, parameters, context, feedback)
        params["somente_ameaca"] = self.SO_AMEACA
        params["gerar_mapas"] = self.parameterAsBool(parameters, "GERAR_MAPAS", context)
        params["pesos_ameaca"] = {k: self.parameterAsDouble(parameters, f"PESO_{k.upper()}", context) for k, _ in INDICES}
        if sum(params["pesos_ameaca"].values()) <= 0:
            raise QgsProcessingException("Pelo menos um índice precisa ter peso maior que zero na ameaça.")
        if not self.SO_AMEACA:
            classes = self.parameterAsString(parameters, "CLASSES", context).strip()
            if classes:
                try:
                    params["classes_limites"] = [float(x.replace(",", ".")) for x in classes.split(";") if x.strip()]
                except ValueError:
                    raise QgsProcessingException("Classes: use números separados por ';'.")
        extra = self.parameterAsString(parameters, "PARAMETROS_JSON", context).strip()
        if extra:
            try:
                params = _mesclar(params, json.loads(extra))
            except json.JSONDecodeError as exc:
                raise QgsProcessingException(f"Parâmetros adicionais: JSON inválido ({exc}).")
        try:
            from qgis.core import Qgis
            vq = Qgis.QGIS_VERSION
        except Exception:  # noqa: BLE001
            vq = None
        trabalho = {
            "interface": {"nome": "complemento QGIS AdaptaHorts – " + ("Índices" if self.SO_AMEACA else "Risco"),
                          "versao": VERSAO_COMPLEMENTO, "qgis": vq},
            "mapeamento": self.parameterAsFile(parameters, "MAPEAMENTO", context),
            "area": str(_exportar_vetor(area, entradas / "area_estudo.gpkg")) if area is not None else None,
            "exposicao": self._exposicao(parameters, context, entradas),
            "paerc": None if self.SO_AMEACA else _parametros_paerc(self, parameters, context, entradas),
            "ce_salinidade": ce.source() if ce is not None else None,
            "saida": str(saida), "parametros": params,
        }
        tj = saida / "trabalho_risco.json"
        tj.write_text(json.dumps(trabalho, ensure_ascii=False, indent=2), encoding="utf-8")
        fb = _Feedback(feedback)
        try:
            r = executar(tj, progresso=fb.progresso, cancelado=fb.cancelado)
        except Exception as exc:  # noqa: BLE001
            raise _erro_processamento(exc, feedback)
        for a in r["avisos"]:
            feedback.pushWarning(a)
        for l in r["resumo"]:
            txt = (f"{l['cenario']}: ISOC {l['isoc']:.3f}; ISDH {l['isdh']:.3f}; ISCC {l['iscc']:.3f}; "
                   f"ISSA {l['issa']:.3f}; ameaça {l['ameaca']:.3f}")
            if not self.SO_AMEACA:
                txt += f"; risco potencial {l['risco_potencial']:.3f}"
                if l.get("risco") is not None:
                    txt += f"; risco {l['risco']:.3f}"
            feedback.pushInfo(txt)
        prods = self._produtos()
        escolhidos = [prods[i][0] for i in self.parameterAsEnums(parameters, "CAMADAS", context)]
        if escolhidos:
            projeto = context.project() or QgsProject.instance()
            from .algoritmos import _Estilo
            grupo = "Índices" if self.SO_AMEACA else "Risco"
            for cen, rot in (("projecao", "projeção"), ("historico", "histórico 1970–2000")):
                for prod in escolhidos:
                    f = next((saida / "rasters" / cen).glob(f"*_{prod}.tif"), None)
                    if f is None:
                        continue
                    det = QgsProcessingContext.LayerDetails(f.stem, projeto, "")
                    if hasattr(det, "groupName"):
                        det.groupName = f"AdaptaHorts – {grupo} – {rot}"
                    est = _EstiloRisco(prod)
                    _Estilo.instancias.append(est)
                    det.setPostProcessor(est)
                    context.addLayerToLoadOnCompletion(str(f), det)
        projeto_qgz = next((saida / "projeto_qgis").glob("*.qgz"), None) if (saida / "projeto_qgis").exists() else None
        if projeto_qgz:
            feedback.pushInfo(f"Projeto com os layouts: {projeto_qgz}")
        return {"SITUACAO": r["situacao"], "RELATORIO": r["relatorio"],
                "MANIFESTO": str(saida / "manifesto_risco.json"), "SAIDA": str(saida)}


class AlgIndices(AlgRisco):
    SO_AMEACA = True

    def name(self):
        return "indices_ameaca"

    def displayName(self):  # noqa: N802
        return _tr("R7. Ameaça agregada (ISOC, ISDH, ISCC, ISSA juntos)")

    def shortHelpString(self):  # noqa: N802
        return ("<p>Calcula só os quatro índices de severidade e a ameaça agregada, para o histórico corrigido e para "
                "a projeção, sem exposição nem PAERC. Gera os rasters (com os componentes Intensidade, Duração e "
                "Concentração de cada índice), a variação entre os períodos, as tabelas, os mapas e o relatório.</p>"
                + AJUDA_RISCO)


# ------------------------------------------------------------------------- um algoritmo por índice

DESC_INDICE = {
    "isoc": ("R3. ISOC – Índice de Severidade de Ondas de Calor",
             "<p><b>ISOC = w<sub>I</sub>·I + w<sub>D</sub>·D + w<sub>C</sub>·C</b>, pesos padrão = médias do bootstrap "
             "(100.000 iterações, IC 95%) do ISOC-Alface: <b>0,460 / 0,352 / 0,188</b>.</p>"
             "<p>I = Tmax média do mês mais quente entre o limiar crítico (30 °C, colapso fisiológico da alface) e o "
             "severo; D = fração do ano com Tmax ≥ limiar, estimada dos dados mensais supondo Tmax diária normal em torno "
             "da média do mês; C = concentração desses dias no ano.</p>"),
    "isdh": ("R4. ISDH – Índice de Severidade de Déficit Hídrico",
             "<p><b>ISDH = w<sub>I</sub>·I + w<sub>D</sub>·D + w<sub>C</sub>·C</b>, pesos padrão = médias do bootstrap "
             "(100.000 iterações, IC 95%) do ISDH-Alface: <b>0,446 / 0,354 / 0,200</b> (a tabela-síntese do CNPq traz "
             "0,452 / 0,346 / 0,202, que podem ser digitados aqui).</p>"
             "<p>ETc = ET0 (Hargreaves–Samani) × Kc. I = déficit anual / ETc anual; D = fração dos meses com déficit "
             "relativo ≥ 30% (perda de 33–43% de biomassa); C = concentração do déficit no ano. Grava também ETc, chuva, "
             "déficit e a necessidade bruta de irrigação (m³/ha/ano).</p>"),
    "iscc": ("R5. ISCC – Índice de Severidade de Concentração de Chuvas",
             "<p><b>ISCC = w<sub>I</sub>·I + w<sub>D</sub>·D + w<sub>C</sub>·C</b>, pesos padrão = médias do bootstrap "
             "(100.000 iterações, IC 95%): <b>0,372 / 0,231 / 0,397</b>.</p>"
             "<p>I = erosividade R (Lombardi Neto & Moldenhauer) entre as classes de Carvalho; D = fração dos meses com "
             "excedente P − ETc acima do limiar de encharcamento; C = PCI de Oliver entre 10 (uniforme) e 20 (forte "
             "concentração). Grava também PCI, R e ISC = PCI·R/P.</p>"),
    "issa": ("R6. ISSA – Índice de Severidade de Salinização",
             "<p><b>ISSA = w<sub>I</sub>·I + w<sub>D</sub>·D + w<sub>C</sub>·C</b>, pesos padrão = médias do bootstrap "
             "(100.000 iterações, IC 95%): <b>0,432 / 0,406 / 0,162</b>.</p>"
             "<p>Sem raster de CE do solo, o ISSA é a <b>suscetibilidade climática à salinização</b> (balanço de sais da "
             "FAO-29): I = fator de concentração de sais ECe/ECw; D = fração dos meses sem lixiviação (P < ETc); "
             "C = concentração do déficit. Produto auxiliar: CE máxima da água de irrigação que mantém o solo abaixo de "
             "1,5 dS/m. Com o raster de CE medida, I passa a ser a CE entre 1,5 e 6,0 dS/m.</p>"),
}
LIMIARES = {  # chave do parâmetro do motor, rótulo
    "isoc": [("isoc_tmax_critica", "Tmax crítica da alface (°C)"),
             ("isoc_tmax_severa", "Tmax severa – intensidade 1 (°C) [proposta]"),
             ("isoc_dp_diario_tmax", "Desvio-padrão da Tmax diária no mês (°C) [proposta]")],
    "isdh": [("isdh_deficit_relativo_dano", "Déficit relativo que causa dano (fração da ETc)"),
             ("kc_alface", "Kc da alface"), ("eficiencia_irrigacao", "Eficiência de irrigação")],
    "iscc": [("iscc_pci_min", "PCI sem concentração"), ("iscc_pci_max", "PCI de forte concentração"),
             ("iscc_r_min", "Erosividade R fraca (MJ mm/ha/h/ano)"), ("iscc_r_max", "Erosividade R muito forte"),
             ("iscc_excedente_encharcamento_mm", "Excedente mensal de encharcamento (mm) [proposta]"),
             ("kc_alface", "Kc da alface")],
    "issa": [("issa_ce_limiar", "CE limiar da alface (dS/m)"), ("issa_ce_max", "CE de dano máximo (dS/m)"),
             ("issa_lf_min", "Fração de lixiviação mínima [proposta]"),
             ("issa_ce_agua", "CE da água de referência (dS/m)"), ("kc_alface", "Kc da alface"),
             ("eficiencia_irrigacao", "Eficiência de irrigação")],
}
AUX_CARREGAR = {"isoc": [], "isdh": ["irrigacao_bruta"], "iscc": ["isc"], "issa": ["ecw_critica"]}


class _AlgIndice(_BaseRisco):
    IND = "isoc"

    def name(self):
        return self.IND

    def displayName(self):  # noqa: N802
        return _tr(DESC_INDICE[self.IND][0])

    def shortHelpString(self):  # noqa: N802
        return (DESC_INDICE[self.IND][1] +
                "<p>Calcula só este índice, para o histórico corrigido (1970–2000) e para a projeção, com os mesmos "
                "limiares. Grava o índice, os componentes I, D e C, a variação (projeção − histórico), mapas, "
                "relatório e manifesto SHA-256. Se os pesos não somarem 1, são normalizados.</p>"
                "<p><b>Entrada:</b> a pasta de resultados do algoritmo \"2. Processar\".</p>"
                f"<p>Complemento v{VERSAO_COMPLEMENTO}</p>")

    def flags(self):
        return super().flags() | self.FlagNoThreading  # layouts PyQGIS no thread principal

    def initAlgorithm(self, config=None):  # noqa: N802
        P = self.addParameter
        P(QgsProcessingParameterFile("MAPEAMENTO", _tr("Pasta de resultados do mapeamento (algoritmo 2. Processar)"),
                                     behavior=QgsProcessingParameterFile.Folder))
        P(QgsProcessingParameterVectorLayer("AREA", _tr("Área de estudo (opcional; padrão: a do mapeamento)"),
                                            [QgsProcessing.TypeVectorPolygon], optional=True))
        w = PARAMETROS_RISCO["pesos"][self.IND]
        for c, nome in (("I", "Intensidade"), ("D", "Duração"), ("C", "Concentração sazonal")):
            P(QgsProcessingParameterNumber(f"PESO_{c}", _tr(f"Peso – {nome} ({c}) – média do bootstrap"),
                                           QgsProcessingParameterNumber.Double, defaultValue=w[c], minValue=0, maxValue=1))
        if self.IND == "issa":
            P(QgsProcessingParameterRasterLayer("CE", _tr("CE do solo medida – dS/m (opcional; sem ela, o ISSA é a "
                                                          "suscetibilidade climática)"), optional=True))
        av = [QgsProcessingParameterNumber(f"LIM_{k.upper()}", _tr(rot), QgsProcessingParameterNumber.Double,
                                           defaultValue=PARAMETROS_RISCO[k])
              for k, rot in LIMIARES[self.IND]]
        av += [QgsProcessingParameterBoolean("GERAR_MAPAS", _tr("Gerar layouts e exportar mapas"), defaultValue=True),
               QgsProcessingParameterString("PARAMETROS_JSON", _tr("Parâmetros adicionais do módulo de risco (JSON)"),
                                            optional=True, multiLine=True)]
        for par in av:
            par.setFlags(par.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
            P(par)
        P(QgsProcessingParameterBoolean("CARREGAR", _tr("Carregar o índice e os componentes I, D, C no projeto"),
                                        defaultValue=True))
        P(QgsProcessingParameterFolderDestination("SAIDA", _tr("Pasta de resultados (vazia)")))
        self.addOutput(QgsProcessingOutputString("SITUACAO", _tr("Situação")))
        self.addOutput(QgsProcessingOutputFile("RELATORIO", _tr("Relatório")))
        self.addOutput(QgsProcessingOutputFile("MANIFESTO", _tr("Manifesto")))
        self.addOutput(QgsProcessingOutputNumber("INDICE_HISTORICO", _tr("Índice médio – histórico")))
        self.addOutput(QgsProcessingOutputNumber("INDICE_PROJECAO", _tr("Índice médio – projeção")))

    def processAlgorithm(self, parameters, context, feedback):  # noqa: N802
        from .motor_mapeamento.config import _mesclar
        from .motor_mapeamento.risco.pipeline_risco import executar
        ind = self.IND
        saida = Path(self.parameterAsString(parameters, "SAIDA", context))
        saida.mkdir(parents=True, exist_ok=True)
        entradas = saida / "entradas"
        entradas.mkdir(parents=True, exist_ok=True)
        area = self.parameterAsVectorLayer(parameters, "AREA", context)
        ce = self.parameterAsRasterLayer(parameters, "CE", context) if ind == "issa" else None
        params = {"indice": ind, "gerar_mapas": self.parameterAsBool(parameters, "GERAR_MAPAS", context),
                  "pesos": {ind: _pesos(self, parameters, context, ("I", "D", "C"), ind.upper(), feedback)}}
        for k, _ in LIMIARES[ind]:
            params[k] = self.parameterAsDouble(parameters, f"LIM_{k.upper()}", context)
        extra = self.parameterAsString(parameters, "PARAMETROS_JSON", context).strip()
        if extra:
            try:
                params = _mesclar(params, json.loads(extra))
            except json.JSONDecodeError as exc:
                raise QgsProcessingException(f"Parâmetros adicionais: JSON inválido ({exc}).")
        params["indice"] = ind
        try:
            from qgis.core import Qgis
            vq = Qgis.QGIS_VERSION
        except Exception:  # noqa: BLE001
            vq = None
        trabalho = {
            "interface": {"nome": f"complemento QGIS AdaptaHorts – {ind.upper()}", "versao": VERSAO_COMPLEMENTO,
                          "qgis": vq},
            "mapeamento": self.parameterAsFile(parameters, "MAPEAMENTO", context),
            "area": str(_exportar_vetor(area, entradas / "area_estudo.gpkg")) if area is not None else None,
            "exposicao": {"tipo": "constante"}, "paerc": None,
            "ce_salinidade": ce.source() if ce is not None else None,
            "saida": str(saida), "parametros": params,
        }
        tj = saida / "trabalho_risco.json"
        tj.write_text(json.dumps(trabalho, ensure_ascii=False, indent=2), encoding="utf-8")
        w = params["pesos"][ind]
        feedback.pushInfo(f"{ind.upper()} = {w['I']:.3f}·I + {w['D']:.3f}·D + {w['C']:.3f}·C")
        fb = _Feedback(feedback)
        try:
            r = executar(tj, progresso=fb.progresso, cancelado=fb.cancelado)
        except Exception as exc:  # noqa: BLE001
            raise _erro_processamento(exc, feedback)
        for a in r["avisos"]:
            feedback.pushWarning(a)
        for l in r["resumo"]:
            feedback.pushInfo(f"{l['cenario']}: {ind.upper()} {l[ind]:.3f} (I {l[ind + '_I']:.3f}; "
                              f"D {l[ind + '_D']:.3f}; C {l[ind + '_C']:.3f})")
        if self.parameterAsBool(parameters, "CARREGAR", context):
            projeto = context.project() or QgsProject.instance()
            from .algoritmos import _Estilo
            prods = [ind, f"{ind}_I", f"{ind}_D", f"{ind}_C"] + AUX_CARREGAR[ind]
            for cen, rot in (("projecao", "projeção"), ("historico", "histórico 1970–2000")):
                for prod in prods:
                    f = next((saida / "rasters" / cen).glob(f"*_{prod}.tif"), None)
                    if f is None:
                        continue
                    det = QgsProcessingContext.LayerDetails(f.stem, projeto, "")
                    if hasattr(det, "groupName"):
                        det.groupName = f"AdaptaHorts – {ind.upper()} – {rot}"
                    est = _EstiloRisco(prod)
                    _Estilo.instancias.append(est)
                    det.setPostProcessor(est)
                    context.addLayerToLoadOnCompletion(str(f), det)
        h, pj = r["resumo"][0][ind], r["resumo"][1][ind]
        return {"SITUACAO": r["situacao"], "RELATORIO": r["relatorio"],
                "MANIFESTO": str(saida / "manifesto_risco.json"), "SAIDA": str(saida),
                "INDICE_HISTORICO": h, "INDICE_PROJECAO": pj}


class AlgISOC(_AlgIndice):
    IND = "isoc"


class AlgISDH(_AlgIndice):
    IND = "isdh"


class AlgISCC(_AlgIndice):
    IND = "iscc"


class AlgISSA(_AlgIndice):
    IND = "issa"


from qgis.core import QgsProcessingLayerPostProcessorInterface  # noqa: E402


class _EstiloRisco(QgsProcessingLayerPostProcessorInterface):
    def __init__(self, produto: str):
        super().__init__()
        self.produto = produto

    def postProcessLayer(self, layer, context, feedback):  # noqa: N802
        if isinstance(layer, QgsRasterLayer):
            from .motor_mapeamento.risco.mapas_risco import estilo_classes, estilo_continuo
            if self.produto == "risco_classes":
                estilo_classes(layer, PARAMETROS_RISCO["classes_nomes_pt"])
            elif self.produto in ("irrigacao_bruta", "isc"):
                from qgis.core import QgsRasterBandStats
                st = layer.dataProvider().bandStatistics(1, QgsRasterBandStats.Min | QgsRasterBandStats.Max)
                estilo_continuo(layer, st.minimumValue, st.maximumValue)
            elif self.produto == "ecw_critica":
                from .motor_mapeamento.risco.mapas_risco import ECW_LIMITES
                estilo_continuo(layer, *ECW_LIMITES, invertido=True)
            else:
                estilo_continuo(layer)
            layer.triggerRepaint()
