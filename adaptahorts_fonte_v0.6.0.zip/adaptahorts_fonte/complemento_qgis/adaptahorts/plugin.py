"""Integração com a interface do QGIS: provedor de Processamento e menu AdaptaHorts."""

from __future__ import annotations

from qgis.core import QgsApplication
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QMessageBox

from .algoritmos import AJUDA_COMUM, ICONE, VERSAO_COMPLEMENTO
from .provedor import ProvedorAdaptaHorts

MENU = "&AdaptaHorts"


class AdaptaHortsPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.provedor = None
        self.acoes: list[QAction] = []

    def initProcessing(self):  # noqa: N802
        self.provedor = ProvedorAdaptaHorts()
        QgsApplication.processingRegistry().addProvider(self.provedor)

    def initGui(self):  # noqa: N802
        self.initProcessing()
        janela = self.iface.mainWindow()
        for texto, alg in (("Gerar planilha-modelo…", "adaptahorts:planilha_modelo"),
                           ("Validar entradas…", "adaptahorts:validar"),
                           ("Processar…", "adaptahorts:processar"),
                           ("Processar arquivo de trabalho (JSON)…", "adaptahorts:processar_json"),
                           ("Risco: gerar questionário PAERC…", "adaptahorts:questionario_paerc"),
                           ("Risco: PAERC (IPSV-AF) dos questionários…", "adaptahorts:calcular_paerc"),
                           ("Risco: ISOC – ondas de calor…", "adaptahorts:isoc"),
                           ("Risco: ISDH – déficit hídrico…", "adaptahorts:isdh"),
                           ("Risco: ISCC – concentração de chuvas…", "adaptahorts:iscc"),
                           ("Risco: ISSA – salinização…", "adaptahorts:issa"),
                           ("Risco: ameaça agregada (quatro índices)…", "adaptahorts:indices_ameaca"),
                           ("Risco: risco climático…", "adaptahorts:risco_climatico")):
            acao = QAction(QIcon(ICONE), texto, janela)
            acao.triggered.connect(lambda _=False, a=alg: self._abrir(a))
            self.iface.addPluginToMenu(MENU, acao)
            self.acoes.append(acao)
        sobre = QAction("Sobre e aviso de responsabilidade", janela)
        sobre.triggered.connect(self._sobre)
        self.iface.addPluginToMenu(MENU, sobre)
        self.acoes.append(sobre)
        self.iface.addToolBarIcon(self.acoes[2])

    def unload(self):
        for acao in self.acoes:
            self.iface.removePluginMenu(MENU, acao)
        if self.acoes:
            self.iface.removeToolBarIcon(self.acoes[2])
        self.acoes = []
        if self.provedor is not None:
            QgsApplication.processingRegistry().removeProvider(self.provedor)
            self.provedor = None

    def _abrir(self, alg_id: str) -> None:
        import processing
        processing.execAlgorithmDialog(alg_id, {})

    def _sobre(self) -> None:
        QMessageBox.information(self.iface.mainWindow(), f"AdaptaHorts v{VERSAO_COMPLEMENTO}", AJUDA_COMUM)
