"""Algoritmos de Processamento do AdaptaHorts.

Os algoritmos montam um arquivo de trabalho (JSON) a partir dos parâmetros, gravam uma
cópia junto dos resultados e chamam o mesmo motor usado pela linha de comando e pela web.
"""

from __future__ import annotations

import json
import time
from pathlib import Path

from qgis.core import (QgsCoordinateTransformContext, QgsProcessing, QgsProcessingAlgorithm,
                       QgsProcessingContext, QgsProcessingException, QgsProcessingLayerPostProcessorInterface,
                       QgsProcessingOutputFile, QgsProcessingOutputFolder, QgsProcessingOutputNumber,
                       QgsProcessingOutputString, QgsProcessingParameterBoolean, QgsProcessingParameterDefinition,
                       QgsProcessingParameterEnum, QgsProcessingParameterFile, QgsProcessingParameterFileDestination,
                       QgsProcessingParameterFolderDestination, QgsProcessingParameterMultipleLayers,
                       QgsProcessingParameterNumber, QgsProcessingParameterString,
                       QgsProcessingParameterVectorLayer, QgsProject, QgsRasterLayer, QgsVectorFileWriter)
from qgis.PyQt.QtCore import QCoreApplication, QThread
from qgis.PyQt.QtGui import QIcon

from .motor_mapeamento import __version__ as VERSAO_MOTOR
from .motor_mapeamento.config import (AVISO_RESPONSABILIDADE_PT, Cancelado, DecisaoNecessaria, ErroValidacao)

VERSAO_COMPLEMENTO = "0.6.0"
ICONE = str(Path(__file__).parent / "icon.png")

TIPOS_DECLARADOS = ["serie", "normal", "serie e normal"]
TIPOS_ROTULOS = ["Séries mensais (um valor por ano e mês)", "Normais climatológicas", "Séries e normais"]
POLITICAS = ["perguntar", "manter", "excluir"]
POLITICAS_ROTULOS = ["Interromper e pedir decisão", "Manter e marcar no relatório", "Excluir do cálculo"]
NORMAIS = ["tendencia", "media", "unica"]
NORMAIS_ROTULOS = ["Taxa por década das normais (1961–2020), referência em 1985 – artigo, seção 2.7",
                   "Média simples dos períodos de normal", "Um único período de normal por estação"]
TAXA_ESTACOES = ["todas", "completas"]
TAXA_ESTACOES_ROTULOS = ["Média de todas as estações disponíveis em cada período",
                         "Só estações com todos os períodos (evita efeito de composição)"]
UNID_TEMP = ["°C", "K"]
UNID_PREC = ["mm/mês", "mm/dia"]
MEDIAS = ["simples", "ponderada_area"]
MEDIAS_ROTULOS = ["Simples (como no artigo e no QGIS)", "Ponderada pela área da célula (cos lat)"]
METODOS_PREC = ["aditivo", "multiplicativo"]
IDIOMAS = ["pt", "en"]

AJUDA_COMUM = f"""
<p><b>Método.</b> Correção regional pelo método Delta (Lima et al., 2026, <i>Land Degradation &amp; Development</i>,
doi:10.1002/ldr.70808): para cada variável e mês, ajuste = média regional das estações (peso igual por local)
− média dos pixels do WorldClim histórico dentro da área. O ajuste é somado à projeção CMIP6 e ao histórico.</p>
<p><b>WorldClim histórico:</b> um GeoTIFF por variável e mês (wc2.1_30s_&lt;var&gt;_&lt;MM&gt;.tif). O mês
analisado vem do nome do arquivo.<br>
<b>Projeção:</b> GeoTIFF de 12 bandas (wc2.1_30s_&lt;var&gt;_&lt;MODELO&gt;_&lt;sspXYZ&gt;_&lt;AAAA-AAAA&gt;.tif); modelo,
SSP e período vêm do nome do arquivo. Todos em EPSG:4326, 30 segundos de arco, na mesma grade.<br>
<b>ETA-HadGEM2-ES (opcional):</b> período histórico, um GeoTIFF por mês, como baixado do Portal de Projeções
do INPE; o mês é lido do nome (..._Mensal_Abril.tif). Arquivos de 12 bandas também são aceitos. Valores fora da
faixa física (como o código −999000000 do INPE) são tratados como ausentes.<br>
<b>Observados:</b> planilha-modelo do AdaptaHorts (.xlsx, .ods ou .csv). Use o algoritmo
"Gerar planilha-modelo". Só entram anos de 1970–2000; recomenda-se ao menos 20 anos válidos.</p>
<p><b>Responsabilidade.</b> {AVISO_RESPONSABILIDADE_PT}</p>
<p>Motor v{VERSAO_MOTOR} · complemento v{VERSAO_COMPLEMENTO}</p>
"""


def _tr(texto: str) -> str:
    return QCoreApplication.translate("AdaptaHorts", texto)


def _no_thread_principal() -> bool:
    app = QCoreApplication.instance()
    return app is not None and QThread.currentThread() == app.thread()


class _Feedback:
    """Adapta QgsProcessingFeedback ao motor (progresso e cancelamento)."""

    def __init__(self, feedback):
        self.f = feedback
        self._ultimo = 0.0
        self._ultima_msg = ""

    def progresso(self, pct: float, msg: str) -> None:
        if self.f is None:
            return
        self.f.setProgress(pct)
        if msg and msg != self._ultima_msg:
            self.f.setProgressText(msg)
            self._ultima_msg = msg
        # Execução no thread principal (mapas PyQGIS): mantém a janela responsiva e o botão Cancelar.
        agora = time.monotonic()
        if _no_thread_principal() and agora - self._ultimo > 0.2:
            QCoreApplication.processEvents()
            self._ultimo = agora

    def cancelado(self) -> bool:
        return bool(self.f is not None and self.f.isCanceled())


class _Estilo(QgsProcessingLayerPostProcessorInterface):
    """Aplica a simbologia do AdaptaHorts às camadas carregadas ao final."""

    instancias: list = []  # mantém referências vivas até o pós-processamento

    def __init__(self, var: str, limites: dict):
        super().__init__()
        self.var, self.limites = var, limites

    def postProcessLayer(self, layer, context, feedback):  # noqa: N802
        if isinstance(layer, QgsRasterLayer) and self.limites:
            from .motor_mapeamento.layouts_qgis import aplicar_simbologia
            aplicar_simbologia(layer, self.var, self.limites)
            layer.triggerRepaint()


def _erro_processamento(exc: Exception, feedback) -> QgsProcessingException:
    if isinstance(exc, DecisaoNecessaria):
        for m in exc.mensagens:
            feedback.reportError(m, False)
        return QgsProcessingException(
            "Há estações abaixo do mínimo recomendado de anos (lista acima). Escolha 'Manter' ou 'Excluir' em "
            "'Estações abaixo do mínimo de anos' e execute novamente.")
    if isinstance(exc, ErroValidacao):
        for m in exc.mensagens:
            feedback.reportError(m, False)
        return QgsProcessingException(f"{len(exc.mensagens)} problema(s) nas entradas (lista acima). "
                                      "Corrija e execute novamente.")
    if isinstance(exc, Cancelado):
        return QgsProcessingException("Processamento cancelado; resultados parciais foram removidos.")
    return QgsProcessingException(str(exc))


class _Base(QgsProcessingAlgorithm):
    def group(self):
        return _tr("AdaptaHorts")

    def groupId(self):  # noqa: N802
        return "adaptahorts"

    def icon(self):
        return QIcon(ICONE)

    def createInstance(self):  # noqa: N802
        return type(self)()


class _AlgTrabalho(_Base):
    """Parâmetros comuns a Validar e Processar."""

    COM_MAPAS = True

    def initAlgorithm(self, config=None):  # noqa: N802
        P = self.addParameter
        P(QgsProcessingParameterVectorLayer("AREA", _tr("Área de estudo (polígonos)"),
                                            [QgsProcessing.TypeVectorPolygon]))
        P(QgsProcessingParameterMultipleLayers("WC_HIST", _tr("WorldClim histórico 1970–2000 (um GeoTIFF por variável e mês)"),
                                               QgsProcessing.TypeRaster))
        P(QgsProcessingParameterMultipleLayers("WC_PROJ", _tr("WorldClim projeção CMIP6 (GeoTIFF de 12 bandas por variável)"),
                                               QgsProcessing.TypeRaster))
        P(QgsProcessingParameterFile("OBS", _tr("Planilha de dados observados (formato da planilha-modelo: uma linha por valor mensal)"),
                                     fileFilter="Planilhas (*.xlsx *.ods *.csv)"))
        P(QgsProcessingParameterString("FONTE", _tr("Fonte dos dados observados"), defaultValue="INMET/BDMEP"))
        P(QgsProcessingParameterEnum("TIPO", _tr("Tipo dos dados observados"), TIPOS_ROTULOS, defaultValue=0))
        P(QgsProcessingParameterEnum("POLITICA", _tr("Estações abaixo do mínimo de anos"), POLITICAS_ROTULOS,
                                     defaultValue=0))
        P(QgsProcessingParameterEnum("NORMAIS", _tr("Normais climatológicas com mais de um período"), NORMAIS_ROTULOS,
                                     defaultValue=0))
        P(QgsProcessingParameterBoolean("RESPONSABILIDADE", _tr(
            "Confirmo que sou responsável pela seleção, origem, qualidade e representatividade dos dados "
            "observados (ver aviso na ajuda)"), defaultValue=False))
        for var, nome in (("TMIN", "Tmin"), ("TMAX", "Tmax"), ("PREC", "Precipitação")):
            P(QgsProcessingParameterMultipleLayers(
                f"ETA_{var}", _tr(f"ETA-HadGEM2-ES histórico – {nome} (um GeoTIFF por mês, opcional)"),
                QgsProcessing.TypeRaster, optional=True))
        P(QgsProcessingParameterString("ETA_PERIODO", _tr("Período do ETA histórico (ex.: 1961-2005)"), optional=True))
        P(QgsProcessingParameterEnum("ETA_UNID_TEMP", _tr("Unidade da temperatura do ETA"), UNID_TEMP, defaultValue=0))
        P(QgsProcessingParameterEnum("ETA_UNID_PREC", _tr("Unidade da precipitação do ETA"), UNID_PREC, defaultValue=0))

        avancados = [
            QgsProcessingParameterEnum("MEDIA_RASTER", _tr("Média regional do raster"), MEDIAS_ROTULOS, defaultValue=0),
            QgsProcessingParameterEnum("METODO_PREC", _tr("Correção da precipitação"), METODOS_PREC, defaultValue=0),
            QgsProcessingParameterEnum("TAXA_ESTACOES", _tr("Estações usadas na taxa das normais"),
                                       TAXA_ESTACOES_ROTULOS, defaultValue=0),
            QgsProcessingParameterNumber("ANOS_MIN", _tr("Mínimo recomendado de anos válidos (1970–2000)"),
                                         QgsProcessingParameterNumber.Integer, defaultValue=20, minValue=1, maxValue=31),
            QgsProcessingParameterNumber("DIST_MAX", _tr("Distância máxima estação–área (km; vazio = sem limite)"),
                                         QgsProcessingParameterNumber.Double, optional=True, minValue=0),
            QgsProcessingParameterString("PARAMETROS_JSON", _tr("Parâmetros adicionais do motor (JSON, opcional)"),
                                         optional=True, multiLine=True),
        ]
        if self.COM_MAPAS:
            avancados = [
                QgsProcessingParameterString("SIMBOLOGIA", _tr(
                    "Limites fixos da simbologia (ex.: tmin=14:30; tmax=24:40; prec=0:250)"), optional=True),
                QgsProcessingParameterBoolean("GERAR_MAPAS", _tr("Gerar layouts e exportar mapas (PDF e PNG)"),
                                              defaultValue=True),
                QgsProcessingParameterBoolean("MAPAS_HISTORICO", _tr("Gerar também mapas do histórico corrigido"),
                                              defaultValue=False),
                QgsProcessingParameterEnum("IDIOMAS", _tr("Idiomas dos mapas"), ["Português", "English"],
                                           allowMultiple=True, defaultValue=[0, 1]),
                QgsProcessingParameterNumber("DPI", _tr("Resolução de exportação (dpi)"),
                                             QgsProcessingParameterNumber.Integer, defaultValue=300, minValue=72,
                                             maxValue=1200),
            ] + avancados
        for par in avancados:
            par.setFlags(par.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
            P(par)
        if self.COM_MAPAS:
            P(QgsProcessingParameterBoolean("CARREGAR", _tr("Carregar os rasters corrigidos no projeto"),
                                            defaultValue=True))
        P(QgsProcessingParameterFolderDestination("SAIDA", _tr("Pasta de resultados (vazia)")))
        self.addOutput(QgsProcessingOutputString("SITUACAO", _tr("Situação")))
        self.addOutput(QgsProcessingOutputNumber("N_AVISOS", _tr("Número de avisos")))

    # ------------------------------------------------------------------ montagem do trabalho

    def _fontes(self, nome, parameters, context) -> list[str]:
        camadas = self.parameterAsLayerList(parameters, nome, context)
        return [c.source() for c in camadas]

    def montar_trabalho(self, parameters, context, feedback) -> tuple[dict, Path]:
        saida = Path(self.parameterAsString(parameters, "SAIDA", context))
        saida.mkdir(parents=True, exist_ok=True)
        entradas = saida / "entradas"  # cópias geradas pelo complemento (ex.: área exportada da camada)
        entradas.mkdir(parents=True, exist_ok=True)

        area = self.parameterAsVectorLayer(parameters, "AREA", context)
        if area is None:
            raise QgsProcessingException(_tr("Área de estudo inválida."))
        area_gpkg = entradas / "area_estudo.gpkg"
        if area_gpkg.exists():
            area_gpkg.unlink()
        opc = QgsVectorFileWriter.SaveVectorOptions()
        opc.driverName = "GPKG"
        res = QgsVectorFileWriter.writeAsVectorFormatV3(area, str(area_gpkg), QgsCoordinateTransformContext(), opc)
        if res[0] != QgsVectorFileWriter.NoError:
            raise QgsProcessingException(f"Não foi possível exportar a área de estudo: {res[1]}")

        etas = []
        periodo = self.parameterAsString(parameters, "ETA_PERIODO", context).strip()
        ut = UNID_TEMP[self.parameterAsEnum(parameters, "ETA_UNID_TEMP", context)]
        up = UNID_PREC[self.parameterAsEnum(parameters, "ETA_UNID_PREC", context)]
        for var in ("tmin", "tmax", "prec"):
            # Arquivos mensais do Portal de Projeções do INPE: o mês vem do nome (..._Mensal_Abril.tif).
            # Um arquivo de 12 bandas também é aceito (banda = mês).
            for fonte in self._fontes(f"ETA_{var.upper()}", parameters, context):
                etas.append({"arquivo": fonte, "variavel": var, "unidade": up if var == "prec" else ut,
                             "periodo": periodo})

        params = {
            "politica_abaixo_minimo": POLITICAS[self.parameterAsEnum(parameters, "POLITICA", context)],
            "media_raster": MEDIAS[self.parameterAsEnum(parameters, "MEDIA_RASTER", context)],
            "metodo_delta": {"tmin": "aditivo", "tmax": "aditivo",
                             "prec": METODOS_PREC[self.parameterAsEnum(parameters, "METODO_PREC", context)]},
            "anos_minimos_recomendados": self.parameterAsInt(parameters, "ANOS_MIN", context),
            "normais_metodo": NORMAIS[self.parameterAsEnum(parameters, "NORMAIS", context)],
            "normais_taxa_estacoes": TAXA_ESTACOES[self.parameterAsEnum(parameters, "TAXA_ESTACOES", context)],
        }
        if parameters.get("DIST_MAX") not in (None, ""):
            params["distancia_max_estacao_km"] = self.parameterAsDouble(parameters, "DIST_MAX", context)
        if self.COM_MAPAS:
            params.update(
                gerar_mapas=self.parameterAsBool(parameters, "GERAR_MAPAS", context),
                mapas_historico=self.parameterAsBool(parameters, "MAPAS_HISTORICO", context),
                idiomas=[IDIOMAS[i] for i in self.parameterAsEnums(parameters, "IDIOMAS", context)] or ["pt", "en"],
                dpi=self.parameterAsInt(parameters, "DPI", context),
                simbologia=_ler_simbologia(self.parameterAsString(parameters, "SIMBOLOGIA", context)),
            )
        extra = self.parameterAsString(parameters, "PARAMETROS_JSON", context).strip()
        if extra:
            try:
                params.update(json.loads(extra))
            except json.JSONDecodeError as exc:
                raise QgsProcessingException(f"Parâmetros adicionais: JSON inválido ({exc}).")

        try:
            from qgis.core import Qgis
            versao_qgis = Qgis.QGIS_VERSION
        except Exception:  # noqa: BLE001
            versao_qgis = None
        trabalho = {
            "interface": {"nome": "complemento QGIS AdaptaHorts", "versao": VERSAO_COMPLEMENTO, "qgis": versao_qgis},
            "area": str(area_gpkg),
            "worldclim_historico": self._fontes("WC_HIST", parameters, context),
            "worldclim_projecao": self._fontes("WC_PROJ", parameters, context),
            "eta_historico": etas,
            "observados": {
                "arquivo": self.parameterAsFile(parameters, "OBS", context),
                "fonte_declarada": self.parameterAsString(parameters, "FONTE", context).strip(),
                "tipo_declarado": TIPOS_DECLARADOS[self.parameterAsEnum(parameters, "TIPO", context)],
                "confirmo_responsabilidade": self.parameterAsBool(parameters, "RESPONSABILIDADE", context),
            },
            "saida": str(saida),
            "parametros": params,
        }
        caminho = saida / "trabalho.json"
        caminho.write_text(json.dumps(trabalho, ensure_ascii=False, indent=2), encoding="utf-8")
        feedback.pushInfo(f"Trabalho gravado em {caminho}")
        return trabalho, caminho


def _ler_simbologia(texto: str) -> dict:
    """'tmin=14:30; tmax=24:40; prec=0:250' → {'tmin': {'min': 14, 'max': 30}, ...}."""
    out: dict = {}
    for parte in filter(None, (p.strip() for p in (texto or "").replace(",", ";").split(";"))):
        try:
            var, faixa = parte.split("=")
            a, b = faixa.split(":")
            var = var.strip().lower()
            if var not in ("tmin", "tmax", "prec"):
                raise ValueError
            out[var] = {"min": float(a), "max": float(b)}
        except ValueError:
            raise QgsProcessingException(f"Simbologia: não entendi '{parte}'. Use, por exemplo, tmin=14:30; prec=0:250.")
    return out


class AlgValidar(_AlgTrabalho):
    COM_MAPAS = False

    def name(self):
        return "validar"

    def displayName(self):  # noqa: N802
        return _tr("1. Validar entradas (sem processar)")

    def shortHelpString(self):  # noqa: N802
        return ("<p>Confere arquivos, grades, nomes, planilha, anos e estações, e mostra os avisos antes do "
                "processamento. Grava <i>trabalho.json</i> e <i>validacao_preliminar.json</i> na pasta de "
                "resultados, que pode ser reutilizada em seguida no algoritmo Processar.</p>" + AJUDA_COMUM + AJUDA_FORMATO)

    def processAlgorithm(self, parameters, context, feedback):  # noqa: N802
        from .motor_mapeamento.pipeline import validar
        _, caminho = self.montar_trabalho(parameters, context, feedback)
        try:
            r = validar(caminho)
        except Exception as exc:  # noqa: BLE001
            raise _erro_processamento(exc, feedback)
        c = r["combinacao"]
        feedback.pushInfo(f"Combinação: {c.get('modelo')} · {c.get('ssp')} · {c.get('periodo')}")
        meses: dict[str, list[int]] = {}
        for v, m in r["variaveis_meses"]:
            meses.setdefault(v, []).append(m)
        for v, ms in meses.items():
            feedback.pushInfo(f"{v}: meses {', '.join(map(str, ms))}")
        feedback.pushInfo(f"Estações: {len(r['estacoes'])}")
        for a in r["avisos"]:
            feedback.pushWarning(a)
        return {"SITUACAO": r["situacao"], "N_AVISOS": len(r["avisos"]),
                "SAIDA": self.parameterAsString(parameters, "SAIDA", context)}


def _executar_e_carregar(caminho_trabalho: Path, carregar: bool, context: QgsProcessingContext, feedback) -> dict:
    from .motor_mapeamento.pipeline import processar
    fb = _Feedback(feedback)
    try:
        r = processar(caminho_trabalho, progresso=fb.progresso, cancelado=fb.cancelado)
    except Exception as exc:  # noqa: BLE001
        raise _erro_processamento(exc, feedback)
    for a in r["avisos"]:
        feedback.pushWarning(a)
    saida = Path(r["saida"])
    man = r["manifesto"]
    for v, a in man["avaliacao_comparativa_eta"].items():
        feedback.pushInfo(f"Avaliação WorldClim × ETA ({v}): {a['status']}")
    if carregar:
        limites = man.get("simbologia", {})
        projeto = context.project() or QgsProject.instance()
        for tif in sorted((saida / "rasters" / "projecao_corrigida").rglob("*.tif")):
            var = tif.parent.name
            det = QgsProcessingContext.LayerDetails(tif.stem, projeto, "")
            if hasattr(det, "groupName"):
                c = man["combinacao"]
                det.groupName = f"AdaptaHorts – {c['modelo']} {c['ssp']} {c['periodo']} – {var}"
            est = _Estilo(var, limites.get(var))
            _Estilo.instancias.append(est)
            det.setPostProcessor(est)
            context.addLayerToLoadOnCompletion(str(tif), det)
        feedback.pushInfo("Rasters corrigidos serão carregados no projeto ao final.")
    projeto_qgz = next((saida / "projeto_qgis").glob("*.qgz"), None) if (saida / "projeto_qgis").exists() else None
    if projeto_qgz:
        feedback.pushInfo(f"Projeto com os layouts: {projeto_qgz}")
    feedback.pushInfo(f"Relatório: {saida / 'relatorio_validacao.md'}")
    if r.get("zip"):
        feedback.pushInfo(f"ZIP final: {r['zip']}")
    return {
        "SITUACAO": r["situacao"], "N_AVISOS": len(r["avisos"]), "SAIDA": str(saida),
        "RELATORIO": str(saida / "relatorio_validacao.md"), "MANIFESTO": str(saida / "manifesto.json"),
        "PROJETO": str(projeto_qgz) if projeto_qgz else "", "ZIP": r.get("zip", ""),
    }


class AlgProcessar(_AlgTrabalho):
    def name(self):
        return "processar"

    def displayName(self):  # noqa: N802
        return _tr("2. Processar (correção Delta, estatísticas e mapas)")

    def flags(self):
        # Os layouts PyQGIS são gerados no thread principal; o progresso mantém a janela responsiva.
        return super().flags() | QgsProcessingAlgorithm.FlagNoThreading

    def initAlgorithm(self, config=None):  # noqa: N802
        super().initAlgorithm(config)
        for nome, rot in (("RELATORIO", "Relatório de validação"), ("MANIFESTO", "Manifesto"),
                          ("PROJETO", "Projeto QGIS com os layouts"), ("ZIP", "ZIP final")):
            self.addOutput(QgsProcessingOutputFile(nome, _tr(rot)))

    def shortHelpString(self):  # noqa: N802
        return ("<p>Executa a correção Delta, a avaliação comparativa com o ETA, as estatísticas, os rasters "
                "corrigidos, os layouts (A4 paisagem, PDF e PNG) e o relatório com manifesto e hashes SHA-256. "
                "A pasta de resultados deve estar vazia ou conter apenas a validação preliminar.</p>" + AJUDA_COMUM
                + AJUDA_FORMATO)

    def processAlgorithm(self, parameters, context, feedback):  # noqa: N802
        _, caminho = self.montar_trabalho(parameters, context, feedback)
        return _executar_e_carregar(caminho, self.parameterAsBool(parameters, "CARREGAR", context), context, feedback)


class AlgTrabalhoJson(_Base):
    def name(self):
        return "processar_json"

    def displayName(self):  # noqa: N802
        return _tr("3. Processar a partir de arquivo de trabalho (JSON)")

    def flags(self):
        return super().flags() | QgsProcessingAlgorithm.FlagNoThreading

    def shortHelpString(self):  # noqa: N802
        return ("<p>Executa um arquivo de trabalho JSON (o mesmo formato da linha de comando), útil para "
                "repetir uma análise, usar ETA de um mês por arquivo, estilos QML ou parâmetros avançados.</p>"
                + AJUDA_COMUM)

    def initAlgorithm(self, config=None):  # noqa: N802
        self.addParameter(QgsProcessingParameterFile("TRABALHO", _tr("Arquivo de trabalho (JSON)"),
                                                     fileFilter="JSON (*.json)"))
        self.addParameter(QgsProcessingParameterBoolean("CARREGAR", _tr("Carregar os rasters corrigidos no projeto"),
                                                        defaultValue=True))
        self.addOutput(QgsProcessingOutputString("SITUACAO", _tr("Situação")))
        self.addOutput(QgsProcessingOutputNumber("N_AVISOS", _tr("Número de avisos")))
        self.addOutput(QgsProcessingOutputFolder("SAIDA", _tr("Pasta de resultados")))
        for nome, rot in (("RELATORIO", "Relatório de validação"), ("MANIFESTO", "Manifesto"),
                          ("PROJETO", "Projeto QGIS com os layouts"), ("ZIP", "ZIP final")):
            self.addOutput(QgsProcessingOutputFile(nome, _tr(rot)))

    def processAlgorithm(self, parameters, context, feedback):  # noqa: N802
        caminho = Path(self.parameterAsFile(parameters, "TRABALHO", context))
        return _executar_e_carregar(caminho, self.parameterAsBool(parameters, "CARREGAR", context), context, feedback)


FIGURA_FORMATO = Path(__file__).parent / "formato_planilha.png"

AJUDA_FORMATO = (
    "<p><b>Formato obrigatório: uma linha para cada valor mensal</b> (estação × variável × ano × mês). "
    "Não use meses em colunas (Jan, Fev, …).</p>"
    "<p><b>Colunas obrigatórias:</b> estacao_id, lon, lat, variavel (tmin, tmax ou prec), tipo_dado (serie ou "
    "normal), mes (1–12), valor, unidade (°C ou mm). <b>ano</b> é obrigatório para séries; <b>periodo_normal</b> "
    "(ex.: 1981-2010), para normais.</p>"
    "<p><b>Valores:</b> temperaturas = média mensal em °C; precipitação = total mensal em mm; decimal com vírgula "
    "ou ponto.</p>"
    "<p><b>Normais:</b> informe todos os períodos disponíveis de cada estação (1961-1990, 1981-2010, 1991-2020). "
    "Para cada período, o motor faz a média de todas as estações da localidade; a taxa por década é a reta dessas "
    "médias (Lima et al., 2026, seção 2.7) e a referência da correção é o valor em 1985, centro de 1970–2000. "
    "<b>tmed</b> e <b>etp</b> são aceitas para tendências e avaliação; <b>regiao</b> (ex.: interior, litoral) "
    "faz a média por sub-região.</p>"
    "<p><b>Também vale:</b> colunas em qualquer ordem; colunas extras são ignoradas; opcionais: nome, local_id "
    "(estações no mesmo local contam como uma), fonte, dias_faltantes; arquivo .xlsx, .ods ou .csv.</p>")


def _wrapper_figura():
    """Classe de widget que mostra a figura do formato da planilha no formulário do algoritmo.
    Retorna None fora do QGIS Desktop (ex.: qgis_process), onde o parâmetro aparece como texto comum."""
    try:
        from processing.gui.wrappers import DIALOG_STANDARD, WidgetWrapper
        from qgis.PyQt.QtCore import Qt
        from qgis.PyQt.QtGui import QPixmap
        from qgis.PyQt.QtWidgets import QDialog, QLabel, QPushButton, QSizePolicy, QVBoxLayout, QWidget
    except Exception:  # noqa: BLE001
        return None

    class _Figura(WidgetWrapper):
        def createWidget(self, **kwargs):  # noqa: N802
            if self.dialogType != DIALOG_STANDARD:
                return QLabel("—")
            px = QPixmap(str(FIGURA_FORMATO))
            if px.isNull():
                rot = QLabel(AJUDA_FORMATO)
                rot.setWordWrap(True)
                return rot
            caixa = QWidget()
            lay = QVBoxLayout(caixa)
            lay.setContentsMargins(0, 0, 0, 0)
            # versão compacta (≈ 630 px), suavizada, para o campo de salvar ficar à vista
            mini = px.scaledToWidth(int(px.width() / 1.2), Qt.SmoothTransformation)
            mini.setDevicePixelRatio(2.0)
            rot = QLabel()
            rot.setPixmap(mini)
            rot.setToolTip("Formato da planilha de dados observados")
            lay.addWidget(rot)
            bt = QPushButton("Ampliar figura…")
            bt.setSizePolicy(QSizePolicy.Maximum, QSizePolicy.Fixed)
            bt.clicked.connect(lambda: self._ampliar(px))
            lay.addWidget(bt)
            return caixa

        def _ampliar(self, px):
            d = QDialog(self.widget)
            d.setWindowTitle("Formato da planilha de dados observados")
            v = QVBoxLayout(d)
            grande = px.scaledToWidth(int(px.width() / 1.5 * 2), Qt.SmoothTransformation)
            grande.setDevicePixelRatio(2.0)
            rot = QLabel()
            rot.setPixmap(grande)
            v.addWidget(rot)
            d.exec_()

        def createLabel(self):  # noqa: N802
            if self.dialogType != DIALOG_STANDARD:
                return None
            return QLabel("<b>Como preencher a planilha</b> · onde salvar: campo <b>Salvar planilha-modelo como…</b>, "
                          "abaixo")

        def value(self):
            return ""

        def setValue(self, value):  # noqa: N802
            pass

    return _Figura


class AlgModeloPlanilha(_Base):
    def name(self):
        return "planilha_modelo"

    def displayName(self):  # noqa: N802
        return _tr("0. Gerar planilha-modelo de dados observados")

    def shortHelpString(self):  # noqa: N802
        return ("<p>Cria uma planilha vazia (.xlsx ou .csv) no formato que o AdaptaHorts lê. Escolha onde salvar em "
                "<b>Salvar planilha-modelo como</b>, clique em Executar, apague as linhas de exemplo (fictícias) e "
                "preencha com os dados das estações (INMET/BDMEP). Depois informe a planilha em <b>1. Validar</b> e "
                "<b>2. Processar</b>.</p>" + AJUDA_FORMATO +
                f"<p><b>Responsabilidade.</b> {AVISO_RESPONSABILIDADE_PT}</p>")

    def initAlgorithm(self, config=None):  # noqa: N802
        fig = QgsProcessingParameterString("FORMATO", _tr("Como preencher a planilha"), optional=True,
                                           defaultValue="")
        classe = _wrapper_figura()
        if classe is not None:
            fig.setMetadata({"widget_wrapper": {"class": classe}})
        self.addParameter(fig)
        docs = Path.home() / "Documents"
        pasta = docs if docs.is_dir() else Path.home()
        self.addParameter(QgsProcessingParameterFileDestination(
            "DESTINO", _tr("Salvar planilha-modelo como…"), fileFilter="Excel (*.xlsx);;CSV (*.csv)",
            defaultValue=str(pasta / "planilha_modelo_adaptahorts.xlsx")))
        self.addParameter(QgsProcessingParameterBoolean("ABRIR", _tr("Abrir a planilha ao terminar"),
                                                        defaultValue=True))
        self.addOutput(QgsProcessingOutputFile("PLANILHA", _tr("Planilha-modelo")))

    def processAlgorithm(self, parameters, context, feedback):  # noqa: N802
        from .motor_mapeamento.observados import criar_modelo_planilha
        destino = Path(self.parameterAsFileOutput(parameters, "DESTINO", context))
        if destino.suffix.lower() not in (".xlsx", ".csv"):
            destino = destino.with_suffix(".xlsx")
        if destino.exists():  # nunca sobrescreve uma planilha (pode já estar preenchida)
            n = 2
            while (alt := destino.with_name(f"{destino.stem} ({n}){destino.suffix}")).exists():
                n += 1
            feedback.pushWarning(f"{destino.name} já existe e não foi alterada; nova planilha salva como {alt.name}.")
            destino = alt
        destino.parent.mkdir(parents=True, exist_ok=True)
        criar_modelo_planilha(destino)
        feedback.pushInfo(f"Planilha-modelo criada: {destino}")
        self._abrir = destino if self.parameterAsBool(parameters, "ABRIR", context) else None
        return {"DESTINO": str(destino), "PLANILHA": str(destino)}

    def postProcessAlgorithm(self, context, feedback):  # noqa: N802
        if getattr(self, "_abrir", None):
            from qgis.PyQt.QtCore import QUrl
            from qgis.PyQt.QtGui import QDesktopServices
            if not QDesktopServices.openUrl(QUrl.fromLocalFile(str(self._abrir))):
                feedback.pushInfo(f"Abra a planilha em: {self._abrir}")
        return {}
