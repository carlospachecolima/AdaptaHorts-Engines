"""Testes do complemento instalado a partir do ZIP, com QGIS sem tela (offscreen).

Execução: ADAPTAHORTS_ZIP=dist/adaptahorts_qgis_v0.6.0.zip python -m pytest testes
"""
from __future__ import annotations

import json
import os
import sys
import zipfile
from pathlib import Path

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
from qgis.core import (QgsApplication, QgsProcessingContext, QgsProcessingException,  # noqa: E402
                       QgsProcessingFeedback, QgsProject, QgsRasterLayer, QgsVectorLayer)

AQUI = Path(__file__).parent
sys.path.insert(0, str(AQUI.parent.parent / "motor_adaptahorts" / "tests"))
import dados_sinteticos as ds  # noqa: E402


@pytest.fixture(scope="session")
def qgis_app(tmp_path_factory):
    QgsApplication.setPrefixPath("/usr", True)
    app = QgsApplication([], True)  # com GUI (offscreen), como no QGIS Desktop
    app.initQgis()
    sys.path.insert(0, "/usr/share/qgis/python/plugins")
    from processing.core.Processing import Processing
    Processing.initialize()
    # "Instala" o complemento a partir do ZIP numa pasta de complementos.
    plugins = tmp_path_factory.mktemp("perfil") / "python" / "plugins"
    plugins.mkdir(parents=True)
    with zipfile.ZipFile(os.environ.get("ADAPTAHORTS_ZIP", AQUI.parent / "dist" / "adaptahorts_qgis_v0.6.0.zip")) as z:
        z.extractall(plugins)
    sys.path.insert(0, str(plugins))
    yield app


class _IfaceFalsa:
    """Substitui o QgisInterface: registra os itens de menu e a barra de ferramentas."""

    def __init__(self):
        from qgis.PyQt.QtWidgets import QMainWindow
        self._janela = QMainWindow()
        self.menu: dict[str, list] = {}
        self.barra: list = []

    def mainWindow(self):  # noqa: N802
        return self._janela

    def addPluginToMenu(self, nome, acao):  # noqa: N802
        self.menu.setdefault(nome, []).append(acao)

    def removePluginMenu(self, nome, acao):  # noqa: N802
        self.menu[nome].remove(acao)

    def addToolBarIcon(self, acao):  # noqa: N802
        self.barra.append(acao)

    def removeToolBarIcon(self, acao):  # noqa: N802
        self.barra.remove(acao)


@pytest.fixture(scope="session")
def plugin(qgis_app):
    import adaptahorts
    iface = _IfaceFalsa()
    p = adaptahorts.classFactory(iface)
    p.initGui()
    yield p, iface
    p.unload()
    assert not iface.barra and not any(iface.menu.values())
    assert QgsApplication.processingRegistry().providerById("adaptahorts") is None


@pytest.fixture(scope="session")
def dados(tmp_path_factory, qgis_app):
    pasta = tmp_path_factory.mktemp("dados")
    trabalho = json.loads(ds.gerar(pasta).read_text())
    return pasta, trabalho


def _params(pasta: Path, trabalho: dict, saida: Path, **extra) -> dict:
    area = QgsVectorLayer(str(pasta / trabalho["area"]), "area", "ogr")
    assert area.isValid()
    QgsProject.instance().addMapLayer(area)
    p = {
        "AREA": area,
        "WC_HIST": [str(pasta / x) for x in trabalho["worldclim_historico"]],
        "WC_PROJ": [str(pasta / x) for x in trabalho["worldclim_projecao"]],
        "OBS": str(pasta / "observados.csv"),
        "FONTE": "Dados sintéticos de teste", "TIPO": 2, "POLITICA": 1, "RESPONSABILIDADE": True,
        "ETA_TMIN": [str(pasta / "eta/eta_hadgem2es_tmin_1961-2005.tif")],          # 12 bandas
        "ETA_TMAX": sorted(str(f) for f in (pasta / "eta").glob("Modelo_Regional_Eta_*Mensal_*.tif")),  # mensais (INPE)
        "ETA_PREC": [str(pasta / "eta/eta_hadgem2es_prec_1961-2005.tif")],
        "ETA_PERIODO": "1961-2005", "ETA_UNID_TEMP": 0, "ETA_UNID_PREC": 0,
        "SAIDA": str(saida),
    }
    p.update(extra)
    return p


def test_metadata_e_registro(plugin):
    p, iface = plugin
    meta = (Path(sys.modules["adaptahorts"].__file__).parent / "metadata.txt").read_text()
    for chave in ("name=", "qgisMinimumVersion=", "description=", "version=0.6.0", "author=", "email=",
                  "hasProcessingProvider=yes", "icon=icon.png"):
        assert chave in meta
    reg = QgsApplication.processingRegistry()
    prov = reg.providerById("adaptahorts")
    assert prov is not None
    assert sorted(a.id() for a in prov.algorithms()) == [
        "adaptahorts:calcular_paerc", "adaptahorts:indices_ameaca", "adaptahorts:iscc", "adaptahorts:isdh",
        "adaptahorts:isoc", "adaptahorts:issa", "adaptahorts:planilha_modelo", "adaptahorts:processar",
        "adaptahorts:processar_json", "adaptahorts:questionario_paerc", "adaptahorts:risco_climatico",
        "adaptahorts:validar"]
    assert len(p.acoes) == 13 and len(iface.menu["&AdaptaHorts"]) == 13 and len(iface.barra) == 1
    assert [a.text() for a in iface.menu["&AdaptaHorts"]][2] == "Processar…"


def test_sem_dependencias_externas(plugin):
    proibidas = {"rasterio", "geopandas", "pandas", "shapely", "pyproj", "openpyxl", "affine", "fiona"}
    raiz = Path(sys.modules["adaptahorts"].__file__).parent
    for py in raiz.rglob("*.py"):
        texto = py.read_text(encoding="utf-8")
        for mod in proibidas:
            assert f"import {mod}" not in texto and f"from {mod}" not in texto, (py, mod)


def test_planilha_modelo(plugin, tmp_path):
    import processing
    r = processing.run("adaptahorts:planilha_modelo", {"DESTINO": str(tmp_path / "modelo.xlsx"), "ABRIR": False})
    assert Path(r["DESTINO"]).exists()
    from adaptahorts.motor_mapeamento.observados import ler_planilha
    linhas = ler_planilha(Path(r["DESTINO"]))
    assert len(linhas) == 3 and linhas[0]["estacao_id"] == "82994"
    # nunca sobrescreve uma planilha existente
    r2 = processing.run("adaptahorts:planilha_modelo", {"DESTINO": str(tmp_path / "modelo.xlsx"), "ABRIR": False})
    assert Path(r2["DESTINO"]).name == "modelo (2).xlsx" and Path(r2["DESTINO"]).exists()


def test_planilha_modelo_figura_no_formulario(plugin):
    """O formulário mostra a figura do formato da planilha (widget próprio no diálogo padrão)."""
    from processing.gui.AlgorithmDialog import AlgorithmDialog
    from qgis.PyQt.QtWidgets import QLabel
    alg = QgsApplication.processingRegistry().algorithmById("adaptahorts:planilha_modelo")
    fig = Path(sys.modules["adaptahorts"].__file__).parent / "formato_planilha.png"
    assert fig.exists()
    p = alg.parameterDefinition("FORMATO")
    assert "widget_wrapper" in p.metadata()
    dlg = AlgorithmDialog(alg.create())
    from qgis.PyQt.QtWidgets import QPushButton
    rotulos = [w for w in dlg.findChildren(QLabel) if w.pixmap() is not None and not w.pixmap().isNull()]
    assert any(l.pixmap().width() == 1266 for l in rotulos)
    assert any(b.text() == "Ampliar figura…" for b in dlg.findChildren(QPushButton))
    assert alg.parameterDefinition("DESTINO").description().startswith("Salvar planilha-modelo como")
    assert "uma linha para cada valor mensal" in alg.shortHelpString()
    val = QgsApplication.processingRegistry().algorithmById("adaptahorts:validar")
    assert val.parameterDefinition("NORMAIS").defaultValue() == 0
    assert val.parameterDefinition("NORMAIS").options()[0].startswith("Taxa por década das normais")
    assert val.parameterDefinition("TAXA_ESTACOES") is not None
    dlg.close()


def test_validar_sem_responsabilidade_falha(plugin, dados, tmp_path):
    import processing
    pasta, t = dados
    fb = QgsProcessingFeedback()
    with pytest.raises(QgsProcessingException):
        processing.run("adaptahorts:validar", _params(pasta, t, tmp_path / "v", RESPONSABILIDADE=False), feedback=fb)


def test_validar_politica_perguntar(plugin, dados, tmp_path):
    import processing
    pasta, t = dados
    with pytest.raises(QgsProcessingException) as e:
        processing.run("adaptahorts:validar", _params(pasta, t, tmp_path / "p", POLITICA=0))
    assert "Manter" in str(e.value)


def test_validar_e_processar_mesma_pasta(plugin, dados, tmp_path):
    import processing
    pasta, t = dados
    saida = tmp_path / "resultado"
    r = processing.run("adaptahorts:validar", _params(pasta, t, saida))
    assert r["SITUACAO"] == "valido" and (saida / "validacao_preliminar.json").exists()

    ctx = QgsProcessingContext()
    ctx.setProject(QgsProject.instance())
    marcas = []
    fb = QgsProcessingFeedback()
    fb.progressChanged.connect(marcas.append)
    r = processing.run("adaptahorts:processar",
                       _params(pasta, t, saida, SIMBOLOGIA="tmin=18:28; tmax=26:38; prec=0:150", CARREGAR=True),
                       context=ctx, feedback=fb)
    assert r["SITUACAO"].startswith("concluído")
    man = json.loads(Path(r["MANIFESTO"]).read_text())
    assert man["interface"]["nome"] == "complemento QGIS AdaptaHorts"
    assert man["mapas"]["n_mapas"] == 72 and Path(r["PROJETO"]).exists() and Path(r["ZIP"]).exists()
    assert "trabalho.json" in man["saidas_sha256"] and "entradas/area_estudo.gpkg" in man["saidas_sha256"]
    assert {v: a["status"] for v, a in man["avaliacao_comparativa_eta"].items()} == \
           {"prec": "validado", "tmax": "validado", "tmin": "validado"}
    assert all(a["n_meses"] == 12 for a in man["avaliacao_comparativa_eta"].values())
    assert len([e for e in man["entradas"]["eta_historico"] if e["variavel"] == "tmax"]) == 12
    assert marcas and marcas == sorted(marcas) and max(marcas) >= 97
    # 36 rasters corrigidos agendados para carregar, com simbologia do AdaptaHorts
    carregar = ctx.layersToLoadOnCompletion()
    assert len(carregar) == 36
    caminho, det = next(iter(carregar.items()))
    lyr = QgsRasterLayer(caminho, det.name, "gdal")
    det.postProcessor().postProcessLayer(lyr, ctx, fb)
    assert lyr.renderer().type() == "singlebandpseudocolor"
    sh = lyr.renderer().shader().rasterShaderFunction()
    var = Path(caminho).parent.name
    assert (sh.minimumValue(), sh.maximumValue()) == {"tmin": (18, 28), "tmax": (26, 38), "prec": (0, 150)}[var]
    # o projeto gerado abre e contém os 72 layouts
    pr = QgsProject()
    assert pr.read(r["PROJETO"])
    assert len(pr.layoutManager().layouts()) == 72


def test_cancelamento_remove_parciais(plugin, dados, tmp_path):
    import processing
    pasta, t = dados
    saida = tmp_path / "cancelado"
    fb = QgsProcessingFeedback()
    fb.progressChanged.connect(lambda v: fb.cancel() if v > 20 else None)
    with pytest.raises(QgsProcessingException) as e:
        processing.run("adaptahorts:processar", _params(pasta, t, saida, GERAR_MAPAS=False, CARREGAR=False),
                       feedback=fb)
    assert "cancelado" in str(e.value)
    assert not (saida / "rasters").exists() and not (saida / "manifesto.json").exists()


def test_processar_json(plugin, dados, tmp_path):
    import processing
    pasta, t = dados
    t = dict(t, saida=str(tmp_path / "json"))
    t["parametros"] = dict(t["parametros"], gerar_mapas=False)
    for k in ("worldclim_historico", "worldclim_projecao"):
        t[k] = [str(pasta / x) for x in t[k]]
    t["area"] = str(pasta / t["area"])
    t["observados"] = dict(t["observados"], arquivo=str(pasta / t["observados"]["arquivo"]))
    t["eta_historico"] = [dict(e, arquivo=str(pasta / e["arquivo"])) for e in t["eta_historico"]]
    j = tmp_path / "trabalho_teste.json"
    j.write_text(json.dumps(t, ensure_ascii=False))
    r = processing.run("adaptahorts:processar_json", {"TRABALHO": str(j), "CARREGAR": False})
    assert r["SITUACAO"].startswith("concluído")


# ----------------------------------------------------------------------------- módulo de risco

@pytest.fixture(scope="session")
def mapeamento_plugin(plugin, dados, tmp_path_factory):
    import processing
    pasta, t = dados
    saida = tmp_path_factory.mktemp("map") / "resultado"
    processing.run("adaptahorts:processar", _params(pasta, t, saida, GERAR_MAPAS=False, CARREGAR=False))
    return saida


@pytest.fixture(scope="session")
def questionario_preenchido(plugin, tmp_path_factory):
    """Gera o questionário pelo R1 e o preenche como se fosse a coleta em campo (pontos)."""
    import processing
    sys.path.insert(0, str(AQUI.parent.parent / "motor_adaptahorts" / "tests"))
    sys.path.append(str(AQUI.parent.parent / "motor_adaptahorts"))  # dados_risco usa a lista de campos do motor
    import dados_risco as dr
    from osgeo import ogr
    pasta = tmp_path_factory.mktemp("quest")
    r = processing.run("adaptahorts:questionario_paerc", {"FORMATO": 2, "PASTA": str(pasta), "CARREGAR": False})
    gpkg = Path(r["GPKG"])
    linhas = dr.gerar_questionarios(pasta / "tmp.csv")
    d = ogr.Open(str(gpkg), 1)
    lyr = d.GetLayerByName("questionario_paerc")
    rng = __import__("random").Random(3)
    for l in linhas:
        f = ogr.Feature(lyr.GetLayerDefn())
        regiao = "Região Oeste" if l["id_questionario"].startswith("OES") else "Região Leste"
        xs = [x for x, _ in dr.REGIOES[regiao]]
        for k, v in l.items():
            if k in ("lon", "lat", "microrregiao") or v == "":
                continue
            f.SetField(k, v)
        g = ogr.Geometry(ogr.wkbPoint)
        g.AddPoint_2D(rng.uniform(min(xs) + 0.05, max(xs) - 0.05), rng.uniform(-10.5, -9.6))
        f.SetGeometry(g)
        lyr.CreateFeature(f)
    d = None
    dr._gpkg_regioes(pasta / "microrregioes.gpkg")
    return gpkg, pasta / "microrregioes.gpkg", Path(r["XLSX"])


def test_r1_formulario(questionario_preenchido):
    gpkg, _, xlsx = questionario_preenchido
    lyr = QgsVectorLayer(f"{gpkg}|layername=questionario_paerc", "q", "ogr")
    assert lyr.isValid() and lyr.featureCount() == 16
    cfg = lyr.editFormConfig()
    assert [t.name() for t in cfg.tabs()][:4] == ["Identificação", "Econômica (CE)", "Técnica (CT)", "Institucional (CI)"]
    assert lyr.editorWidgetSetup(lyr.fields().indexOf("caf")).type() == "ValueMap"
    assert xlsx.exists()


def test_r2_paerc(questionario_preenchido, tmp_path):
    import processing
    gpkg, regioes, _ = questionario_preenchido
    q = QgsVectorLayer(f"{gpkg}|layername=questionario_paerc", "q", "ogr")
    reg = QgsVectorLayer(str(regioes), "regioes", "ogr")
    r = processing.run("adaptahorts:calcular_paerc", {"QUESTIONARIOS_CAMADA": q, "MICRORREGIOES": reg,
                                                      "CAMPO_NOME": "nome", "BOOTSTRAP": 1000,
                                                      "SAIDA": str(tmp_path / "paerc"), "CARREGAR": False})
    assert r["N_QUESTIONARIOS"] == 16
    out = QgsVectorLayer(f"{r['MICRORREGIOES_PAERC']}|layername=microrregioes_paerc", "p", "ogr")
    vals = {f["microrregiao"]: f["paerc"] for f in out.getFeatures()}
    assert vals["Região Oeste"] == pytest.approx(11 / 12)
    assert vals["Região Leste"] == pytest.approx(0.473 * 0.25 / 3 + 0.388 * 0.5 / 3 + 0.139 * 0.5 / 3)


def test_r3_risco(mapeamento_plugin, questionario_preenchido, tmp_path):
    import processing
    from qgis.core import QgsProcessingContext
    gpkg, regioes, _ = questionario_preenchido
    sys.path.insert(0, str(AQUI.parent.parent / "motor_adaptahorts" / "tests"))
    import dados_risco as dr
    dr.gerar_ce(tmp_path / "ce.tif")
    ctx = QgsProcessingContext()
    ctx.setProject(QgsProject.instance())
    r = processing.run("adaptahorts:risco_climatico", {
        "MAPEAMENTO": str(mapeamento_plugin), "EXPOSICAO_MODO": 0, "ADOCAO": 0.10,
        "QUESTIONARIOS_CAMADA": QgsVectorLayer(f"{gpkg}|layername=questionario_paerc", "q", "ogr"),
        "MICRORREGIOES": QgsVectorLayer(str(regioes), "regioes", "ogr"), "CAMPO_NOME": "nome",
        "BOOTSTRAP": 1000, "CE": str(tmp_path / "ce.tif"), "GERAR_MAPAS": True, "CARREGAR": True,
        "SAIDA": str(tmp_path / "risco")}, context=ctx)
    assert r["SITUACAO"].startswith("concluído")
    man = json.loads(Path(r["MANIFESTO"]).read_text())
    assert man["interface"]["nome"].startswith("complemento QGIS AdaptaHorts")
    assert man["mapas"]["n_mapas"] == 32  # 8 produtos × 2 períodos × 2 idiomas
    assert man["resumo_cenarios"][0]["exposicao"] == pytest.approx(0.90)
    for rel, h in man["saidas_sha256"].items():
        import hashlib
        assert hashlib.sha256((Path(r["SAIDA"]) / rel).read_bytes()).hexdigest() == h, rel
    # padrão: ISOC, ISDH, ISCC, ISSA, ameaça, risco e classes, nos dois períodos
    carregadas = ctx.layersToLoadOnCompletion()
    assert len(carregadas) == 14
    assert any(Path(c).stem.endswith("_isoc") for c in carregadas) and any(Path(c).stem.endswith("_iscc") for c in carregadas)
    pr = QgsProject()
    assert pr.read(str(next((Path(r["SAIDA"]) / "projeto_qgis").glob("*.qgz"))))
    assert len(pr.layoutManager().layouts()) == 32


def test_r3_indices(mapeamento_plugin, tmp_path):
    """Só os índices (sem exposição nem PAERC), sem CE medida: ISSA = suscetibilidade climática."""
    import processing
    from qgis.core import QgsProcessingContext
    ctx = QgsProcessingContext()
    ctx.setProject(QgsProject.instance())
    alg = QgsApplication.processingRegistry().algorithmById("adaptahorts:indices_ameaca")
    nomes = [d.name() for d in alg.parameterDefinitions()]
    assert {"PESO_ISOC", "PESO_ISDH", "PESO_ISCC", "PESO_ISSA"} <= set(nomes)
    assert "EXPOSICAO_MODO" not in nomes and "QUESTIONARIOS_CAMADA" not in nomes
    r = processing.run("adaptahorts:indices_ameaca", {
        "MAPEAMENTO": str(mapeamento_plugin), "PESO_ISOC": 0.4, "PESO_ISDH": 0.3, "PESO_ISCC": 0.3, "PESO_ISSA": 0.0,
        "GERAR_MAPAS": True, "SAIDA": str(tmp_path / "indices")}, context=ctx)
    man = json.loads(Path(r["MANIFESTO"]).read_text())
    assert man["pesos_ameaca_usados"] == pytest.approx({"isoc": 0.4, "isdh": 0.3, "iscc": 0.3})
    assert man["mapas"]["n_mapas"] == 24  # ISOC, ISDH, ISCC, ISSA, CE máx. da água, ameaça × 2 períodos × 2 idiomas
    assert not any("PAERC" in a for a in man["avisos"])
    for l in man["resumo_cenarios"]:
        assert all(l[k] is not None for k in ("isoc", "isdh", "iscc", "issa", "ameaca"))
    assert len(ctx.layersToLoadOnCompletion()) == 12
    rel = (Path(r["SAIDA"]) / "relatorio_risco.md").read_text(encoding="utf-8")
    assert rel.startswith("# Índices de ameaça climática")


@pytest.mark.parametrize("ind,pesos", [("isoc", (0.460, 0.352, 0.188)), ("isdh", (0.446, 0.354, 0.200)),
                                       ("iscc", (0.372, 0.231, 0.397)), ("issa", (0.432, 0.406, 0.162))])
def test_algoritmo_por_indice(mapeamento_plugin, tmp_path, ind, pesos):
    import processing
    from qgis.core import QgsProcessingContext
    alg = QgsApplication.processingRegistry().algorithmById(f"adaptahorts:{ind}")
    defs = {d.name(): d for d in alg.parameterDefinitions()}
    assert tuple(defs[f"PESO_{c}"].defaultValue() for c in "IDC") == pesos
    assert "PESO_ISOC" not in defs and "QUESTIONARIOS_CAMADA" not in defs and "EXPOSICAO_MODO" not in defs
    assert ("CE" in defs) == (ind == "issa")
    ctx = QgsProcessingContext()
    ctx.setProject(QgsProject.instance())
    r = processing.run(f"adaptahorts:{ind}", {"MAPEAMENTO": str(mapeamento_plugin), "GERAR_MAPAS": ind == "isdh",
                                              "SAIDA": str(tmp_path / ind)}, context=ctx)
    man = json.loads(Path(r["MANIFESTO"]).read_text())
    assert man["indice"] == ind and man["parametros_efetivos"]["pesos"][ind] == dict(zip("IDC", pesos))
    assert man["interface"]["nome"].endswith(ind.upper())
    assert Path(r["RELATORIO"]).name == f"relatorio_{ind}.md"
    assert 0 <= r["INDICE_HISTORICO"] <= 1 and 0 <= r["INDICE_PROJECAO"] <= 1
    stems = [Path(c).stem for c in ctx.layersToLoadOnCompletion()]
    for x in (ind, f"{ind}_I", f"{ind}_D", f"{ind}_C"):
        assert sum(st.endswith(f"_{x}") for st in stems) == 2, x  # histórico e projeção
    assert not any(st.endswith(("_ameaca", "_risco")) for st in stems)
    if ind == "isdh":
        assert man["mapas"]["n_mapas"] == 16  # índice + I, D, C × 2 períodos × 2 idiomas
        pr = QgsProject()
        assert pr.read(str(next((Path(r["SAIDA"]) / "projeto_qgis").glob("isdh_*.qgz"))))


def test_indice_pesos_normalizados(mapeamento_plugin, tmp_path):
    import processing
    r = processing.run("adaptahorts:isoc", {"MAPEAMENTO": str(mapeamento_plugin), "PESO_I": 0.6, "PESO_D": 0.3,
                                            "PESO_C": 0.3, "GERAR_MAPAS": False, "CARREGAR": False,
                                            "SAIDA": str(tmp_path / "w")})
    man = json.loads(Path(r["MANIFESTO"]).read_text())
    assert man["parametros_efetivos"]["pesos"]["isoc"] == pytest.approx({"I": 0.5, "D": 0.25, "C": 0.25})


def test_r2_pesos_paerc(questionario_preenchido, tmp_path):
    import processing
    gpkg, regioes, _ = questionario_preenchido
    alg = QgsApplication.processingRegistry().algorithmById("adaptahorts:calcular_paerc")
    defs = {d.name(): d for d in alg.parameterDefinitions()}
    assert (defs["PESO_CE"].defaultValue(), defs["PESO_CT"].defaultValue(), defs["PESO_CI"].defaultValue()) == (0.473, 0.388, 0.139)
    r = processing.run("adaptahorts:calcular_paerc", {
        "QUESTIONARIOS_CAMADA": QgsVectorLayer(f"{gpkg}|layername=questionario_paerc", "q", "ogr"),
        "MICRORREGIOES": QgsVectorLayer(str(regioes), "regioes", "ogr"), "CAMPO_NOME": "nome", "BOOTSTRAP": 0,
        "PESO_CE": 1, "PESO_CT": 0, "PESO_CI": 0, "SAIDA": str(tmp_path / "p"), "CARREGAR": False})
    out = QgsVectorLayer(f"{r['MICRORREGIOES_PAERC']}|layername=microrregioes_paerc", "p", "ogr")
    vals = {f["microrregiao"]: f["paerc"] for f in out.getFeatures()}
    assert vals["Região Leste"] == pytest.approx(0.25 / 3)
