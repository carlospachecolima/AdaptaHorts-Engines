# Motor de mapeamento climático — AdaptaHorts (v0.6.0)

O motor corrige projeções CMIP6 do WorldClim v2.1 com dados observados do INMET/BDMEP, pelo método Delta regional de Lima et al. (2026), *Land Degradation & Development*, seção 2.6. Ele também:

- avalia o WorldClim histórico contra o ETA-HadGEM2-ES (seção 2.8);
- calcula estatísticas;
- gera rasters corrigidos e mapas bilíngues em PyQGIS;
- produz um relatório de validação e um manifesto com SHA-256.

O núcleo de cálculo não depende do QGIS. Só o módulo `layouts_qgis.py` usa PyQGIS, e o mesmo motor pode ser chamado pela linha de comando, pela API web ou pelo complemento QGIS.

## Instalação

- **Cálculo:** Python ≥ 3.9 com `numpy` e GDAL (`osgeo`). São as mesmas bibliotecas que acompanham o QGIS, então não há nada a instalar no QGIS. Em servidor, use o pacote GDAL do sistema ou do conda.
- **Mapas:** QGIS ≥ 3.30, com o mesmo Python do QGIS. Fora do QGIS, o motor roda sem interface gráfica (`QT_QPA_PLATFORM=offscreen`, já configurado no código).
- **Complemento QGIS:** veja `adaptahorts_qgis_v0.6.0.zip`, que já traz este motor.

Sem PyQGIS, o processamento termina normalmente, sem gerar os mapas, e o relatório registra isso. O motor não altera o modo de exceções do GDAL (configuração global que afetaria o QGIS e outros complementos).

## Uso

```bash
python -m motor_mapeamento modelo-planilha observados.xlsx   # planilha-modelo
python -m motor_mapeamento validar  trabalho.json            # validação preliminar, sem processar
python -m motor_mapeamento processar trabalho.json           # processamento completo
```

Códigos de saída: `0` = concluído; `2` = erros de validação, com a lista de correções; `3` = decisão necessária (por exemplo, o que fazer com estações abaixo do mínimo de anos).

## Entradas (um trabalho = uma combinação modelo–SSP–período)

| Entrada | Formato | Como o motor identifica |
|---|---|---|
| WorldClim histórico | GeoTIFF de 1 banda por variável e mês, ou ZIP com esses GeoTIFFs | Variável e mês pelo nome `wc2.1_30s_<tmin\|tmax\|prec>_<MM>.tif`, ou por `variavel`/`mes` informados |
| WorldClim projeção | GeoTIFF de 12 bandas por variável | Modelo, SSP e período pelo nome `wc2.1_30s_<var>_<MODELO>_<sspXYZ>_<AAAA-AAAA>.tif`, ou informados; banda = mês |
| ETA-HadGEM2-ES histórico | Um GeoTIFF por mês, como baixado do Portal de Projeções do INPE, ou um de 12 bandas | Variável e mês pelo nome do INPE (`..._Temperatura_Máxima_Mensal_Abril.tif`), ou `variavel`/`mes` informados; `unidade` e `periodo` são obrigatórios. Valores fora da faixa física (como −999000000, usado pelo INPE sem NoData declarado) contam como ausentes |
| Observados | Planilha-modelo `.xlsx` (aba `dados`) ou `.csv` | Colunas descritas na aba `colunas` da planilha-modelo |
| Área de estudo | Shapefile ou ZIP com `.shp`, `.shx`, `.dbf` e `.prj` | Polígonos; reprojetados para EPSG:4326 |

O motor analisa as variáveis e os meses para os quais há GeoTIFF histórico. Veja `exemplos/trabalho_exemplo.json`. Os caminhos são relativos à pasta do JSON.

## Regras aplicadas

- **Grade:** EPSG:4326, 30″ (1/120°). Todos os rasters WorldClim devem estar alinhados; não há reamostragem automática. Lê-se apenas a janela que cobre a área.
- **Pixels da área:** entra o pixel cujo centro está dentro do polígono (ou sobre a borda), regra do GDAL, a mesma do recorte no QGIS.
- **Média regional do raster:** `simples` por padrão, como no artigo; `ponderada_area` (cos lat) é opcional.
- **Observados:**
  - entram apenas os anos de 1970–2000;
  - o mínimo recomendado é de 20 anos válidos por estação, variável e mês;
  - abaixo do mínimo, a política padrão `perguntar` interrompe o processamento até o usuário escolher `manter` ou `excluir`;
  - numa normal, a sobreposição do período com 1970–2000 conta como anos válidos;
  - duplicatas idênticas são descartadas; valores conflitantes são erro;
  - estações com o mesmo `local_id` ou com coordenadas idênticas contam como um único local, e estações próximas (menos de 1 km) sem `local_id` comum são apenas sinalizadas;
  - a média regional dá peso igual a cada local, e o número de estações é livre;
  - estações fora da área são aceitas, com a distância registrada, a menos que se defina `distancia_max_estacao_km`.
- **Responsabilidade:** `observados.confirmo_responsabilidade = true` é obrigatório. O texto do aviso aparece no relatório, no manifesto e na planilha-modelo.
- **Delta:** `obs_regional − WorldClim_regional`, somado à projeção e ao histórico. A precipitação negativa é limitada a zero, com a contagem e a soma removida registradas. O método multiplicativo, só para precipitação, é opcional.
- **Diagnóstico pareado:** compara o WorldClim no pixel de cada estação com o valor observado. Serve apenas para o relatório e não altera os rasters.
- **ETA:**
  - o motor compara os meses que têm observado, WorldClim e ETA ao mesmo tempo, usando viés, MAE, RMSE e r de Pearson (r exige pelo menos 3 meses);
  - regra padrão: o WorldClim é validado se o MAE dele for menor ou igual ao do ETA (configurável em `regra_validacao_eta`);
  - a etapa adicional de correção baseada no ETA fica desativada.
- **Estatísticas:** mín., máx., amplitude, média, mediana, DP populacional, CV (só precipitação), IC95% da média, área (km²) e, se configurado, área por classe.
- **Simbologia:** limites fixos por variável em `parametros.simbologia` (recomendado para comparar cenários) ou estilo QML. Sem nenhum dos dois, usam-se os percentis 2–98 dos meses da análise, com aviso. Temperatura vai do frio (baixo) ao quente (alto); precipitação, do quente (baixo) ao frio (alto).
- **Mapas:** A4 paisagem, PDF e PNG a 300 dpi, em português e inglês. Cada mapa tem título, modelo/SSP/período, legenda, escala, norte, grade de coordenadas e fontes, com a resolução indicada como 30 segundos de arco. Com 3 variáveis × 12 meses × 2 idiomas, são 72 mapas. O projeto `.qgz` é salvo com caminhos relativos.

## Saídas

```
saida/
  rasters/projecao_corrigida/<var>/<periodo>_<SSP>_<modelo>_<var>_<MMMes>.tif
  rasters/historico_corrigido/<var>/Historico_1970-2000_<var>_<MMMes>.tif
  tabelas/  ajustes_delta, estatisticas, estacoes, valores_por_estacao,
            medias_regionais_observadas, diagnostico_pareado, avaliacao_eta_mensal, coerencia_tmin_tmax (.csv)
  mapas/<var>/<pt|en>/*.pdf|*.png
  projeto_qgis/*.qgz
  relatorio_validacao.md
  manifesto.json            # versões, parâmetros, metadados, ajustes, avisos, SHA-256 das entradas e saídas
saida.zip + saida.zip.sha256
```

Rasters e tabelas são reprodutíveis bit a bit para as mesmas entradas, versão e parâmetros. PDFs e PNGs podem variar em metadados internos do QGIS.

## Módulo de risco climático (`motor_mapeamento.risco`)

**Risco = Ameaça × Exposição × (1 − PAERC)**, com todos os termos em [0, 1]. A entrada climática é a pasta de resultados do mapeamento (histórico 1970–2000 e projeção corrigidos). Os índices são calculados para os dois períodos com os mesmos limiares, e a variação (projeção − histórico) sai em `rasters/variacao/`.

```bash
python -m motor_mapeamento questionario-paerc questionario_paerc.xlsx   # ou .gpkg (formulário QGIS/QField)
python -m motor_mapeamento risco trabalho_risco.json                     # ver exemplos/trabalho_risco_exemplo.json
python -m motor_mapeamento risco trabalho_risco.json --indice isdh       # só um índice: isoc, isdh, iscc ou issa
```

- **Índices**, com pesos = médias das distribuições bootstrap (100.000 iterações, IC 95%), não a coluna arredondada "Peso final" da Tabela 1: ISOC 0,460/0,352/0,188; ISDH 0,446/0,354/0,200 (figura do ISDH-Alface; a tabela-síntese traz 0,452/0,346/0,202); ISCC 0,372/0,231/0,397; ISSA 0,432/0,406/0,162 (Intensidade/Duração/Concentração).
- **Um índice por vez:** `parametros.indice` (ou `--indice`) calcula só o índice escolhido, com os componentes I, D e C, a variação, os mapas (índice e componentes) e o relatório `relatorio_<indice>.md`, sem exposição nem PAERC.
- **ET0:** Hargreaves–Samani, com Ra da FAO-56 no dia 15 de cada mês; ETc = ET0 × 1,00; irrigação bruta = déficit × 10 / 0,85.
- **Normalização:** limiares fixos (fisiológicos ou da literatura), iguais para o histórico e os cenários, para que os resultados sejam comparáveis entre períodos. Cada limiar e sua origem estão em `risco/config_risco.py`; os marcados como PROPOSTA precisam de revisão.
- **Ameaça:** média ponderada dos índices (padrão: pesos iguais).
- **ISSA:** sem dados de salinidade, é a **suscetibilidade climática à salinização**, calculada pelo balanço de sais em equilíbrio da FAO-29. A irrigação repõe o déficit, a drenagem é irrigação + chuva − ETc, e o fator de concentração é FC = ECe/ECw = [Irr/(Irr+P)]·(1+LF)/(5·LF). Com um raster de CE do solo medida, o ISSA passa a ser o estresse salino. Produtos auxiliares: FC, fração de lixiviação, ECe com água de referência (0,7 dS/m) e CE máxima da água de irrigação para a alface (1,5/FC).
- **Exposição:** 1 − adoção de sistemas conservacionistas (padrão: 10% de adoção, exposição 0,90). Também aceita um raster ou polígonos com valores de 0 a 1.
- **PAERC:** questionário estruturado (`risco/paerc.py`), com as faixas de pontuação do documento do PAERC. A pontuação é feita por propriedade; na microrregião, as faixas são aplicadas à mediana das respostas, e o IC 95% vem de bootstrap com semente fixa. PAERC (IPSV-AF) = 0,473·CE + 0,388·CT + 0,139·CI (médias do bootstrap com 10.000 iterações; IC 95%: CE 0,435–0,512, CT 0,348–0,427, CI 0,115–0,165). Itens do documento ainda sem faixas são registrados, mas não pontuam.
- **Classes:** 5 classes com limites configuráveis (padrão: intervalos iguais, PROPOSTA).
- **Saídas:**
  - rasters por período (índices e seus componentes I/D/C, ET0, ETc, déficit, irrigação, PCI, R, ISC, ameaça, exposição, PAERC, vulnerabilidade, risco potencial, risco e classes);
  - tabelas `resumo_cenarios.csv`, `paerc_propriedades.csv`, `paerc_microrregioes.csv` e `risco_microrregioes.csv`;
  - 36 layouts (9 produtos × 2 períodos × 2 idiomas), ou 32 com CE do solo medida (sem o mapa da CE máxima da água);
  - `relatorio_risco.md` e `manifesto_risco.json`, com SHA-256.

## Testes

```bash
python -m pytest tests
```

- `test_motor.py` usa dados sintéticos com resultado conhecido, calculado de forma independente do motor. Cobre o delta, o recorte, NoData, a limitação a zero, a avaliação ETA, os hashes, os 72 mapas, a reprodutibilidade, as políticas de anos mínimos, a confirmação de responsabilidade e a grade desalinhada.
- `test_referencia_ldd2026.py` confere as Tabelas 1, 2, 3 e 7 do artigo. Com dados reais, defina `ADAPTAHORTS_TRABALHO_REFERENCIA=/caminho/trabalho_LSF.json` para verificar se o motor reproduz o artigo.

## Ainda não implementado

- Etapa de correção adicional baseada no ETA (método a definir).
- API web, fila de tarefas e complemento QGIS. O motor já é a biblioteca que eles vão chamar.
- Tendências com normais de 1961–1990, 1981–2010 e 1991–2020 (seção 2.7) e índices (ETP de Hargreaves–Samani, IA, estação chuvosa), que ficam para o motor de índices.

## Integridade do pacote

`SHA256SUMS.txt` lista o SHA-256 de cada arquivo do pacote. Para conferir, na pasta `motor_adaptahorts`:

```bash
sha256sum -c SHA256SUMS.txt
```

O ZIP de distribuição tem o próprio hash em `motor_adaptahorts_v<versão>.zip.sha256`:

```bash
sha256sum -c adaptahorts_fonte_v0.6.0.zip.sha256
```

O ZIP é montado de forma determinística (ordem fixa e data fixa nos arquivos), então reempacotar os mesmos arquivos gera o mesmo hash. O hash garante integridade, não autoria.

## Histórico

- **0.6.0:** normais climatológicas com vários períodos: para cada período, média de todas as estações da localidade (peso igual por local e, com a coluna `regiao`, por sub-região); taxa por década pela reta dessas médias; cada normal é levada a 1985 (centro de 1970–2000) pela taxa e entra na referência do delta (Lima et al., 2026, seção 2.7). Parâmetros `normais_metodo` (`tendencia`, `media`, `unica`) e `normais_taxa_estacoes` (`todas`, `completas`). `tmed` e `etp` aceitas na planilha (tendências e avaliação). Nova tabela `tendencias_normais.csv`.
- **0.5.1:** no complemento, figura do formato da planilha de observados no formulário da planilha-modelo e regras na ajuda de Validar e Processar; a planilha-modelo nunca sobrescreve um arquivo existente.
- **0.5.0:** pesos padrão = médias do bootstrap (ISCC e ISSA mudam em relação à coluna arredondada; PAERC/IPSV-AF passa a 0,473/0,388/0,139); modo de índice único (`parametros.indice`, `--indice`); no complemento, um algoritmo para cada índice (ISOC, ISDH, ISCC, ISSA) e pesos do PAERC editáveis.
- **0.4.2:** modo só de índices (`parametros.somente_ameaca`) e escolha dos produtos com mapa (`mapas_produtos`); no complemento, algoritmo próprio para os índices, pesos visíveis e índices carregados no projeto.
- **0.4.1:** ISSA como suscetibilidade climática à salinização (FAO-29), sem exigir dados de salinidade.
- **0.4.0:** módulo de risco climático (ISOC, ISDH, ISCC, ISSA, ameaça, exposição, PAERC por questionário estruturado com formulário QGIS/QField, risco, classes, mapas e relatório).
- **0.3.1:** ETA aceito como um GeoTIFF por mês (formato do Portal de Projeções do INPE), com variável e mês lidos do nome, inclusive em ZIPs sem codificação UTF-8; código −999000000 e valores fisicamente impossíveis tratados como ausentes e contados no relatório.
- **0.3.0:** motor reescrito sobre GDAL/OGR e numpy (sem rasterio, geopandas, pandas, shapely e openpyxl), com resultados idênticos aos da 0.2.1; progresso e cancelamento; remoção de resultados parciais quando o processamento é interrompido; leitura de planilhas .ods; base do complemento QGIS.
- **0.2.1:** processar pode rodar no mesmo diretório da validação preliminar; `validacao_preliminar.json` passa a entrar no manifesto; hashes do pacote.
- **0.2.0:** primeira versão do motor.
