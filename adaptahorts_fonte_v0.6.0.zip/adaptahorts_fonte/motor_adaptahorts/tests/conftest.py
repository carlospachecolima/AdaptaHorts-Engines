import importlib.abc
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
sys.path.insert(0, str(Path(__file__).parent.parent))

# O motor deve funcionar só com numpy + GDAL (o que vem com o QGIS).
# Bloqueia bibliotecas que não acompanham o QGIS para garantir isso nos testes.
BLOQUEADAS = {"rasterio", "geopandas", "pandas", "shapely", "pyproj", "openpyxl", "affine", "fiona"}


class _Bloqueio(importlib.abc.MetaPathFinder):
    def find_spec(self, nome, caminho=None, alvo=None):
        if nome.split(".")[0] in BLOQUEADAS:
            raise ImportError(f"'{nome}' bloqueado nos testes: o motor deve depender só de numpy e GDAL")
        return None


sys.meta_path.insert(0, _Bloqueio())

# O QGIS e outros complementos podem deixar o GDAL com ou sem exceções ativadas.
# O motor precisa funcionar nos dois modos: ADAPTAHORTS_GDAL_EXCECOES=1 testa com exceções.
import os  # noqa: E402

from osgeo import gdal, ogr, osr  # noqa: E402

for _m in (gdal, ogr, osr):
    (_m.UseExceptions if os.environ.get("ADAPTAHORTS_GDAL_EXCECOES") == "1" else _m.DontUseExceptions)()
