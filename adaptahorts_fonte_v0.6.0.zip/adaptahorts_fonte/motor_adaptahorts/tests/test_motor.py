"""Testes ponta a ponta com dados sintéticos (resultado esperado calculado de forma independente)."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
import pytest
from osgeo import gdal

from motor_mapeamento.config import DecisaoNecessaria, ErroValidacao
from motor_mapeamento.entradas import sha256
from motor_mapeamento.pipeline import processar, validar

import dados_sinteticos as ds


@pytest.fixture(scope="module")
def conjunto(tmp_path_factory):
    pasta = tmp_path_factory.mktemp("sintetico")
    trabalho = ds.gerar(pasta)
    return pasta, trabalho


def _editar(trabalho: Path, destino: Path, **params) -> Path:
    d = json.loads(trabalho.read_text(encoding="utf-8"))
    d["saida"] = str(destino)
    for k, v in params.items():
        if k == "observados":
            d["observados"].update(v)
        else:
            d.setdefault("parametros", {})[k] = v
    novo = trabalho.parent / f"trabalho_{destino.name}.json"
    novo.write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")
    return novo


def _dentro_poligono(x: float, y: float, vert: list[tuple[float, float]], tol: float = 1e-9,
                     borda: bool = True) -> bool:
    """Ponto no polígono (raio) em Python puro; pontos a menos de tol da borda contam como `borda`."""
    n, dentro = len(vert), False
    for i in range(n):
        (x1, y1), (x2, y2) = vert[i], vert[(i + 1) % n]
        dx, dy = x2 - x1, y2 - y1
        t = max(0.0, min(1.0, ((x - x1) * dx + (y - y1) * dy) / (dx * dx + dy * dy)))
        if np.hypot(x - (x1 + t * dx), y - (y1 + t * dy)) < tol:
            return borda
        if (y1 > y) != (y2 > y) and x < x1 + (y - y1) * dx / dy:
            dentro = not dentro
    return dentro


def _ler_tif(caminho: Path):
    d = gdal.Open(str(caminho))
    b = d.GetRasterBand(1)
    arr = b.ReadAsArray().astype("float64")
    arr[arr == b.GetNoDataValue()] = np.nan
    return arr, d.GetGeoTransform(), d.GetProjection()


def _esperado(pasta: Path, var: str, mes: int) -> tuple[float, float]:
    """Delta esperado calculado sem o motor: média simples dos centros de pixel na área e
    média por local (A003/A004 co-localizadas) das médias de 1970–2000.
    Centros exatamente sobre a borda contam como dentro (regra do GDAL, a mesma do recorte no QGIS)."""
    arr = ds.campo(var, mes, False).astype("float64")
    arr[arr == np.float32(ds.NODATA_WC)] = np.nan
    lins, cols = np.mgrid[0:ds.H, 0:ds.W]
    lon = ds.X0 + (cols + 0.5) * ds.RES
    lat = ds.Y0 - (lins + 0.5) * ds.RES
    # centros sobre a borda (ruído de 1e-15) contam como dentro, como no GDAL
    dentro = np.array([_dentro_poligono(x, y, ds.AREA) for x, y in zip(lon.ravel(), lat.ravel())]).reshape(arr.shape)
    wc = np.nanmean(arr[dentro])
    with (pasta / "observados.csv").open(encoding="utf-8-sig") as f:
        linhas = list(csv.DictReader(f, delimiter=";"))
    unicas = {tuple(l.items()) for l in linhas}  # remove a duplicata idêntica
    por_est: dict[str, list[float]] = {}
    for l in map(dict, unicas):
        if l["variavel"] != var or int(l["mes"]) != mes:
            continue
        v = float(l["valor"].replace(",", "."))
        if l["tipo_dado"] == "serie":
            if not 1970 <= int(l["ano"]) <= 2000 or (l["dias_faltantes"] and float(l["dias_faltantes"]) > 10):
                continue
        por_est.setdefault(l["estacao_id"], []).append(v)
    por_est = {k: float(np.mean(v)) for k, v in por_est.items()}
    locais = {"A001": [por_est["A001"]], "A002": [por_est["A002"]], "A003": [por_est["A003"], por_est["A004"]],
              "A005": [por_est["A005"]], "A006": [por_est["A006"]]}
    obs = np.mean([np.mean(v) for v in locais.values()])
    return obs, wc


@pytest.fixture(scope="module")
def resultado(conjunto):
    pasta, trabalho = conjunto
    return pasta, processar(_editar(trabalho, pasta / "saida_principal"))


def test_validacao_preliminar(conjunto, tmp_path):
    pasta, trabalho = conjunto
    r = validar(_editar(trabalho, tmp_path / "v"))
    assert r["situacao"] == "valido"
    assert r["combinacao"] == {"modelo": "ACCESS-CM2", "ssp": "SSP5-8.5", "periodo": "2081-2100"}
    assert len(r["variaveis_meses"]) == 36


def test_delta_igual_ao_calculo_independente(resultado):
    pasta, r = resultado
    for a in r["ajustes"]:
        if a["mes"] not in (1, 4, 7, 10):
            continue
        obs, wc = _esperado(pasta, a["variavel"], a["mes"])
        assert a["media_observada_regional"] == pytest.approx(obs, abs=1e-9)
        assert a["media_worldclim_regional"] == pytest.approx(wc, abs=1e-4)
        assert a["delta"] == pytest.approx(obs - wc, abs=1e-4)
        assert a["n_estacoes"] == 6 and a["n_locais"] == 5


def test_raster_corrigido_e_recorte(resultado):
    pasta, r = resultado
    saida = Path(r["saida"])
    a = next(x for x in r["ajustes"] if x["variavel"] == "tmax" and x["mes"] == 7)
    tif = saida / "rasters/projecao_corrigida/tmax/2081-2100_SSP5-8.5_ACCESS-CM2_tmax_07Jul.tif"
    v, gt, wkt = _ler_tif(tif)
    assert "4326" in wkt and abs(gt[1] - 1 / 120) < 1e-12
    idx = lambda lon, lat: (int((lat - gt[3]) // gt[5]), int((lon - gt[0]) // gt[1]))
    # pixel no centro da área: projeção sintética + delta
    lin, col = idx(-37.0, -10.0)
    lon_c = gt[0] + (col + 0.5) * gt[1]
    esperado = 30 + 1.5 * np.cos(2 * np.pi * 6 / 12) + 1.2 * (lon_c + 37) + 4.0 + a["delta"]
    assert float(v[lin, col]) == pytest.approx(esperado, abs=1e-4)
    # fora da área = NoData
    lin2, col2 = idx(-37.55, -10.55)  # dentro da janela, fora do polígono
    assert np.isnan(v[lin2, col2])


def test_precipitacao_nunca_negativa_e_limitacao_registrada(resultado):
    pasta, r = resultado
    out = [a for a in r["ajustes"] if a["variavel"] == "prec" and a["proj_pixels_limitados_a_zero"] > 0]
    assert out, "o conjunto sintético deveria gerar limitação a zero em outubro/novembro"
    for tif in (Path(r["saida"]) / "rasters").rglob("*prec*.tif"):
        assert float(np.nanmin(_ler_tif(tif)[0])) >= 0


def test_avaliacao_eta(resultado):
    _, r = resultado
    for var in ("tmin", "tmax", "prec"):
        a = r["avaliacoes"][var]
        assert a["n_meses"] == 12
        assert a["status"] == "validado"  # o ETA sintético tem viés maior
        assert a["worldclim"]["mae"] < a["eta"]["mae"]


def test_manifesto_hashes_conferem(resultado):
    _, r = resultado
    saida = Path(r["saida"])
    man = json.loads((saida / "manifesto.json").read_text(encoding="utf-8"))
    assert man["entradas"]["observados"]["responsabilidade_confirmada"] is True
    for rel, h in man["saidas_sha256"].items():
        assert sha256(saida / rel) == h, rel


def test_mapas_72(resultado):
    _, r = resultado
    if not r["mapas"].get("gerados"):
        pytest.skip(r["mapas"].get("motivo"))
    assert r["mapas"]["n_mapas"] == 72
    assert len(list((Path(r["saida"]) / "mapas").rglob("*.pdf"))) == 72
    assert len(list((Path(r["saida"]) / "mapas").rglob("*.png"))) == 72


def test_reprodutibilidade_rasters_e_tabelas(conjunto, resultado, tmp_path):
    pasta, trabalho = conjunto
    _, r1 = resultado
    r2 = processar(_editar(trabalho, tmp_path / "repeticao", gerar_mapas=False))
    m1 = json.loads((Path(r1["saida"]) / "manifesto.json").read_text())["saidas_sha256"]
    m2 = json.loads((Path(r2["saida"]) / "manifesto.json").read_text())["saidas_sha256"]
    comuns = [k for k in m2 if k.startswith(("rasters/", "tabelas/"))]
    assert comuns and all(m1[k] == m2[k] for k in comuns)


def test_politica_perguntar_interrompe(conjunto, tmp_path):
    pasta, trabalho = conjunto
    with pytest.raises(DecisaoNecessaria) as e:
        validar(_editar(trabalho, tmp_path / "p", politica_abaixo_minimo="perguntar"))
    assert "A002" in str(e.value)


def test_excluir_abaixo_do_minimo(conjunto, tmp_path):
    pasta, trabalho = conjunto
    r = validar(_editar(trabalho, tmp_path / "e", politica_abaixo_minimo="excluir"))
    tmin = [m for m in r["medias_observadas"] if m["variavel"] == "tmin"]
    assert all("A002" not in m["estacoes"] for m in tmin)


def test_sem_confirmacao_de_responsabilidade(conjunto, tmp_path):
    pasta, trabalho = conjunto
    with pytest.raises(ErroValidacao) as e:
        validar(_editar(trabalho, tmp_path / "c", observados={"confirmo_responsabilidade": False}))
    assert "responsabilidade" in str(e.value)


def test_grade_desalinhada_rejeitada(conjunto, tmp_path):
    pasta, trabalho = conjunto
    p = pasta / "worldclim" / "wc2.1_30s_tmax_ACCESS-CM2_ssp585_2081-2100.tif"
    copia = tmp_path / "wc2.1_30s_tmax_ACCESS-CM2_ssp585_2081-2100.tif"
    d = gdal.Translate(str(copia), str(p))
    gt = list(d.GetGeoTransform())
    gt[0] += 0.003  # desloca a origem em fração de pixel
    d.SetGeoTransform(gt)
    d = None
    d = json.loads(trabalho.read_text())
    d["worldclim_projecao"] = [str(copia) if "tmax" in x else x for x in d["worldclim_projecao"]]
    d["saida"] = str(tmp_path / "g")
    novo = tmp_path / "t.json"
    novo.write_text(json.dumps(d))
    d2 = json.loads(novo.read_text())
    d2["worldclim_historico"] = [str(pasta / x) for x in d2["worldclim_historico"]]
    d2["worldclim_projecao"] = [x if Path(x).is_absolute() else str(pasta / x) for x in d2["worldclim_projecao"]]
    d2["area"] = str(pasta / d2["area"])
    d2["observados"]["arquivo"] = str(pasta / d2["observados"]["arquivo"])
    d2["eta_historico"] = [{**e, "arquivo": str(pasta / e["arquivo"])} for e in d2["eta_historico"]]
    novo.write_text(json.dumps(d2))
    with pytest.raises(ErroValidacao) as e:
        validar(novo)
    assert "mesma grade" in str(e.value)


def test_validar_e_depois_processar_na_mesma_saida(conjunto, tmp_path):
    """Fluxo da interface: validação preliminar, consentimento e processamento no mesmo diretório."""
    pasta, trabalho = conjunto
    tj = _editar(trabalho, tmp_path / "fluxo", gerar_mapas=False, gerar_zip=False)
    validar(tj)
    r = processar(tj)
    man = json.loads((Path(r["saida"]) / "manifesto.json").read_text(encoding="utf-8"))
    assert "validacao_preliminar.json" in man["saidas_sha256"]
    with pytest.raises(ErroValidacao):
        processar(tj)  # resultados já existem: não sobrescreve


def test_progresso_e_cancelamento(conjunto, tmp_path):
    from motor_mapeamento.config import Cancelado
    pasta, trabalho = conjunto
    tj = _editar(trabalho, tmp_path / "cancel", gerar_mapas=False, gerar_zip=False)
    marcas: list[float] = []
    with pytest.raises(Cancelado):
        processar(tj, progresso=lambda pct, msg: marcas.append(pct), cancelado=lambda: len(marcas) >= 10)
    assert marcas == sorted(marcas) and all(0 <= m <= 100 for m in marcas)
    assert not any((tmp_path / "cancel").iterdir()), "resultados parciais devem ser removidos"
    marcas.clear()
    processar(_editar(trabalho, tmp_path / "completo", gerar_mapas=False, gerar_zip=False),
              progresso=lambda pct, msg: marcas.append(pct))
    assert marcas == sorted(marcas) and marcas[-1] >= 97


def test_eta_mensal_do_inpe(resultado):
    """ETA de Tmax em 12 arquivos mensais com nomes do INPE, sem NoData declarado e com -999000000."""
    pasta, r = resultado
    a = r["avaliacoes"]["tmax"]
    assert a["n_meses"] == 12 and a["status"] == "validado"
    jul = next(l for l in a["linhas"] if l["mes"] == 7)
    # média independente: células de 0,2° com centro na área, sem a célula inválida
    lin_e, col_e = np.mgrid[0:10, 0:15]
    lon = ds.X0 + (col_e + 0.5) * 0.2
    lat = ds.Y0 - (lin_e + 0.5) * 0.2
    # Um centro de célula de 0,2° cai exatamente num vértice do polígono sintético; o GDAL não o conta.
    dentro = np.array([_dentro_poligono(x, y, ds.AREA, borda=False)
                       for x, y in zip(lon.ravel(), lat.ravel())]).reshape(lon.shape)
    assert dentro[ds.ETA_PIXEL_INVALIDO]
    dentro[ds.ETA_PIXEL_INVALIDO] = False
    s = np.cos(2 * np.pi * 6 / 12)
    esperado = float(np.mean((29 + 0.8 * s + 1.2 * (lon + 37))[dentro].astype("float32")))
    assert jul["eta"] == pytest.approx(esperado, abs=1e-4)
    assert jul["eta_n_pixels"] == int(dentro.sum())
    assert any("ETA tmax, mês 7: 1 pixel(is)" in av for av in r["avisos"])


def test_eta_mes_nao_identificado(conjunto, tmp_path):
    pasta, trabalho = conjunto
    d = json.loads(trabalho.read_text(encoding="utf-8"))
    origem = pasta / "eta" / "Modelo_Regional_Eta_HadGEM2-ES__Histórico_Média_Temperatura_Máxima_Mensal_Abril.tif"
    copia = pasta / "eta" / "eta_tmax_sem_mes.tif"
    copia.write_bytes(origem.read_bytes())
    d["eta_historico"].append({"arquivo": "eta/eta_tmax_sem_mes.tif", "unidade": "°C", "periodo": "1961-2005"})
    d["saida"] = str(tmp_path / "x")
    j = pasta / "trabalho_eta_sem_mes.json"
    j.write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")
    try:
        with pytest.raises(ErroValidacao) as e:
            validar(j)
        assert "identificar o mês" in str(e.value)
    finally:
        copia.unlink()
