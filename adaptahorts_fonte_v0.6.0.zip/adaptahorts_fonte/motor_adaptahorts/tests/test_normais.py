"""Normais climatológicas: média da localidade por período, taxa por década e referência em 1985
(Lima et al., 2026, seção 2.7), sub-regiões e variáveis de avaliação (tmed, etp)."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import pytest

from motor_mapeamento.config import PADROES, ErroValidacao
from motor_mapeamento.observados import _centro, consolidar_regional, media_localidade
from motor_mapeamento.pipeline import validar

import dados_sinteticos as ds

PERIODOS = ["1961-1990", "1981-2010", "1991-2020"]


def _v(eid, var, mes, valor, per=None, ano=None, regiao="", local=None):
    return {"estacao_id": eid, "local": local or f"coord:{eid}", "regiao": regiao, "variavel": var, "mes": mes,
            "tipo_dado": "normal" if per else "serie", "periodo_normal": per or "", "valor": valor, "ano": ano}


def _linear(base, taxa, per):
    """Valor de uma normal que cresce linearmente: base em 1985 e taxa por década."""
    return base + taxa * (_centro(per) - 1985) / 10


def test_taxa_da_media_da_localidade_e_referencia_1985():
    # três estações com os três períodos; taxa de +0,4 °C/década; bases diferentes
    us = [_v(e, "tmax", 1, _linear(b, 0.4, p), p) for e, b in (("A", 30.0), ("B", 31.0), ("C", 32.0)) for p in PERIODOS]
    av = []
    reg, tend = consolidar_regional(us, PADROES, av)
    assert tend[0]["taxa_por_decada"] == pytest.approx(0.4)
    assert reg[0]["valor_regional"] == pytest.approx(31.0)  # média das bases em 1985
    assert reg[0]["taxa_por_decada"] == pytest.approx(0.4)
    assert tend[0]["media_1961-1990"] == pytest.approx(_linear(31.0, 0.4, "1961-1990"))
    assert "levadas a 1985" in reg[0]["referencia"] and not av


def test_taxa_vem_das_medias_e_nao_das_estacoes():
    """A taxa é a reta das médias da localidade por período (não a média das taxas de cada estação)."""
    us = [_v("A", "prec", 3, v, p) for v, p in zip((200.0, 180.0, 150.0), PERIODOS)]
    us += [_v("B", "prec", 3, v, p) for v, p in zip((100.0, 100.0, 100.0), PERIODOS)]
    reg, tend = consolidar_regional(us, PADROES, [])
    medias = [150.0, 140.0, 125.0]
    xs = [_centro(p) for p in PERIODOS]
    mx, my = sum(xs) / 3, sum(medias) / 3
    b = sum((x - mx) * (y - my) for x, y in zip(xs, medias)) / sum((x - mx) ** 2 for x in xs)
    assert tend[0]["taxa_por_decada"] == pytest.approx(10 * b)
    assert reg[0]["valor_regional"] == pytest.approx(my + b * (1985 - mx))  # = reta em 1985


def test_estacao_com_um_periodo_e_levada_a_1985_pela_taxa_regional():
    us = [_v(e, "tmin", 7, _linear(18.0, -0.2, p), p) for e in ("A", "B") for p in PERIODOS]
    us.append(_v("C", "tmin", 7, _linear(18.0, -0.2, "1991-2020"), "1991-2020"))
    av = []
    reg, tend = consolidar_regional(us, PADROES, av)
    # C tem o mesmo clima de A e B: a média de 1991–2020 não muda, a taxa fica −0,2 e C vai a 18 em 1985
    assert tend[0]["taxa_por_decada"] == pytest.approx(-0.2)
    assert reg[0]["valor_regional"] == pytest.approx(18.0)
    assert any("número de locais difere" in a for a in av)


def test_composicao_diferente_entre_periodos_distorce_a_taxa():
    """Estação mais quente presente só no último período eleva a média dele: a taxa sai das médias
    (regra do artigo) e o aviso de composição é emitido."""
    us = [_v(e, "tmin", 7, _linear(18.0, -0.2, p), p) for e in ("A", "B") for p in PERIODOS]
    us.append(_v("C", "tmin", 7, _linear(21.0, -0.2, "1991-2020"), "1991-2020"))
    av = []
    _, tend = consolidar_regional(us, PADROES, av)
    assert tend[0]["taxa_por_decada"] > 0  # sinal invertido pela composição
    assert any("mistura mudança do clima e mudança na composição" in a for a in av)
    _, tend2 = consolidar_regional(us, {**PADROES, "normais_taxa_estacoes": "completas"}, [])
    assert tend2[0]["taxa_por_decada"] == pytest.approx(-0.2)  # só A e B, que têm os três períodos


def test_series_e_normais_juntas():
    us = [_v("A", "tmax", 1, _linear(30.0, 0.5, p), p) for p in PERIODOS]
    us.append(_v("S", "tmax", 1, 32.0, ano=1990))  # média da série 1970–2000 já consolidada
    reg, _ = consolidar_regional(us, PADROES, [])
    assert reg[0]["valor_regional"] == pytest.approx(31.0)
    assert "séries" in reg[0]["referencia"] and "normais" in reg[0]["referencia"]


def test_subregioes_interior_e_litoral():
    us = [_v(e, "tmax", 1, v, "1961-1990", regiao=r) for e, v, r in
          (("I1", 34.0, "interior"), ("I2", 32.0, "interior"), ("L1", 29.0, "litoral"))]
    m, nl, nr = media_localidade(us)
    assert m == pytest.approx((33.0 + 29.0) / 2) and nl == 3 and nr == 2


def test_taxa_anual_temperatura_media_e_precipitacao_soma():
    us = []
    for mes in range(1, 13):
        us += [_v("A", "tmax", mes, _linear(30, 0.3 + 0.01 * mes, p), p) for p in PERIODOS]
        us += [_v("A", "prec", mes, _linear(100, -5.0, p), p) for p in PERIODOS]
    _, tend = consolidar_regional(us, PADROES, [])
    anual = {t["variavel"]: t["taxa_por_decada"] for t in tend if t["mes"] == "anual"}
    assert anual["tmax"] == pytest.approx(0.3 + 0.01 * 6.5)
    assert anual["prec"] == pytest.approx(-60.0)


def test_metodo_media_sem_tendencia():
    us = [_v("A", "tmax", 1, _linear(30.0, 0.4, p), p) for p in PERIODOS]
    reg, _ = consolidar_regional(us, {**PADROES, "normais_metodo": "media"}, [])
    assert reg[0]["valor_regional"] == pytest.approx(sum(_linear(30.0, 0.4, p) for p in PERIODOS) / 3)


# ------------------------------------------------------------------- ponta a ponta (validação)

@pytest.fixture(scope="module")
def pasta_normais(tmp_path_factory):
    """Conjunto sintético em que todas as estações têm só normais dos três períodos, com tmed, etp e regiao."""
    pasta = tmp_path_factory.mktemp("normais")
    tj = ds.gerar(pasta)
    est = [("N1", -37.20, -10.10, "interior"), ("N2", -36.95, -9.90, "interior"), ("N3", -36.70, -10.05, "litoral")]
    linhas = []
    for eid, lon, lat, reg in est:
        for var, base, taxa, un in (("tmin", 20.0, -0.19, "°C"), ("tmax", 31.0, 0.41, "°C"), ("tmed", 25.5, 0.1, "°C"),
                                    ("prec", 80.0, -5.5, "mm"), ("etp", 130.0, 1.0, "mm")):
            for mes in range(1, 13):
                for per in PERIODOS:
                    linhas.append({"estacao_id": eid, "nome": eid, "local_id": "", "lon": lon, "lat": lat,
                                   "variavel": var, "tipo_dado": "normal", "ano": "", "mes": mes,
                                   "valor": f"{_linear(base + mes * 0.1, taxa, per):.4f}".replace(".", ","),
                                   "unidade": un, "periodo_normal": per, "fonte": "INMET – Normais",
                                   "dias_faltantes": "", "regiao": reg})
    with (pasta / "observados.csv").open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(linhas[0]), delimiter=";")
        w.writeheader()
        w.writerows(linhas)
    d = json.loads(tj.read_text(encoding="utf-8"))
    d["observados"]["tipo_declarado"] = "normal"
    d["saida"] = str(pasta / "saida_val")
    tj.write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")
    return tj


def test_validacao_com_normais_tres_periodos(pasta_normais):
    r = validar(pasta_normais)  # sem DecisaoNecessaria: normais em tendência não caem no mínimo de anos
    reg = {(x["variavel"], x["mes"]): x for x in r["medias_observadas"]}
    assert reg[("tmax", 1)]["valor_regional"] == pytest.approx(31.1, abs=1e-6)
    assert reg[("tmax", 1)]["n_regioes"] == 2
    assert ("tmed", 6) in reg and ("etp", 6) in reg
    anual = {t["variavel"]: t["taxa_por_decada"] for t in r["tendencias_normais"] if t["mes"] == "anual"}
    assert anual["tmax"] == pytest.approx(0.41) and anual["tmin"] == pytest.approx(-0.19)
    assert anual["prec"] == pytest.approx(-66.0) and anual["etp"] == pytest.approx(12.0)


def test_unica_recusa_varios_periodos(pasta_normais, tmp_path):
    d = json.loads(pasta_normais.read_text(encoding="utf-8"))
    d["parametros"]["normais_metodo"] = "unica"
    d["saida"] = str(tmp_path / "s")
    tj = pasta_normais.parent / "trabalho_unica.json"
    tj.write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")
    with pytest.raises(ErroValidacao) as e:
        validar(tj)
    assert "mais de um período de normal" in str(e.value)
