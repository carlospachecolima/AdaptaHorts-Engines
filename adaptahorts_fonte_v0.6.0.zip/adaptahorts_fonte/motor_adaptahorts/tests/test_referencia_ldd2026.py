"""Teste de referência: reproduzir as Tabelas 1, 2, 3 e 7 de Lima et al. (2026), LDD.

Requer os dados reais (shapefile do LSF/SE-AL, WorldClim 1970–2000, planilha das 12
estações INMET e ETA-HadGEM2-ES histórico). Aponte a variável de ambiente
ADAPTAHORTS_TRABALHO_REFERENCIA para o JSON desse trabalho; sem ela, o teste é ignorado.

O teste também confere, sem dados reais, a consistência interna das tabelas publicadas.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

import numpy as np
import pytest

REF = json.loads((Path(__file__).parent / "referencia_ldd2026.json").read_text(encoding="utf-8"))
TOL = REF["tolerancias"]


def test_tabelas_publicadas_sao_consistentes():
    for v in ("tmax", "tmin", "prec"):
        obs, wc, dc = map(np.array, (REF[v]["obs"], REF[v]["worldclim"], REF[v]["delta"]))
        tol = TOL["temperatura_delta"] if v != "prec" else TOL["prec_delta"]
        assert np.allclose(obs - wc, dc, atol=tol), v
        assert np.corrcoef(obs, wc)[0, 1] == pytest.approx(REF[v]["pearson_wc"], abs=TOL["pearson"]), v
    assert sum(REF["prec"]["obs"]) == pytest.approx(REF["prec"]["anual"]["obs"], abs=0.1)
    assert sum(REF["prec"]["eta"]) == pytest.approx(REF["prec"]["anual"]["eta"], abs=0.1)


@pytest.mark.skipif(not os.environ.get("ADAPTAHORTS_TRABALHO_REFERENCIA"),
                    reason="defina ADAPTAHORTS_TRABALHO_REFERENCIA com o JSON do trabalho com dados reais")
def test_motor_reproduz_artigo(tmp_path):
    from motor_mapeamento.pipeline import processar
    original = Path(os.environ["ADAPTAHORTS_TRABALHO_REFERENCIA"]).resolve()
    d = json.loads(original.read_text(encoding="utf-8"))
    d["saida"] = str(tmp_path / "saida")
    d.setdefault("parametros", {}).update(media_raster="simples", gerar_mapas=False, gerar_zip=False,
                                          metodo_delta={"tmin": "aditivo", "tmax": "aditivo", "prec": "aditivo"})
    copia = original.parent / f".{original.stem}_teste_referencia.json"
    copia.write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")
    try:
        r = processar(copia)
    finally:
        copia.unlink(missing_ok=True)
    for v in ("tmax", "tmin", "prec"):
        aj = sorted((a for a in r["ajustes"] if a["variavel"] == v), key=lambda a: a["mes"])
        assert [a["mes"] for a in aj] == list(range(1, 13)), f"{v}: o trabalho precisa dos 12 meses"
        t_obs = TOL["temperatura_media"] if v != "prec" else TOL["prec_obs"]
        t_wc = TOL["temperatura_media"] if v != "prec" else TOL["prec_wc"]
        t_dc = TOL["temperatura_delta"] if v != "prec" else TOL["prec_delta"] + TOL["prec_obs"]
        for a, o, w, dc in zip(aj, REF[v]["obs"], REF[v]["worldclim"], REF[v]["delta"]):
            assert a["media_observada_regional"] == pytest.approx(o, abs=t_obs), (v, a["mes"], "obs")
            assert a["media_worldclim_regional"] == pytest.approx(w, abs=t_wc), (v, a["mes"], "worldclim")
            assert a["delta"] == pytest.approx(dc, abs=t_dc), (v, a["mes"], "delta")
        av = r["avaliacoes"][v]
        assert av["worldclim"]["pearson"] == pytest.approx(REF[v]["pearson_wc"], abs=0.002), (v, "r WorldClim")
    p = r["avaliacoes"]["prec"]
    if p.get("n_meses") == 12:
        eta = [l["eta"] for l in sorted(p["linhas"], key=lambda l: l["mes"])]
        assert np.allclose(eta, REF["prec"]["eta"], atol=TOL["eta_prec"])
        assert p["eta"]["pearson"] == pytest.approx(REF["prec"]["pearson_eta"], abs=0.005)
        assert p["status"] == "validado"
