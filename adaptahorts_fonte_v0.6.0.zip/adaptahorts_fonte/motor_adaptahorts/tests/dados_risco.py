"""Dados sintéticos para o módulo de risco: microrregiões, questionários PAERC e raster de CE."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from osgeo import gdal, ogr, osr

import dados_sinteticos as ds

REGIOES = {  # nome: polígono (lon, lat)
    "Região Oeste": [(-37.7, -9.4), (-37.0, -9.4), (-37.0, -10.7), (-37.7, -10.7)],
    "Região Leste": [(-37.0, -9.4), (-36.2, -9.4), (-36.2, -10.7), (-37.0, -10.7)],
}

# Respostas: Oeste com alta capacidade adaptativa, Leste com baixa.
PERFIS = {
    "Região Oeste": dict(renda_mensal=4500, credito_pronaf="sim", seguro_rural="sim", n_especies=8,
                         tec_estufa="sim", tec_mulching="sim", tec_irrigacao_eficiente="sim",
                         tec_fertilizacao_eficiente="não", tec_sistemas_regenerativos="não",
                         ater_visitas_ano=6, caf="valido", prog_abc="sim", prog_ater_qualificada="sim",
                         prog_agroecologia="não", prog_irrigacao="sim", dist_ceasa_km=15),
    "Região Leste": dict(renda_mensal=2200, credito_pronaf="não", seguro_rural="não", n_especies=2,
                         tec_estufa="não", tec_mulching="não", tec_irrigacao_eficiente="não",
                         tec_fertilizacao_eficiente="não", tec_sistemas_regenerativos="não",
                         ater_visitas_ano=1, caf="pendente", prog_abc="não", prog_ater_qualificada="não",
                         prog_agroecologia="não", prog_irrigacao="não", dist_ceasa_km=65),
}


def _gpkg_regioes(caminho: Path) -> None:
    s = osr.SpatialReference()
    s.ImportFromEPSG(4326)
    d = ogr.GetDriverByName("GPKG").CreateDataSource(str(caminho))
    lyr = d.CreateLayer("microrregioes", s, ogr.wkbPolygon)
    lyr.CreateField(ogr.FieldDefn("nome", ogr.OFTString))
    for nome, v in REGIOES.items():
        anel = ogr.Geometry(ogr.wkbLinearRing)
        for x, y in v + [v[0]]:
            anel.AddPoint_2D(x, y)
        pol = ogr.Geometry(ogr.wkbPolygon)
        pol.AddGeometry(anel)
        f = ogr.Feature(lyr.GetLayerDefn())
        f.SetField("nome", nome)
        f.SetGeometry(pol)
        lyr.CreateFeature(f)
    d = None


def gerar_questionarios(caminho: Path, n_por_regiao: int = 8) -> list[dict]:
    from motor_mapeamento.risco.paerc import CAMPOS
    linhas = []
    rng = np.random.default_rng(7)
    for nome, perfil in PERFIS.items():
        xs = [x for x, _ in REGIOES[nome]]
        for i in range(n_por_regiao):
            l = {c: "" for c in CAMPOS}
            l.update(perfil)
            l["id_questionario"] = f"{nome[7:10].upper()}-{i + 1:02d}"
            l["renda_mensal"] = perfil["renda_mensal"] + int(rng.integers(-300, 300))
            if i % 2 == 0:  # metade com coordenadas, metade só com o nome da microrregião
                l["lon"] = round(float(rng.uniform(min(xs) + 0.05, max(xs) - 0.05)), 5)
                l["lat"] = round(float(rng.uniform(-10.5, -9.6)), 5)
            else:
                l["microrregiao"] = nome.upper() if i == 1 else nome  # nome sem diferenciar maiúsculas
            linhas.append(l)
    with caminho.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=CAMPOS, delimiter=";")
        w.writeheader()
        w.writerows(linhas)
    return linhas


def gerar_ce(caminho: Path) -> None:
    """CE (dS/m) em grade de 0,05°: 0,8 a oeste até 4,0 a leste."""
    gt = (ds.X0, 0.05, 0.0, ds.Y0, 0.0, -0.05)
    cols = np.arange(60)
    lon = ds.X0 + (cols + 0.5) * 0.05
    ce = np.tile(np.clip(0.8 + (lon + 38.5) * 1.3, 0, None), (40, 1)).astype("float32")
    d = gdal.GetDriverByName("GTiff").Create(str(caminho), 60, 40, 1, gdal.GDT_Float32)
    d.SetGeoTransform(gt)
    s = osr.SpatialReference()
    s.ImportFromEPSG(4326)
    d.SetProjection(s.ExportToWkt())
    d.GetRasterBand(1).WriteArray(ce)
    d = None


def gerar(pasta: Path, saida_mapeamento: Path) -> Path:
    pasta.mkdir(parents=True, exist_ok=True)
    _gpkg_regioes(pasta / "microrregioes.gpkg")
    gerar_questionarios(pasta / "questionarios.csv")
    gerar_ce(pasta / "ce_dsm.tif")
    trabalho = {
        "mapeamento": str(saida_mapeamento),
        "area": str(pasta.parent / "area" / "area_teste.shp") if (pasta.parent / "area").exists() else None,
        "exposicao": {"tipo": "constante", "adocao_conservacionista": 0.10},
        "paerc": {"questionarios": "questionarios.csv", "microrregioes": "microrregioes.gpkg", "campo_nome": "nome"},
        "ce_salinidade": "ce_dsm.tif",
        "saida": "saida_risco",
        "parametros": {"paerc_bootstrap_iteracoes": 2000, "gerar_mapas": True},
    }
    p = pasta / "trabalho_risco.json"
    p.write_text(json.dumps(trabalho, ensure_ascii=False, indent=2), encoding="utf-8")
    return p
