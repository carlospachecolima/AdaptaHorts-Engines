"""Testes do módulo de risco: fórmulas de referência, questionário PAERC e cálculo ponta a ponta."""

from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
import pytest
from osgeo import gdal

import dados_risco as dr
import dados_sinteticos as ds
from motor_mapeamento.config import ErroValidacao
from motor_mapeamento.entradas import sha256
from motor_mapeamento.pipeline import processar
from motor_mapeamento.risco import indices as ix
from motor_mapeamento.risco import paerc as pq
from motor_mapeamento.risco.config_risco import PARAMETROS_RISCO as P
from motor_mapeamento.risco.pipeline_risco import executar


# ----------------------------------------------------------------------------- fórmulas

def test_ra_exemplo_fao56():
    # FAO-56, Exemplo 8: 20° S, 3 de setembro (dia 246) → Ra = 32,2 MJ m⁻² dia⁻¹
    assert float(ix.ra_mj(-20.0, 246)) == pytest.approx(32.2, abs=0.05)


def test_hargreaves_mensal():
    lat = np.full((1, 1), -15.8)
    tmin = np.full((12, 1, 1), 15.0)
    tmax = np.full((12, 1, 1), 28.0)
    et0 = ix.et0_hargreaves(tmin, tmax, lat)
    ra_jan = float(ix.ra_mj(-15.8, 15)) * 0.408
    esperado = 0.0023 * ra_jan * (21.5 + 17.8) * math.sqrt(13.0) * 31
    assert float(et0[0, 0, 0]) == pytest.approx(esperado, rel=1e-12)


def test_concentracao_e_pci():
    uniforme = np.full((12, 1, 1), 50.0)
    unico = np.zeros((12, 1, 1))
    unico[3] = 600.0
    assert float(ix.concentracao(uniforme)[0, 0]) == pytest.approx(0.0)
    assert float(ix.concentracao(unico)[0, 0]) == pytest.approx(1.0)
    assert float(ix.concentracao(np.zeros((12, 1, 1)))[0, 0]) == 0.0
    assert float(ix.pci_oliver(uniforme)[0, 0]) == pytest.approx(100 / 12)


def test_erosividade_lombardi_neto():
    prec = np.full((12, 1, 1), 100.0)
    assert float(ix.erosividade(prec)[0, 0]) == pytest.approx(12 * 67.355 * (100 ** 2 / 1200) ** 0.85)


def test_isdh_responde_ao_clima():
    """Com limiares fixos, mais déficit → ISDH maior (o score não fica 'parado' entre cenários)."""
    etc = np.full((12, 1, 1), 120.0)
    pouco = ix.isdh(etc, np.full((12, 1, 1), 100.0), P)["indice"]
    muito = ix.isdh(etc, np.full((12, 1, 1), 40.0), P)["indice"]
    assert float(muito[0, 0]) > float(pouco[0, 0])


def test_issa_zero_abaixo_do_limiar():
    etc, prec = np.full((12, 1, 2), 120.0), np.full((12, 1, 2), 30.0)
    r = ix.issa(np.array([[1.0, 4.0]]), etc, prec, P)["indice"]
    assert r[0, 0] == 0.0 and r[0, 1] > 0


def test_fator_concentracao_fao29():
    """Sem chuva e com eficiência 0,85, LF = 0,15 e FC = (1 + 0,15) / (5 · 0,15) ≈ 1,53 (FAO-29: ECe ≈ 1,5 ECw)."""
    etc, prec = np.full((12, 1, 1), 120.0), np.zeros((12, 1, 1))
    f = ix.fator_concentracao_sais(etc, prec, 0.85, 0.05)
    assert float(f["lf"][0, 0]) == pytest.approx(0.15)
    assert float(f["fc"][0, 0]) == pytest.approx(1.15 / 0.75)


def test_issa_suscetibilidade_responde_ao_clima():
    etc = np.full((12, 1, 1), 120.0)
    seco = ix.issa_suscetibilidade(etc, np.full((12, 1, 1), 20.0), P)
    umido = ix.issa_suscetibilidade(etc, np.full((12, 1, 1), 100.0), P)
    sem_deficit = ix.issa_suscetibilidade(etc, np.full((12, 1, 1), 150.0), P)
    assert float(seco["indice"][0, 0]) > float(umido["indice"][0, 0]) > 0
    assert float(sem_deficit["indice"][0, 0]) == 0.0 and float(sem_deficit["fator_concentracao_sais"][0, 0]) == 0.0
    # CE máxima da água = limiar / FC; água de referência → ECe = 0,7 · FC
    fc = float(seco["fator_concentracao_sais"][0, 0])
    assert float(seco["ecw_critica"][0, 0]) == pytest.approx(P["issa_ce_limiar"] / fc)
    assert float(seco["ece_agua_referencia"][0, 0]) == pytest.approx(P["issa_ce_agua"] * fc)


def test_ameaca_renormaliza_pesos():
    a, b = np.array([0.2]), np.array([0.8])
    h, usados = ix.ameaca({"isoc": a, "isdh": b}, {"isoc": 0.25, "isdh": 0.25, "iscc": 0.25, "issa": 0.25})
    assert float(h[0]) == pytest.approx(0.5) and usados == {"isoc": 0.5, "isdh": 0.5}


# ----------------------------------------------------------------------------- questionário

@pytest.mark.parametrize("x,esperado", [(2000, 0.0), (2001, 0.25), (3000, 0.25), (5000, 0.75), (5001, 1.0)])
def test_faixas_renda(x, esperado):
    assert float(pq.faixa(np.array([x]), pq.FAIXAS["renda"])[0]) == esperado


@pytest.mark.parametrize("d,esperado", [(70, 0.0), (60, 0.25), (41, 0.25), (40, 0.5), (20, 0.75), (10.5, 0.75), (10, 1.0)])
def test_faixas_distancia(d, esperado):
    assert float(pq.faixa_proximidade(np.array([d]), pq.FAIXAS_PROXIMIDADE["distancia"])[0]) == esperado


def test_pesos_bootstrap():
    """Pesos padrão = médias do bootstrap (não a coluna arredondada 'Peso final')."""
    w = P["pesos"]
    assert w["isoc"] == {"I": 0.460, "D": 0.352, "C": 0.188}
    assert w["isdh"] == {"I": 0.446, "D": 0.354, "C": 0.200}
    assert w["iscc"] == {"I": 0.372, "D": 0.231, "C": 0.397}
    assert w["issa"] == {"I": 0.432, "D": 0.406, "C": 0.162}
    assert w["paerc"] == {"CE": 0.473, "CT": 0.388, "CI": 0.139}
    for v in w.values():
        assert sum(v.values()) == pytest.approx(1.0, abs=1e-9)


def test_paerc_perfis(tmp_path):
    linhas = dr.gerar_questionarios(tmp_path / "q.csv")
    q = pq.validar_respostas(pq.ler_respostas(tmp_path / "q.csv"), P)
    assert not q.erros and len(q.respostas) == len(linhas)
    for r in q.respostas:
        r["regiao_atribuida"] = "Região Oeste" if r["id_questionario"].startswith("OES") else "Região Leste"
    regs = {r["microrregiao"]: r for r in pq.paerc_regioes(q.respostas, {**P, "paerc_bootstrap_iteracoes": 500})}
    # Oeste: CE (0,75+1+1)/3, CT (0,75+1+1)/3, CI (1+1+0,75)/3 → PAERC 0,9167
    assert regs["Região Oeste"]["PAERC"] == pytest.approx(0.473 * 11 / 12 + 0.388 * 11 / 12 + 0.139 * 11 / 12)
    # Leste: CE (0,25+0+0)/3, CT (0,25+0+0,25)/3, CI (0,5+0+0)/3
    assert regs["Região Leste"]["PAERC"] == pytest.approx(0.473 * 0.25 / 3 + 0.388 * 0.5 / 3 + 0.139 * 0.5 / 3)
    a = pq.paerc_regioes(q.respostas, {**P, "paerc_bootstrap_iteracoes": 500})
    b = pq.paerc_regioes(q.respostas, {**P, "paerc_bootstrap_iteracoes": 500})
    assert a == b  # semente fixa → reprodutível


def test_questionario_respostas_invalidas(tmp_path):
    dr.gerar_questionarios(tmp_path / "q.csv")
    texto = (tmp_path / "q.csv").read_text(encoding="utf-8-sig").replace(";valido;", ";talvez;", 1)
    (tmp_path / "q.csv").write_text(texto, encoding="utf-8-sig")
    q = pq.validar_respostas(pq.ler_respostas(tmp_path / "q.csv"), P)
    assert any("caf" in e and "talvez" in e for e in q.erros)


def test_modelo_xlsx_ignora_exemplo(tmp_path):
    x = pq.criar_modelo_xlsx(tmp_path / "q.xlsx")
    assert pq.ler_respostas(x) == []
    from motor_mapeamento import geo
    linhas = geo.ler_tabela_ogr(x, "respostas")  # cabeçalho forçado, como na leitura real
    assert list(linhas[0]) == pq.CAMPOS and linhas[0]["id_questionario"] == "EXEMPLO-APAGUE"


# ----------------------------------------------------------------------------- ponta a ponta

@pytest.fixture(scope="module")
def mapeamento(tmp_path_factory):
    pasta = tmp_path_factory.mktemp("risco_base")
    tj = ds.gerar(pasta)
    d = json.loads(tj.read_text(encoding="utf-8"))
    d["parametros"].update(gerar_mapas=False, gerar_zip=False)
    tj.write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")
    processar(tj)
    return pasta


def _trabalho(mapeamento: Path, nome: str, **extra) -> Path:
    tj = dr.gerar(mapeamento / f"risco_{nome}", mapeamento / "saida")
    d = json.loads(tj.read_text(encoding="utf-8"))
    d["parametros"].update(gerar_mapas=False, gerar_zip=False, paerc_bootstrap_iteracoes=500)
    d.update(extra)
    tj.write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")
    return tj


def _tif(f: Path) -> np.ndarray:
    d = gdal.Open(str(f))
    a = d.GetRasterBand(1).ReadAsArray().astype("float64")
    a[a == -9999.0] = np.nan
    return a


def test_risco_ponta_a_ponta(mapeamento):
    r = executar(_trabalho(mapeamento, "completo"))
    saida = Path(r["saida"])
    hist, proj = r["resumo"]
    assert proj["etc_anual"] > hist["etc_anual"] and proj["isdh"] > hist["isdh"] and proj["isoc"] > hist["isoc"]
    assert proj["variacao_irrigacao_pct"] > 0
    assert hist["exposicao"] == pytest.approx(0.90)
    rot = {"historico": "Historico_1970-2000", "projecao": "2081-2100_SSP5-8.5_ACCESS-CM2"}
    for cen in ("historico", "projecao"):
        g = lambda n: _tif(saida / "rasters" / cen / f"{rot[cen]}_{n}.tif")
        h, e, pa, risco = g("ameaca"), g("exposicao"), g("paerc"), g("risco")
        ok = np.isfinite(risco)
        assert ok.sum() > 1000
        assert np.allclose(risco[ok], (h * e * (1 - pa))[ok], atol=1e-5)
        # ameaça = média dos 4 índices (pesos iguais), já que há raster de CE
        media = (g("isoc") + g("isdh") + g("iscc") + g("issa")) / 4
        assert np.allclose(h[ok], media[ok], atol=1e-5)
        # PAERC rasterizado: Oeste alto, Leste baixo
        assert set(np.round(np.unique(pa[ok]), 4)) == {round(0.473 * 0.25 / 3 + 0.388 * 0.5 / 3 + 0.139 * 0.5 / 3, 4),
                                                       round(11 / 12, 4)}
    man = json.loads((saida / "manifesto_risco.json").read_text(encoding="utf-8"))
    for rel, hsh in man["saidas_sha256"].items():
        assert sha256(saida / rel) == hsh, rel
    assert man["pesos_ameaca_usados"] == {"isoc": 0.25, "isdh": 0.25, "iscc": 0.25, "issa": 0.25}
    assert man["issa_modo"].startswith("estresse")


def test_risco_sem_ce_e_sem_paerc(mapeamento):
    r = executar(_trabalho(mapeamento, "parcial", ce_salinidade=None, paerc=None))
    # sem CE medida, o ISSA é a suscetibilidade climática e entra na ameaça com os outros três
    assert r["manifesto"]["pesos_ameaca_usados"] == {"isoc": 0.25, "isdh": 0.25, "iscc": 0.25, "issa": 0.25}
    assert r["manifesto"]["issa_modo"].startswith("suscetibilidade")
    hist, proj = r["resumo"]
    assert proj["issa"] > hist["issa"] and proj["fator_concentracao_sais"] > hist["fator_concentracao_sais"]
    assert proj["ecw_critica"] < hist["ecw_critica"]  # clima mais seco tolera água menos salina
    assert hist["risco"] is None and hist["risco_potencial"] is not None
    assert any("suscetibilidade climática à salinização" in a for a in r["avisos"])
    assert any("apenas o risco potencial" in a for a in r["avisos"])


def test_risco_questionario_sem_regiao_falha_e_limpa(mapeamento):
    tj = _trabalho(mapeamento, "erro")
    q = tj.parent / "questionarios.csv"
    q.write_text(q.read_text(encoding="utf-8-sig").replace("Região Leste", "Região Inexistente"), encoding="utf-8-sig")
    with pytest.raises(ErroValidacao) as e:
        executar(tj)
    assert "não foi possível associá-lo" in str(e.value)
    saida = tj.parent / "saida_risco"
    assert not saida.exists() or not any(saida.iterdir())


@pytest.mark.parametrize("ind", ["isoc", "isdh", "iscc", "issa"])
def test_indice_unico(mapeamento, ind):
    tj = _trabalho(mapeamento, f"so_{ind}", ce_salinidade=None)
    r = executar(tj, indice=ind)
    saida = Path(r["saida"])
    assert r["manifesto"]["indice"] == ind and r["manifesto"]["pesos_ameaca_usados"] is None
    assert r["paerc"] is None  # questionários ignorados no modo de índice único
    rot = {"historico": "Historico_1970-2000", "projecao": "2081-2100_SSP5-8.5_ACCESS-CM2"}
    w = P["pesos"][ind]
    outros = {"isoc", "isdh", "iscc", "issa", "ameaca", "exposicao", "risco", "risco_potencial"} - {ind}
    for cen in ("historico", "projecao"):
        nomes = {f.stem.split(rot[cen] + "_")[1] for f in (saida / "rasters" / cen).glob("*.tif")}
        assert {ind, f"{ind}_I", f"{ind}_D", f"{ind}_C"} <= nomes
        assert not (nomes & outros), nomes & outros
        g = lambda n: _tif(saida / "rasters" / cen / f"{rot[cen]}_{n}.tif")
        x = g(ind)
        ok = np.isfinite(x)
        assert ok.sum() > 1000
        comb = w["I"] * g(f"{ind}_I") + w["D"] * g(f"{ind}_D") + w["C"] * g(f"{ind}_C")
        assert np.allclose(x[ok], comb[ok], atol=1e-5)
    assert (saida / "rasters" / "variacao" / f"variacao_{ind}.tif").exists()
    rel = Path(r["relatorio"])
    assert rel.name == f"relatorio_{ind}.md"
    txt = rel.read_text(encoding="utf-8")
    assert f"{w['I']:.3f}·I + {w['D']:.3f}·D + {w['C']:.3f}·C" in txt
    man = json.loads((saida / "manifesto_risco.json").read_text(encoding="utf-8"))
    for relp, hsh in man["saidas_sha256"].items():
        assert sha256(saida / relp) == hsh, relp


def test_indice_unico_pesos_personalizados(mapeamento):
    tj = _trabalho(mapeamento, "so_isoc_w", ce_salinidade=None)
    d = json.loads(tj.read_text(encoding="utf-8"))
    d["parametros"]["pesos"] = {"isoc": {"I": 1.0, "D": 0.0, "C": 0.0}}
    tj.write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")
    r = executar(tj, indice="isoc")
    s = Path(r["saida"]) / "rasters" / "historico"
    a, b = _tif(next(s.glob("*_isoc.tif"))), _tif(next(s.glob("*_isoc_I.tif")))
    ok = np.isfinite(a)
    assert np.allclose(a[ok], b[ok])


def test_indice_invalido(mapeamento):
    with pytest.raises(ErroValidacao):
        executar(_trabalho(mapeamento, "so_x"), indice="xyz")
