"""Gera um conjunto sintético pequeno, com o mesmo formato dos dados reais.

Os valores são artificiais e servem apenas para testar o motor.
"""

from __future__ import annotations

import json
from pathlib import Path

import csv

import numpy as np
from osgeo import gdal, ogr, osr



RES = 1 / 120
NODATA_WC = -3.4e38
# Grade de 30" alinhada à grade global do WorldClim (origem -180, 90).
X0, Y0 = -38.5, -9.0
W, H = 360, 240  # 3° × 2°
TRANSF = (X0, RES, 0.0, Y0, 0.0, -RES)  # geotransform GDAL
AREA = [(-37.6, -9.6), (-36.6, -9.5), (-36.3, -10.0), (-36.7, -10.6), (-37.5, -10.4)]  # vértices (lon, lat)

ESTACOES = [  # id, nome, lon, lat, local_id
    ("A001", "Estação A", -37.20, -9.80, ""),
    ("A002", "Estação B", -36.80, -10.10, ""),
    ("A003", "Estação C", -37.30, -10.30, ""),
    ("A004", "Estação D (co-localizada)", -37.30, -10.30, ""),   # mesma coordenada de A003
    ("A005", "Estação E (fora da área)", -36.25, -10.45, ""),
    ("A006", "Estação F (normal)", -36.90, -9.70, ""),
]


def campo(var: str, mes: int, futuro: bool) -> np.ndarray:
    lins, cols = np.mgrid[0:H, 0:W]
    lon = X0 + (cols + 0.5) * RES
    lat = Y0 - (lins + 0.5) * RES
    sazonal = np.cos(2 * np.pi * (mes - 1) / 12)
    if var == "tmax":
        v = 30 + 1.5 * sazonal + 1.2 * (lon + 37)
        v = v + (4.0 if futuro else 0)
    elif var == "tmin":
        v = 21 + 1.0 * sazonal + 0.6 * (lon + 37)
        v = v + (3.0 if futuro else 0)
    else:
        base = 60 + 50 * np.cos(2 * np.pi * (mes - 6) / 12)  # chuvoso no meio do ano
        v = np.clip(base + 25 * (lon + 37), 0, None)
        v = v * (0.7 if futuro else 1.0)
    v = v.astype("float32")
    v[lon > -35.8] = NODATA_WC  # "oceano"
    return v


MESES_PT = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro",
            "Novembro", "Dezembro"]
ETA_PIXEL_INVALIDO = (5, 7)  # linha, coluna na grade de 0,2°: centro (-37,0; -10,1), dentro da área


def _tif(caminho: Path, bandas: list[np.ndarray], transf=TRANSF, nodata=NODATA_WC) -> None:
    ds = gdal.GetDriverByName("GTiff").Create(str(caminho), bandas[0].shape[1], bandas[0].shape[0], len(bandas),
                                              gdal.GDT_Float32)
    ds.SetGeoTransform(transf)
    s = osr.SpatialReference()
    s.ImportFromEPSG(4326)
    ds.SetProjection(s.ExportToWkt())
    for i, b in enumerate(bandas, 1):
        if nodata is not None:
            ds.GetRasterBand(i).SetNoDataValue(nodata)
        ds.GetRasterBand(i).WriteArray(b)
    ds = None


def _shapefile(caminho: Path) -> None:
    s = osr.SpatialReference()
    s.ImportFromEPSG(4326)
    ds = ogr.GetDriverByName("ESRI Shapefile").CreateDataSource(str(caminho))
    lyr = ds.CreateLayer(caminho.stem, s, ogr.wkbPolygon)
    lyr.CreateField(ogr.FieldDefn("nome", ogr.OFTString))
    anel = ogr.Geometry(ogr.wkbLinearRing)
    for x, y in AREA + [AREA[0]]:
        anel.AddPoint_2D(x, y)
    pol = ogr.Geometry(ogr.wkbPolygon)
    pol.AddGeometry(anel)
    f = ogr.Feature(lyr.GetLayerDefn())
    f.SetField("nome", "Area teste")
    f.SetGeometry(pol)
    lyr.CreateFeature(f)
    ds = None


def valor_obs(var: str, mes: int, lon: float, ano: int, sid: int) -> float:
    """Observado = 'verdade' com viés conhecido em relação ao campo sintético."""
    sazonal = np.cos(2 * np.pi * (mes - 1) / 12)
    ruido = 0.3 * np.sin(ano * 1.7 + sid + mes)
    if var == "tmax":
        return 30 + 1.5 * sazonal + 1.2 * (lon + 37) + 1.5 + ruido
    if var == "tmin":
        return 21 + 1.0 * sazonal + 0.6 * (lon + 37) + 1.1 + ruido
    base = 60 + 50 * np.cos(2 * np.pi * (mes - 6) / 12)
    return max(0.0, base + 25 * (lon + 37) + (-22 if mes in (10, 11) else 8) + 3 * ruido)


def gerar(pasta: Path) -> Path:
    pasta.mkdir(parents=True, exist_ok=True)
    wc = pasta / "worldclim"
    wc.mkdir(exist_ok=True)
    hist = []
    for var in ("tmin", "tmax", "prec"):
        for mes in range(1, 13):
            p = wc / f"wc2.1_30s_{var}_{mes:02d}.tif"
            _tif(p, [campo(var, mes, False)])
            hist.append(str(p.relative_to(pasta)))
        _tif(wc / f"wc2.1_30s_{var}_ACCESS-CM2_ssp585_2081-2100.tif", [campo(var, m, True) for m in range(1, 13)])

    # ETA: grade grosseira (0,2°), viés maior que o do WorldClim.
    eta = pasta / "eta"
    eta.mkdir(exist_ok=True)
    te = (X0, 0.2, 0.0, Y0, 0.0, -0.2)
    lins, cols = np.mgrid[0:10, 0:15]
    lon_e = X0 + (cols + 0.5) * 0.2
    etas = []
    for var in ("tmin", "tmax", "prec"):
        bandas = []
        for mes in range(1, 13):
            s = np.cos(2 * np.pi * (mes - 1) / 12)
            if var == "tmax":
                b = 29 + 0.8 * s + 1.2 * (lon_e + 37)
            elif var == "tmin":
                b = 20 + 0.5 * s + 0.6 * (lon_e + 37)
            else:
                b = np.clip((60 + 50 * np.cos(2 * np.pi * (mes - 6) / 12)) * 0.5 + 10 * (lon_e + 37), 0, None)
            bandas.append(b.astype("float32"))
        if var == "tmax":
            # Como no Portal de Projeções do INPE: um GeoTIFF por mês, mês e variável no nome,
            # sem NoData declarado e com o código -999000000 nas células sem dado.
            for mes, b in enumerate(bandas, 1):
                b = b.copy()
                b[0, :] = -999000000.0           # fora da área
                if mes == 7:
                    b[ETA_PIXEL_INVALIDO] = -999000000.0  # dentro da área: deve ser descartado
                nome = f"Modelo_Regional_Eta_HadGEM2-ES__Histórico_Média_Temperatura_Máxima_Mensal_{MESES_PT[mes - 1]}.tif"
                _tif(eta / nome, [b], te, None)
                etas.append({"arquivo": f"eta/{nome}", "unidade": "°C", "periodo": "1961-2005"})
            continue
        p = eta / f"eta_hadgem2es_{var}_1961-2005.tif"
        _tif(p, bandas, te, -9999.0)
        etas.append({"arquivo": str(p.relative_to(pasta)), "variavel": var,
                     "unidade": "mm/mês" if var == "prec" else "°C", "periodo": "1961-2005"})

    area = pasta / "area"
    area.mkdir(exist_ok=True)
    _shapefile(area / "area_teste.shp")

    linhas = []
    for sid, (eid, nome, lon, lat, loc) in enumerate(ESTACOES):
        for var in ("tmin", "tmax", "prec"):
            if eid == "A006":
                for mes in range(1, 13):
                    vals = [valor_obs(var, mes, lon, a, sid) for a in range(1961, 1991)]
                    linhas.append(dict(estacao_id=eid, nome=nome, local_id=loc, lon=lon, lat=lat, variavel=var,
                                       tipo_dado="normal", ano="", mes=mes, valor=f"{np.mean(vals):.2f}".replace(".", ","),
                                       unidade="°C" if var != "prec" else "mm", periodo_normal="1961-1990",
                                       fonte="sintético", dias_faltantes=""))
                continue
            anos = range(1965, 2006)
            if eid == "A002" and var == "tmin":
                anos = range(1986, 2006)  # só 15 anos dentro de 1970–2000
            for ano in anos:
                for mes in range(1, 13):
                    linhas.append(dict(estacao_id=eid, nome=nome, local_id=loc, lon=lon, lat=lat, variavel=var,
                                       tipo_dado="serie", ano=ano, mes=mes,
                                       valor=round(valor_obs(var, mes, lon, ano, sid), 2),
                                       unidade="°C" if var != "prec" else "mm", periodo_normal="",
                                       fonte="sintético", dias_faltantes=0))
    # Uma duplicata idêntica e um mês incompleto, para testar os descartes.
    linhas.append(dict(linhas[0]))
    linhas[63]["dias_faltantes"] = 15  # A001 tmin, 1970, abril
    with (pasta / "observados.csv").open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(linhas[0]), delimiter=";")
        w.writeheader()
        w.writerows(linhas)

    trabalho = {
        "area": "area/area_teste.shp",
        "worldclim_historico": hist,
        "worldclim_projecao": [f"worldclim/wc2.1_30s_{v}_ACCESS-CM2_ssp585_2081-2100.tif" for v in ("tmin", "tmax", "prec")],
        "eta_historico": etas,
        "observados": {"arquivo": "observados.csv", "fonte_declarada": "Dados sintéticos de teste",
                       "tipo_declarado": "serie e normal", "confirmo_responsabilidade": True},
        "saida": "saida",
        "parametros": {"politica_abaixo_minimo": "manter",
                       "simbologia": {"tmin": {"min": 18, "max": 28}, "tmax": {"min": 26, "max": 38}},
                       "classes_area": {"prec": [30, 60, 90]}},
    }
    p = pasta / "trabalho.json"
    p.write_text(json.dumps(trabalho, ensure_ascii=False, indent=2), encoding="utf-8")
    return p


if __name__ == "__main__":
    import sys
    print(gerar(Path(sys.argv[1] if len(sys.argv) > 1 else "dados_teste")))
