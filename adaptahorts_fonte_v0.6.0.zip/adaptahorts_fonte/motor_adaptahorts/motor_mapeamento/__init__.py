"""Motor de mapeamento climático do AdaptaHorts.

Correção regional (método Delta) de projeções CMIP6/WorldClim v2.1 com
dados observados do INMET/BDMEP, avaliação comparativa com o ETA-HadGEM2-ES
(período histórico), estatísticas, rasters corrigidos, layouts bilíngues
(PyQGIS), relatório de validação e manifesto com hashes SHA-256.

Referência metodológica: Lima et al. (2026), Land Degradation & Development,
doi:10.1002/ldr.70808, seções 2.6 e 2.8.
"""

__version__ = "0.6.0"
