"""Planilha-modelo de dados observados (INMET/BDMEP): leitura, regras de período,
consolidação por local e média regional com peso igual por local.

Usa apenas a biblioteca padrão e GDAL/OGR (para .xlsx/.ods)."""

from __future__ import annotations

import csv
import itertools
import math
import re
from dataclasses import dataclass, field
from pathlib import Path
from statistics import mean

from . import geo
from .config import AVISO_RESPONSABILIDADE_PT, VARIAVEIS, DecisaoNecessaria, ErroValidacao

COLUNAS = ["estacao_id", "nome", "local_id", "lon", "lat", "variavel", "tipo_dado", "ano", "mes", "valor",
           "unidade", "periodo_normal", "fonte", "dias_faltantes", "regiao"]
# Variáveis aceitas na planilha: as três corrigidas nos mapas e duas usadas em avaliação (tendências).
VARIAVEIS_OBS = {**{k: v["tipo"] for k, v in VARIAVEIS.items()}, "tmed": "temperatura", "etp": "precipitacao"}
REFERENCIA_ANO_CENTRAL = None  # calculado da janela de referência (1970–2000 → 1985,0)
COLUNAS_OBRIGATORIAS = ["estacao_id", "lon", "lat", "variavel", "tipo_dado", "mes", "valor", "unidade"]

UNIDADES = {
    "temperatura": {"°c", "ºc", "c", "degc", "graus c", "celsius"},
    "precipitacao": {"mm", "mm/mês", "mm/mes", "mm/month", "mm mês-1", "mm mes-1"},
}

DESCRICAO_COLUNAS = {
    "estacao_id": "Código da estação (ex.: código OMM/INMET). Obrigatório.",
    "nome": "Nome da estação. Opcional.",
    "local_id": "Identificador do local. Estações com o mesmo local_id contam como um só local. Opcional.",
    "lon": "Longitude em graus decimais (WGS 84), negativa a oeste. Obrigatório.",
    "lat": "Latitude em graus decimais (WGS 84), negativa ao sul. Obrigatório.",
    "variavel": "tmin, tmax ou prec (corrigidas nos mapas); tmed e etp também são aceitas, para tendências e "
                "avaliação. Obrigatório.",
    "tipo_dado": "'serie' (um valor por ano e mês) ou 'normal' (normal climatológica mensal). Obrigatório.",
    "ano": "Ano do valor mensal. Obrigatório quando tipo_dado = serie; vazio para normal.",
    "mes": "Mês (1 a 12). Obrigatório.",
    "valor": "Temperatura: média mensal em °C. Precipitação e ETp: total mensal em mm. Decimal com ponto ou vírgula.",
    "unidade": "°C para tmin/tmax; mm (total mensal) para prec. Obrigatório.",
    "periodo_normal": "Período da normal, ex.: 1961-1990. Obrigatório quando tipo_dado = normal.",
    "fonte": "Origem dos dados, ex.: INMET/BDMEP. Opcional, recomendado.",
    "dias_faltantes": "Dias sem registro no mês (séries). Se informado, meses acima do limite são descartados.",
    "regiao": "Sub-região da estação, ex.: interior ou litoral. Opcional. Se preenchida, a média regional é a média "
              "das sub-regiões (cada uma com peso igual), como no artigo.",
}


def _num(v) -> float | None:
    s = str(v if v is not None else "").strip().replace(",", ".")
    if s in ("", "nan", "None", "NaN", "NA"):
        return None
    try:
        x = float(s)
    except ValueError:
        return None
    return x if math.isfinite(x) else None


def ler_planilha(caminho: Path) -> list[dict]:
    suf = caminho.suffix.lower()
    if suf in (".xlsx", ".ods"):
        try:
            linhas = geo.ler_tabela_ogr(caminho, "dados")
        except Exception as exc:  # noqa: BLE001
            raise ErroValidacao([f"Planilha '{caminho.name}': não foi possível ler ({exc})."])
    elif suf in (".csv", ".txt"):
        texto = caminho.read_text(encoding="utf-8-sig")
        primeira = texto.splitlines()[0] if texto.strip() else ""
        sep = ";" if primeira.count(";") > primeira.count(",") else ","
        linhas = list(csv.DictReader(texto.splitlines(), delimiter=sep))
    else:
        raise ErroValidacao([f"Planilha de observados '{caminho.name}': formato não suportado (use .xlsx, .ods ou .csv)."])
    if not linhas:
        raise ErroValidacao(["Planilha de observados sem registros."])
    norm = []
    cab = {str(k).strip().lower() for k in linhas[0].keys() if k is not None}
    faltam = [c for c in COLUNAS_OBRIGATORIAS if c not in cab]
    if faltam:
        raise ErroValidacao([f"Planilha de observados sem as colunas obrigatórias: {', '.join(faltam)}."])
    for i, l in enumerate(linhas):
        d = {str(k).strip().lower(): ("" if v is None else str(v).strip()) for k, v in l.items() if k is not None}
        if not any(d.get(c, "") for c in COLUNAS_OBRIGATORIAS):
            continue
        d = {c: d.get(c, "") for c in COLUNAS}
        d["linha_planilha"] = i + 2
        norm.append(d)
    if not norm:
        raise ErroValidacao(["Planilha de observados sem registros."])
    return norm


@dataclass
class ResultadoObservados:
    estacoes: list[dict]
    valores: list[dict]
    regional: list[dict]
    avisos: list[str] = field(default_factory=list)
    descartes: dict = field(default_factory=dict)
    abaixo_minimo: list[dict] = field(default_factory=list)
    tendencias: list[dict] = field(default_factory=list)

    def valor_regional(self, var: str, mes: int) -> dict | None:
        return next((r for r in self.regional if r["variavel"] == var and r["mes"] == mes), None)

    def usados(self, var: str, mes: int) -> list[dict]:
        return [v for v in self.valores if v["variavel"] == var and v["mes"] == mes and v["status"] == "usado"]

    def estacoes_publicas(self) -> list[dict]:
        return [{k: v for k, v in e.items() if k != "local"} | {"local": e["local"].split(":", 1)[1]}
                for e in self.estacoes]


def _normalizar(linhas: list[dict], erros: list[str]) -> list[dict]:
    contagem: dict[str, list[int]] = {}

    def erro(ln, msg):
        contagem.setdefault(msg, []).append(ln)

    out = []
    for d in linhas:
        ln = d["linha_planilha"]
        r = dict(d)
        r["variavel"] = d["variavel"].lower()
        r["tipo_dado"] = {"série": "serie", "normais": "normal"}.get(d["tipo_dado"].lower(), d["tipo_dado"].lower())
        r["lon"], r["lat"], r["mes"], r["ano"] = _num(d["lon"]), _num(d["lat"]), _num(d["mes"]), _num(d["ano"])
        r["valor"], r["dias_faltantes"] = _num(d["valor"]), _num(d["dias_faltantes"])
        r["periodo_normal"] = re.sub(r"\s*[-–]\s*", "-", d["periodo_normal"])
        if not r["estacao_id"]:
            erro(ln, "estacao_id vazio.")
        if r["variavel"] not in VARIAVEIS_OBS:
            erro(ln, "variavel deve ser tmin, tmax, prec, tmed ou etp.")
        if r["tipo_dado"] not in ("serie", "normal"):
            erro(ln, "tipo_dado deve ser 'serie' ou 'normal'.")
        if r["lon"] is None or not -180 <= r["lon"] <= 180:
            erro(ln, "lon ausente ou fora de [-180, 180].")
        if r["lat"] is None or not -90 <= r["lat"] <= 90:
            erro(ln, "lat ausente ou fora de [-90, 90].")
        if r["mes"] is None or r["mes"] not in range(1, 13):
            erro(ln, "mes deve ser inteiro de 1 a 12.")
        if r["valor"] is None:
            erro(ln, "valor ausente ou não numérico.")
        if r["tipo_dado"] == "serie" and r["ano"] is None:
            erro(ln, "ano obrigatório para tipo_dado = serie.")
        if r["tipo_dado"] == "normal" and not re.match(r"^\d{4}-\d{4}$", r["periodo_normal"]):
            erro(ln, "periodo_normal obrigatório (AAAA-AAAA) para tipo_dado = normal.")
        if r["variavel"] in VARIAVEIS_OBS and d["unidade"].lower() not in UNIDADES[VARIAVEIS_OBS[r["variavel"]]]:
            erro(ln, "unidade incompatível (use °C para tmin/tmax/tmed e mm para prec/etp, total mensal).")
        r["regiao"] = d.get("regiao", "").strip()
        if r["mes"] is not None:
            r["mes"] = int(r["mes"])
        if r["ano"] is not None:
            r["ano"] = int(r["ano"])
        out.append(r)
    for msg, lns in contagem.items():
        mostra = ", ".join(map(str, lns[:15])) + (f" e mais {len(lns) - 15}" if len(lns) > 15 else "")
        erros.append(f"Planilha, linha(s) {mostra}: {msg}")
    return out


def _centro(periodo: str) -> float:
    a0, a1 = map(int, periodo.split("-"))
    return (a0 + a1) / 2.0


def media_localidade(itens: list[dict]) -> tuple[float, int, int]:
    """Média da localidade: estações → locais (média simples por local) → sub-regiões (se informadas) → média.
    Retorna (média, n_locais, n_regioes)."""
    locais: dict[str, list[float]] = {}
    reg_local: dict[str, str] = {}
    for v in itens:
        locais.setdefault(v["local"], []).append(v["valor"])
        reg_local[v["local"]] = v.get("regiao") or ""
    med_local = {l: mean(x) for l, x in locais.items()}
    regioes = {reg_local[l] for l in med_local}
    if regioes == {""}:
        return mean(med_local.values()), len(med_local), 0
    por_reg: dict[str, list[float]] = {}
    for l, m in med_local.items():
        por_reg.setdefault(reg_local[l] or "(sem região)", []).append(m)
    return mean(mean(x) for x in por_reg.values()), len(med_local), len(por_reg)


def reta(xs: list[float], ys: list[float]) -> tuple[float, float]:
    """Mínimos quadrados: (inclinação por ano, intercepto)."""
    n = len(xs)
    mx, my = sum(xs) / n, sum(ys) / n
    sxx = sum((x - mx) ** 2 for x in xs)
    b = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sxx
    return b, my - b * mx


def _anual(var: str, mensal: list[float]) -> float:
    return sum(mensal) if VARIAVEIS_OBS[var] == "precipitacao" else mean(mensal)


def consolidar_regional(usados: list[dict], params: dict, avisos: list[str]) -> tuple[list[dict], list[dict]]:
    """Média regional por variável e mês e, com normais de dois ou mais períodos, as taxas por década.

    Taxa (Lima et al., 2026, seção 2.7): para cada período de normal (1961–1990, 1981–2010, 1991–2020) calcula-se
    a média de todas as estações disponíveis na localidade (peso igual por local e, se houver coluna regiao, por
    sub-região); a taxa por década é a inclinação da reta dessas médias contra o ano central de cada período.

    Referência para o delta (método "tendencia"): cada normal é levada ao ano central da janela do WorldClim
    (1985,0 para 1970–2000) pela taxa da localidade, valor + taxa × (1985 − ano central)/10; a estação fica com a
    média dos seus períodos ajustados e entra na média da localidade junto com as estações de série (média em
    1970–2000). Quando todas as estações têm todos os períodos, isso é igual ao valor da reta em 1985."""
    j0, j1 = params["janela_referencia"]
    ref = (j0 + j1) / 2.0
    metodo = params.get("normais_metodo", "tendencia")
    regional, tend = [], []
    for var, mes in sorted({(v["variavel"], v["mes"]) for v in usados}):
        us = [v for v in usados if v["variavel"] == var and v["mes"] == mes]
        normais = [v for v in us if v["tipo_dado"] == "normal"]
        taxa = None
        pers = sorted({v["periodo_normal"] for v in normais}, key=_centro)
        if normais:
            base_taxa = normais
            if params.get("normais_taxa_estacoes", "todas") == "completas":
                n_per = {}
                for v in normais:
                    n_per.setdefault(v["estacao_id"], set()).add(v["periodo_normal"])
                completas = {e for e, ps in n_per.items() if len(ps) == len(pers)}
                if completas:
                    base_taxa = [v for v in normais if v["estacao_id"] in completas]
            per_vals = {}
            for per in pers:
                m, nl, nr = media_localidade([v for v in base_taxa if v["periodo_normal"] == per])
                per_vals[per] = {"media": m, "n_locais": nl, "n_regioes": nr}
            linha_t = {"variavel": var, "mes": mes, "periodos": ";".join(pers),
                       **{f"media_{p}": per_vals[p]["media"] for p in pers},
                       **{f"n_locais_{p}": per_vals[p]["n_locais"] for p in pers}, "taxa_por_decada": None}
            if len(pers) >= 2:
                b, a = reta([_centro(p) for p in pers], [per_vals[p]["media"] for p in pers])
                taxa = b * 10
                linha_t["taxa_por_decada"] = taxa
                linha_t[f"reta_em_{ref:g}"] = a + b * ref
            tend.append(linha_t)
        # valor de referência de cada estação
        por_est: dict[str, list[dict]] = {}
        for v in us:
            por_est.setdefault(v["estacao_id"], []).append(v)
        itens = []
        for eid, vs in por_est.items():
            if vs[0]["tipo_dado"] == "serie":
                itens.append({**vs[0]})
                continue
            if metodo == "tendencia" and taxa is not None:
                val = mean(v["valor"] + taxa * (ref - _centro(v["periodo_normal"])) / 10 for v in vs)
            else:
                val = mean(v["valor"] for v in vs)
            for v in vs:
                v["valor_ajustado_referencia"] = (v["valor"] + taxa * (ref - _centro(v["periodo_normal"])) / 10
                                                  if metodo == "tendencia" and taxa is not None else v["valor"])
            itens.append({**vs[0], "valor": val})
        valor, n_loc, n_reg = media_localidade(itens)
        partes = []
        if any(v["tipo_dado"] == "serie" for v in us):
            partes.append(f"séries em {j0}–{j1}")
        if normais:
            partes.append(f"normais {', '.join(pers)}" + (f" levadas a {ref:g} pela taxa de {taxa:+.3f}/década"
                                                         if metodo == "tendencia" and taxa is not None else ""))
        regional.append({"variavel": var, "mes": mes, "valor_regional": valor,
                         "n_estacoes": len(por_est), "n_locais": n_loc, "n_regioes": n_reg,
                         "taxa_por_decada": taxa, "referencia": "; ".join(partes),
                         "estacoes": ";".join(sorted(por_est))})
    # linha anual das taxas (temperatura: média dos meses; precipitação e ETp: soma dos meses)
    for var in sorted({t["variavel"] for t in tend}):
        ls = [t for t in tend if t["variavel"] == var and t["taxa_por_decada"] is not None]
        if len(ls) == 12:
            tend.append({"variavel": var, "mes": "anual", "periodos": ls[0]["periodos"],
                         "taxa_por_decada": _anual(var, [t["taxa_por_decada"] for t in ls])})
    difere: dict[str, list] = {}
    for t in tend:
        ns = {k[9:]: v for k, v in t.items() if k.startswith("n_locais_")}
        if len(set(ns.values())) > 1:
            difere.setdefault(t["variavel"], []).append((t["mes"], ns))
    for var, ms in difere.items():
        ns = ms[0][1]
        avisos.append(f"{var}, meses {','.join(str(m) for m, _ in ms)}: número de locais difere entre os períodos das "
                      f"normais ({', '.join(f'{k}: {v}' for k, v in ns.items())}); a taxa mistura mudança do clima e "
                      "mudança na composição das estações. Para usar na taxa só as estações com todos os períodos, "
                      "defina normais_taxa_estacoes = completas.")
    return regional, tend


def processar_observados(caminho: Path, area: geo.Area, params: dict,
                         necessarios: set[tuple[str, int]]) -> ResultadoObservados:
    erros: list[str] = []
    avisos: list[str] = []
    descartes = {"duplicatas_identicas": 0, "anos_fora_janela": 0, "meses_incompletos": 0}
    linhas = _normalizar(ler_planilha(caminho), erros)
    if erros:
        raise ErroValidacao(erros)

    por_est: dict[str, list[dict]] = {}
    for r in linhas:
        por_est.setdefault(r["estacao_id"], []).append(r)
    for eid, rs in por_est.items():
        if len({(r["lon"], r["lat"]) for r in rs}) > 1:
            erros.append(f"Estação {eid}: coordenadas diferentes entre linhas da planilha.")
        if len({r["local_id"] for r in rs if r["local_id"]}) > 1:
            erros.append(f"Estação {eid}: mais de um local_id atribuído.")
        if len({r["regiao"] for r in rs if r["regiao"]}) > 1:
            erros.append(f"Estação {eid}: mais de uma regiao atribuída.")
        for var in VARIAVEIS_OBS:
            tipos = {r["tipo_dado"] for r in rs if r["variavel"] == var}
            if len(tipos) > 1:
                erros.append(f"Estação {eid}, {var}: mistura de 'serie' e 'normal'; envie apenas um tipo por "
                             "estação e variável.")
            pers = {r["periodo_normal"] for r in rs if r["variavel"] == var and r["tipo_dado"] == "normal"}
            if len(pers) > 1 and params.get("normais_metodo", "tendencia") == "unica":
                erros.append(f"Estação {eid}, {var}: mais de um período de normal; mantenha apenas o desejado.")

    # Duplicatas: idênticas são descartadas; conflitantes são erro.
    vistos: dict[tuple, float] = {}
    unicos = []
    for r in linhas:
        k = (r["estacao_id"], r["variavel"], r["tipo_dado"], r["mes"], r["ano"], r["periodo_normal"])
        if k in vistos:
            if vistos[k] == r["valor"]:
                descartes["duplicatas_identicas"] += 1
                continue
            desc = f", ano {k[4]}" if k[4] is not None else f", normal {k[5]}"
            erros.append(f"Valores conflitantes para estação {k[0]}, {k[1]}, mês {k[3]}{desc}.")
            continue
        vistos[k] = r["valor"]
        unicos.append(r)
    if erros:
        raise ErroValidacao(erros[:40] + ([f"... e mais {len(erros) - 40} erros."] if len(erros) > 40 else []))

    # Cadastro de estações e distância à área.
    estacoes = []
    dmax = params.get("distancia_max_estacao_km")
    for eid, rs in sorted(por_est.items()):
        r0 = rs[0]
        e = {"estacao_id": eid, "nome": next((r["nome"] for r in rs if r["nome"]), ""),
             "local_id": next((r["local_id"] for r in rs if r["local_id"]), ""),
             "lon": r0["lon"], "lat": r0["lat"], "fonte": next((r["fonte"] for r in rs if r["fonte"]), ""),
             "regiao": next((r["regiao"] for r in rs if r["regiao"]), "")}
        e["distancia_area_km"] = round(area.distancia_km(e["lon"], e["lat"]), 3)
        e["dentro_area"] = e["distancia_area_km"] <= 0
        e["incluida"], e["motivo_exclusao"] = True, ""
        if dmax is not None and e["distancia_area_km"] > float(dmax):
            e["incluida"], e["motivo_exclusao"] = False, f"a mais de {dmax} km da área"
        e["local_origem"] = "informado" if e["local_id"] else "coordenadas"
        e["local"] = ("local:" + e["local_id"]) if e["local_id"] else f"coord:{round(e['lon'], 6)},{round(e['lat'], 6)}"
        estacoes.append(e)
        if e["incluida"] and not e["dentro_area"]:
            avisos.append(f"Estação {eid} ({e['nome'] or 'sem nome'}) fica fora da área, a {e['distancia_area_km']:.1f} km.")
    por_local: dict[str, list[str]] = {}
    for e in estacoes:
        if e["local_origem"] == "coordenadas":
            por_local.setdefault(e["local"], []).append(e["estacao_id"])
    for ids in por_local.values():
        if len(ids) > 1:
            avisos.append(f"Estações com coordenadas idênticas consolidadas como um local: {', '.join(ids)}.")
    lim = float(params["distancia_estacoes_proximas_km"])
    inc = [e for e in estacoes if e["incluida"]]
    for a, b in itertools.combinations(inc, 2):
        if a["local"] != b["local"]:
            d = geo.distancia_haversine_km(a["lon"], a["lat"], b["lon"], b["lat"])
            if d < lim:
                avisos.append(f"Estações {a['estacao_id']} e {b['estacao_id']} estão a {d:.2f} km e não compartilham "
                              "local_id; foram mantidas como locais distintos. Revise.")
    cad = {e["estacao_id"]: e for e in estacoes}

    j0, j1 = params["janela_referencia"]
    minimo = int(params["anos_minimos_recomendados"])
    lim_falta = params["max_dias_faltantes_mes"]
    grupos: dict[tuple, list[dict]] = {}
    for r in unicos:
        if not cad[r["estacao_id"]]["incluida"]:
            continue
        if r["tipo_dado"] == "serie":
            if not j0 <= r["ano"] <= j1:
                descartes["anos_fora_janela"] += 1
                continue
            if r["dias_faltantes"] is not None and r["dias_faltantes"] > lim_falta:
                descartes["meses_incompletos"] += 1
                continue
        grupos.setdefault((r["estacao_id"], r["variavel"], r["mes"], r["tipo_dado"], r["periodo_normal"]), []).append(r)

    valores = []
    periodos_normais = set()
    metodo_normais = params.get("normais_metodo", "tendencia")
    if metodo_normais not in ("tendencia", "media", "unica"):
        raise ErroValidacao([f"normais_metodo inválido: {metodo_normais} (use tendencia, media ou unica)."])
    for (eid, var, mes, tipo, per), rs in sorted(grupos.items(), key=lambda kv: tuple(str(x) for x in kv[0])):
        if tipo == "serie":
            anos = sorted(r["ano"] for r in rs)
            v = dict(valor=mean(r["valor"] for r in rs), anos_validos=len(anos), anos=f"{anos[0]}–{anos[-1]}")
        else:
            a0, a1 = map(int, per.split("-"))
            sobre = max(0, min(a1, j1) - max(a0, j0) + 1)
            v = dict(valor=rs[0]["valor"], anos_validos=sobre, anos=f"sobreposição {sobre} anos")
            periodos_normais.add(per)
        # Normais com método "tendencia": a referência vem da reta das médias regionais por período,
        # então a sobreposição individual de cada normal com 1970–2000 não se aplica.
        abaixo_min = v["anos_validos"] < minimo and not (tipo == "normal" and metodo_normais == "tendencia")
        valores.append({"estacao_id": eid, "local": cad[eid]["local"], "regiao": cad[eid]["regiao"], "variavel": var,
                        "mes": mes, "tipo_dado": tipo, "periodo_normal": per, **v,
                        "abaixo_minimo": abaixo_min, "status": "usado"})
    for per in sorted(periodos_normais):
        a0, a1 = map(int, per.split("-"))
        if (a0 < j0 or a1 > j1) and metodo_normais != "tendencia":
            avisos.append(f"Normal {per}: inclui anos fora da janela {j0}–{j1} do WorldClim; a média observada e a "
                          "climatologia WorldClim não são temporalmente equivalentes.")
    if not valores:
        raise ErroValidacao(["Nenhum valor observado válido após aplicar a janela de referência e os filtros."])

    abaixo = [v for v in valores if v["abaixo_minimo"] and (v["variavel"], v["mes"]) in necessarios]
    politica = params["politica_abaixo_minimo"]
    if abaixo:
        resumo: dict[tuple, dict] = {}
        for v in abaixo:
            k = (v["estacao_id"], v["variavel"])
            resumo.setdefault(k, {"meses": [], "anos": v["anos_validos"]})
            resumo[k]["meses"].append(v["mes"])
            resumo[k]["anos"] = min(resumo[k]["anos"], v["anos_validos"])
        msgs = [f"Estação {eid}, {var}: {r['anos']} anos válidos em {j0}–{j1} (mínimo recomendado {minimo}); "
                f"meses {','.join(map(str, sorted(r['meses'])))}." for (eid, var), r in sorted(resumo.items())]
        if politica == "perguntar":
            raise DecisaoNecessaria(msgs, "politica_abaixo_minimo", ["manter", "excluir"])
        if politica == "excluir":
            for v in abaixo:
                v["status"] = "excluido_abaixo_minimo"
            avisos.extend(m + " Excluída por decisão do usuário." for m in msgs)
        elif politica == "manter":
            avisos.extend(m + " Mantida por decisão do usuário." for m in msgs)
        else:
            raise ErroValidacao([f"politica_abaixo_minimo inválida: {politica}."])

    usados = [v for v in valores if v["status"] == "usado"]
    regional, tendencias = consolidar_regional(usados, params, avisos)
    tem = {(r["variavel"], r["mes"]) for r in regional}
    faltam = sorted(necessarios - tem)
    if faltam:
        raise ErroValidacao([f"Sem dados observados válidos para {v}, mês {m}." for v, m in faltam])
    for r in regional:
        if (r["variavel"], r["mes"]) in necessarios and r["n_locais"] < 3:
            avisos.append(f"{r['variavel']}, mês {r['mes']}: delta calculado com apenas {r['n_locais']} local(is); "
                          "a dispersão entre estações não pode ser avaliada adequadamente.")
    return ResultadoObservados(estacoes, valores, regional, avisos, descartes, abaixo, tendencias)


EXEMPLO = [
    ["82994", "Maceió", "", "-35.70", "-9.55", "tmax", "serie", "1971", "1", "30,4", "°C", "", "INMET/BDMEP", "0", ""],
    ["82994", "Maceió", "", "-35.70", "-9.55", "prec", "serie", "1971", "1", "45,2", "mm", "", "INMET/BDMEP", "2", ""],
    ["83097", "Propriá", "", "-36.84", "-10.21", "tmin", "normal", "", "1", "22,1", "°C", "1961-1990",
     "INMET - Normais Climatológicas", "", ""],
]
REGRAS = [
    "Os valores de exemplo são fictícios: apague-os antes de preencher.",
    "Séries: apenas anos entre 1970 e 2000 (climatologia WorldClim v2.1) são usados.",
    "Recomenda-se pelo menos 20 anos válidos por estação, variável e mês nessa janela.",
    "Normais: informe todos os períodos disponíveis de cada estação (1961-1990, 1981-2010, 1991-2020). Para cada "
    "período, o motor faz a média de todas as estações da localidade; a taxa por década é a reta dessas médias, e a "
    "referência para a correção é o valor da reta em 1985 (centro de 1970–2000).",
    "Cada estação deve ter um único tipo de dado (serie ou normal) por variável.",
    "tmed e etp são opcionais: entram nas tendências e na avaliação, não na correção dos mapas.",
    "regiao (opcional): ex.: interior e litoral; a média da localidade passa a ser a média das sub-regiões.",
    "Temperatura: média mensal (°C). Precipitação: total mensal (mm).",
    "Estações no mesmo local: use o mesmo local_id para que contem como um só local.",
    AVISO_RESPONSABILIDADE_PT,
]


def criar_modelo_planilha(destino: Path) -> Path:
    """Gera a planilha-modelo (.xlsx ou .csv) com exemplos e instruções."""
    destino = Path(destino)
    destino.parent.mkdir(parents=True, exist_ok=True)
    if destino.suffix.lower() == ".csv":
        with destino.open("w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f, delimiter=";")
            w.writerow(COLUNAS)
            w.writerows(EXEMPLO)
        return destino
    geo.escrever_xlsx(destino, [
        ("dados", COLUNAS, EXEMPLO),
        ("colunas", ["coluna", "descricao"], [[k, v] for k, v in DESCRICAO_COLUNAS.items()]),
        ("regras", ["regra"], [[r] for r in REGRAS]),
    ])
    return destino
