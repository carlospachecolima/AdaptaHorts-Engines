"""Orquestração: validação preliminar e processamento completo de um trabalho."""

from __future__ import annotations

import csv
import json
import platform
import shutil
import tempfile
import zipfile
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np

from . import __version__, geo
from .calculo import (aplicar_ajuste, area_celulas_km2, avaliar_eta, calcular_ajuste, diagnostico_pareado,
                      estatisticas, media_regional, media_regional_eta)
from .config import (AVISO_RESPONSABILIDADE_EN, AVISO_RESPONSABILIDADE_PT, MESES, VARIAVEIS, Cancelado,
                     ErroValidacao, Trabalho, carregar_trabalho)
from .entradas import (alinhadas, area_dentro, checar_grade_worldclim, expandir_entradas, grade_da_area,
                       identificar_eta, identificar_historico, identificar_projecao, inspecionar_raster, ler_area,
                       ler_banda_na_grade, mascara_area, sha256)
from .observados import processar_observados

NODATA_SAIDA = -9999.0
ARQUIVOS_PREVIOS = {"validacao_preliminar.json", "trabalho.json", "entradas"}  # "entradas": pasta do complemento


@dataclass
class Preparacao:
    trabalho: Trabalho
    temp: Path
    area: Any
    historicos: dict[tuple[str, int], dict]
    projecoes: dict[str, dict]
    etas: dict[tuple[str, int], dict]
    combinacao: dict
    grade: Any
    obs: Any
    avisos: list[str] = field(default_factory=list)
    entradas_hash: dict = field(default_factory=dict)


def preparar(trabalho: Trabalho, temp: Path) -> Preparacao:
    """Valida todas as entradas. Reúne o máximo de erros antes de interromper."""
    p = trabalho.parametros
    erros: list[str] = []
    avisos: list[str] = []

    obs_cfg = trabalho.observados
    if obs_cfg.get("confirmo_responsabilidade") is not True:
        erros.append("É necessário confirmar a responsabilidade pelos dados observados "
                     "(observados.confirmo_responsabilidade = true). Texto: " + AVISO_RESPONSABILIDADE_PT)
    for campo in ("arquivo", "fonte_declarada", "tipo_declarado"):
        if not obs_cfg.get(campo):
            erros.append(f"Observados: informe '{campo}'.")

    area = None
    try:
        area = ler_area(trabalho.area, temp)
    except ErroValidacao as e:
        erros.extend(e.mensagens)

    historicos: dict[tuple[str, int], dict] = {}
    try:
        for item in expandir_entradas(trabalho.worldclim_historico, trabalho.caminho, temp, "worldclim_historico"):
            try:
                h = identificar_historico(item)
            except ErroValidacao as e:
                erros.extend(e.mensagens)
                continue
            k = (h["variavel"], h["mes"])
            if k in historicos:
                erros.append(f"WorldClim histórico duplicado para {k[0]}, mês {k[1]}.")
            h["info"] = inspecionar_raster(h["arquivo"])
            if h["info"].bandas != 1:
                erros.append(f"WorldClim histórico '{h['arquivo'].name}': esperado 1 banda; encontradas {h['info'].bandas}.")
            erros.extend(checar_grade_worldclim(h["info"], p, "WorldClim histórico"))
            historicos[k] = h
    except ErroValidacao as e:
        erros.extend(e.mensagens)

    projecoes: dict[str, dict] = {}
    try:
        for item in expandir_entradas(trabalho.worldclim_projecao, trabalho.caminho, temp, "worldclim_projecao"):
            try:
                f = identificar_projecao(item)
            except ErroValidacao as e:
                erros.extend(e.mensagens)
                continue
            if f["variavel"] in projecoes:
                erros.append(f"Mais de uma projeção para {f['variavel']}.")
            f["info"] = inspecionar_raster(f["arquivo"])
            if f["info"].bandas != 12:
                erros.append(f"Projeção '{f['arquivo'].name}': esperado 12 bandas mensais; encontradas {f['info'].bandas}.")
            erros.extend(checar_grade_worldclim(f["info"], p, "Projeção"))
            projecoes[f["variavel"]] = f
    except ErroValidacao as e:
        erros.extend(e.mensagens)

    combos = {(f["modelo"], f["ssp"], f["periodo"]) for f in projecoes.values()}
    combinacao = {}
    if len(combos) > 1:
        erros.append(f"As projeções misturam combinações modelo–SSP–período: {sorted(combos)}. "
                     "Processe uma combinação por trabalho.")
    elif combos:
        mod, ssp, per = next(iter(combos))
        combinacao = {"modelo": mod, "ssp": ssp, "periodo": per}
    if not historicos:
        erros.append("Nenhum GeoTIFF histórico do WorldClim válido.")
    vars_hist = {v for v, _ in historicos}
    for v in sorted(vars_hist - set(projecoes)):
        erros.append(f"Há histórico de {v} mas nenhuma projeção correspondente.")
    for v in sorted(set(projecoes) - vars_hist):
        avisos.append(f"Projeção de {v} enviada sem histórico; essa variável será ignorada.")

    ref = next(iter(historicos.values()))["info"] if historicos else None
    if ref is not None:
        todos = [h["info"] for h in historicos.values()] + [f["info"] for f in projecoes.values()]
        for info in todos:
            if not alinhadas(ref, info):
                erros.append(f"'{info.caminho.name}' não está na mesma grade de 30\" dos demais rasters WorldClim "
                             "(origem ou resolução diferente). Reamostragem não é feita automaticamente.")
            if area is not None and not area_dentro(info, area):
                erros.append(f"A área de estudo não está inteiramente coberta por '{info.caminho.name}'.")

    etas: dict[tuple[str, int], dict] = {}
    try:
        for item in expandir_entradas(trabalho.eta_historico, trabalho.caminho, temp, "eta_historico"):
            nome = Path(item["arquivo"]).name
            var_nome, mes_nome = identificar_eta(nome)
            var = str(item.get("variavel") or var_nome or "").lower()
            if var not in VARIAVEIS:
                erros.append(f"ETA '{nome}': não foi possível identificar a variável pelo nome; informe 'variavel' "
                             "(tmin, tmax ou prec).")
                continue
            if var_nome and item.get("variavel") and var_nome != var:
                erros.append(f"ETA '{nome}': o nome indica {var_nome}, mas o arquivo foi informado como {var}.")
                continue
            if not item.get("unidade"):
                erros.append(f"ETA '{nome}': informe 'unidade' (temperatura: °C ou K; precipitação: mm/mês ou mm/dia).")
                continue
            if not item.get("periodo"):
                erros.append(f"ETA '{nome}': informe o 'periodo' histórico (ex.: 1961-2005).")
            info = inspecionar_raster(item["arquivo"])
            mes_inf = item.get("mes") if item.get("mes") not in (None, "") else None
            if mes_inf is not None or (info.bandas == 1 and mes_nome is not None):
                mes = int(mes_inf if mes_inf is not None else mes_nome)
                if mes_inf is not None and mes_nome is not None and int(mes_inf) != mes_nome:
                    erros.append(f"ETA '{nome}': o nome indica o mês {mes_nome}, mas foi informado o mês {mes_inf}.")
                    continue
                if info.bandas != 1 and "banda" not in item:
                    erros.append(f"ETA '{nome}': {info.bandas} bandas; informe 'banda' para o mês {mes}.")
                    continue
                pares = [(mes, int(item.get("banda", 1)))]
            elif info.bandas == 12:
                pares = [(m, m) for m in range(1, 13)]
            else:
                erros.append(f"ETA '{nome}': não foi possível identificar o mês pelo nome (ex.: ..._Mensal_Abril.tif); "
                             "informe 'mes' ou use um arquivo de 12 bandas.")
                continue
            for mes, banda in pares:
                if (var, mes) in etas:
                    erros.append(f"ETA duplicado para {var}, mês {mes}.")
                etas[(var, mes)] = {**item, "variavel": var, "mes": mes, "banda": banda, "info": info}
    except ErroValidacao as e:
        erros.extend(e.mensagens)
    analisados = set(historicos)
    for k in sorted(analisados - set(etas)):
        avisos.append(f"Sem ETA histórico para {k[0]}, mês {k[1]}; esse mês não entra na avaliação comparativa.")

    obs_path = trabalho.caminho(obs_cfg["arquivo"]) if obs_cfg.get("arquivo") else None
    if obs_path is not None and not obs_path.exists():
        erros.append(f"Planilha de observados não encontrada: {obs_path}")
    if erros:
        raise ErroValidacao(erros)

    obs = processar_observados(obs_path, area, p, analisados)
    avisos.extend(obs.avisos)
    grade = grade_da_area(ref, area)

    hashes = {}
    for f in [trabalho.area, obs_path] + [h["origem"] for h in historicos.values()] + \
             [f["origem"] for f in projecoes.values()] + [e["origem"] for e in etas.values()]:
        hashes[str(Path(f).name)] = sha256(Path(f))
    return Preparacao(trabalho, temp, area, historicos, projecoes, etas, combinacao, grade, obs, avisos, hashes)


def resumo_validacao(prep: Preparacao) -> dict:
    return {
        "situacao": "valido",
        "combinacao": prep.combinacao,
        "variaveis_meses": sorted([list(k) for k in prep.historicos]),
        "eta_meses": sorted([list(k) for k in prep.etas]),
        "estacoes": prep.obs.estacoes_publicas(),
        "medias_observadas": prep.obs.regional,
        "tendencias_normais": prep.obs.tendencias,
        "avisos": prep.avisos,
        "aviso_responsabilidade": AVISO_RESPONSABILIDADE_PT,
    }


def validar(caminho_trabalho: str | Path) -> dict:
    t = carregar_trabalho(caminho_trabalho)
    with tempfile.TemporaryDirectory(prefix="adaptahorts_") as td:
        prep = preparar(t, Path(td))
        r = resumo_validacao(prep)
    t.saida.mkdir(parents=True, exist_ok=True)
    (t.saida / "validacao_preliminar.json").write_text(json.dumps(r, ensure_ascii=False, indent=2, default=str),
                                                        encoding="utf-8")
    return r


def _nome(comb: dict | None, var: str, mes: int) -> str:
    if comb is None:
        return f"Historico_1970-2000_{var}_{mes:02d}{MESES[mes - 1][2]}"
    return f"{comb['periodo']}_{comb['ssp']}_{comb['modelo']}_{var}_{mes:02d}{MESES[mes - 1][2]}"


def _gravar_tif(caminho: Path, arr: np.ndarray, grade, tags: dict, descricao: str) -> None:
    geo.gravar_geotiff(caminho, arr, grade.gt, grade.epsg, NODATA_SAIDA, tags, descricao)


def _csv(caminho: Path, linhas: list[dict]) -> None:
    campos: list[str] = []
    for l in linhas:
        for k in l:
            if k not in campos:
                campos.append(k)

    def fmt(v):
        if v is None:
            return ""
        if isinstance(v, bool):
            return "True" if v else "False"
        if isinstance(v, float):
            return "" if not np.isfinite(v) else f"{v:.6f}"
        return v

    with caminho.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=campos, lineterminator="\n")
        w.writeheader()
        for l in linhas:
            w.writerow({k: fmt(l.get(k)) for k in campos})


def _versoes() -> dict:
    from osgeo import gdal
    v = {"python": platform.python_version(), "numpy": np.__version__, "gdal": gdal.__version__}
    try:
        from qgis.core import Qgis
        v["qgis"] = Qgis.QGIS_VERSION
    except Exception:
        v["qgis"] = None
    return v


class _Progresso:
    """Encaminha progresso (0–100) e verifica cancelamento entre etapas."""

    def __init__(self, progresso=None, cancelado=None, ini: float = 0.0, fim: float = 100.0):
        self._p, self._c, self._ini, self._fim = progresso, cancelado, ini, fim

    def __call__(self, pct: float, msg: str = "") -> None:
        if self._c is not None and self._c():
            raise Cancelado("Processamento cancelado pelo usuário.")
        if self._p is not None:
            v = self._ini + (self._fim - self._ini) * max(0.0, min(100.0, float(pct))) / 100.0
            self._p(v, msg)

    def faixa(self, ini: float, fim: float) -> "_Progresso":
        """Sub-etapa que ocupa [ini, fim] da faixa atual."""
        span = self._fim - self._ini
        return _Progresso(self._p, self._c, self._ini + span * ini / 100.0, self._ini + span * fim / 100.0)


def processar(caminho_trabalho: str | Path, progresso=None, cancelado=None) -> dict:
    """Processa um trabalho. progresso(pct, mensagem) e cancelado() -> bool são opcionais."""
    prog = _Progresso(progresso, cancelado)
    t = carregar_trabalho(caminho_trabalho)
    p = t.parametros
    saida = t.saida
    # Aceitos antes do processamento: a validação preliminar e a cópia do trabalho
    # (gravada pelo complemento QGIS junto dos resultados).
    if saida.exists() and any(f.name not in ARQUIVOS_PREVIOS for f in saida.iterdir()):
        raise ErroValidacao([f"O diretório de saída '{saida}' já contém resultados; use um diretório vazio."])
    saida.mkdir(parents=True, exist_ok=True)
    inicio = datetime.now(timezone.utc)
    preexistentes = {f.name for f in saida.iterdir()}
    try:
        with tempfile.TemporaryDirectory(prefix="adaptahorts_") as td:
            prog(1, "Validando entradas")
            prep = preparar(t, Path(td))
            prog(5, "Entradas válidas")
            resultado = _executar(prep, saida, prog)
    except BaseException:
        # Interrompido (erro ou cancelamento): remove resultados parciais para não parecerem válidos.
        for f in saida.iterdir():
            if f.name not in preexistentes:
                shutil.rmtree(f) if f.is_dir() else f.unlink()
        raise
    resultado["manifesto"]["execucao"] = {"inicio_utc": inicio.isoformat(),
                                          "fim_utc": datetime.now(timezone.utc).isoformat()}
    man_path = saida / "manifesto.json"
    man_path.write_text(json.dumps(resultado["manifesto"], ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    if p["gerar_zip"]:
        zpath = saida.parent / f"{saida.name}.zip"
        with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as zf:
            for f in sorted(saida.rglob("*")):
                if f.is_file():
                    zf.write(f, f.relative_to(saida.parent))
        resultado["zip"] = str(zpath)
        (saida.parent / f"{saida.name}.zip.sha256").write_text(f"{sha256(zpath)}  {zpath.name}\n")
    return resultado


def _executar(prep: Preparacao, saida: Path, prog: "_Progresso | None" = None) -> dict:
    prog = prog or _Progresso()
    t, p, grade, comb = prep.trabalho, prep.trabalho.parametros, prep.grade, prep.combinacao
    avisos = list(prep.avisos)
    dentro = mascara_area(grade, prep.area)
    if not dentro.any():
        raise ErroValidacao(["Nenhum centro de pixel de 30\" dentro da área de estudo."])
    area_cel = area_celulas_km2(grade)
    ajustes, pareados, stats_rows, arquivos_saida = [], [], [], []
    eta_linhas: dict[str, list[dict]] = {}
    camadas: list[dict] = []
    for nome in sorted(ARQUIVOS_PREVIOS):
        alvo = saida / nome
        if alvo.is_file():
            arquivos_saida.append(alvo)
        elif alvo.is_dir():
            arquivos_saida.extend(f for f in sorted(alvo.rglob("*")) if f.is_file())
    corrigidos: dict[tuple[str, str, int], np.ndarray] = {}

    chaves = sorted(prep.historicos)
    for i, (var, mes) in enumerate(chaves):
        prog(5 + 45 * i / len(chaves), f"Corrigindo {var}, mês {mes}")
        h = prep.historicos[(var, mes)]
        f = prep.projecoes[var]
        hist = ler_banda_na_grade(h["arquivo"], 1, grade)
        proj = ler_banda_na_grade(f["arquivo"], mes, grade)
        wc_media, n_px = media_regional(hist, dentro, grade, p["media_raster"])
        reg = prep.obs.valor_regional(var, mes)
        ajuste = calcular_ajuste(reg["valor_regional"], wc_media, p["metodo_delta"][var], var)
        hist_c, info_h = aplicar_ajuste(hist, dentro, ajuste, var)
        proj_c, info_p = aplicar_ajuste(proj, dentro, ajuste, var)
        if info_p["pixels_limitados_a_zero"] or info_h["pixels_limitados_a_zero"]:
            avisos.append(f"{var}, mês {mes}: {info_p['pixels_limitados_a_zero']} pixels da projeção e "
                          f"{info_h['pixels_limitados_a_zero']} do histórico ficaram negativos e foram limitados a zero.")
        corrigidos[("proj", var, mes)] = proj_c
        corrigidos[("hist", var, mes)] = hist_c

        usados = prep.obs.usados(var, mes)
        diag = diagnostico_pareado(h["arquivo"], usados, prep.obs.estacoes, int(p["raio_busca_pixel"]))
        for e in diag["estacoes"]:
            pareados.append({"variavel": var, "mes": mes, **e})
        ajustes.append({
            "variavel": var, "mes": mes, "media_observada_regional": reg["valor_regional"],
            "n_estacoes": reg["n_estacoes"], "n_locais": reg["n_locais"], "estacoes": reg["estacoes"],
            "media_worldclim_regional": wc_media, "n_pixels_area": n_px, "media_raster": p["media_raster"],
            "metodo": ajuste["metodo"], "delta": ajuste["delta"], "fator": ajuste["fator"],
            "delta_pareado_diagnostico": diag["delta_pareado"], "dp_entre_locais_pareado": diag.get("dp_entre_locais"),
            "diferenca_regional_menos_pareado": (ajuste["delta"] - diag["delta_pareado"]) if diag["delta_pareado"] is not None else None,
            "proj_pixels_limitados_a_zero": info_p["pixels_limitados_a_zero"],
            "proj_soma_negativa_removida_mm": info_p["soma_negativa_removida_mm"],
            "hist_pixels_limitados_a_zero": info_h["pixels_limitados_a_zero"],
        })
        if (var, mes) in prep.etas:
            e = prep.etas[(var, mes)]
            r = media_regional_eta(e["arquivo"], e["banda"], prep.area, e["unidade"], var, mes,
                                   bool(p["eta_pixels_tocados_se_vazio"]), e.get("nodata"))
            if r["valores_descartados_area"]:
                avisos.append(f"ETA {var}, mês {mes}: {r['valores_descartados_area']} pixel(is) da área com valor fora "
                              f"da faixa física ou código de ausência; tratados como NoData.")
            if r["selecao_pixels"] != "centro do pixel":
                avisos.append(f"ETA {var}, mês {mes}: área menor que a célula; usados pixels tocados ({r['n_pixels']}).")
            eta_linhas.setdefault(var, []).append({"mes": mes, "obs": reg["valor_regional"], "worldclim": wc_media,
                                                   "eta": r["valor"], "eta_n_pixels": r["n_pixels"],
                                                   "eta_conversao": r["conversao"],
                                                   "eta_nodata": r["nodata_usado"]})

        classes = p["classes_area"].get(var)
        for tipo, arr, nome in (("projecao", proj_c, _nome(comb, var, mes)), ("historico", hist_c, _nome(None, var, mes))):
            s = estatisticas(arr, dentro, var, area_cel, classes)
            if tipo == "projecao":
                s["anomalia_media_vs_historico_corrigido"] = s["media"] - float(np.nanmean(hist_c[dentro]))
            stats_rows.append({"produto": tipo, "variavel": var, "mes": mes, "mes_pt": MESES[mes - 1][0],
                               "mes_en": MESES[mes - 1][1], **s})
            pasta = "projecao_corrigida" if tipo == "projecao" else "historico_corrigido"
            tif = saida / "rasters" / pasta / var / f"{nome}.tif"
            tags = {"variavel": var, "mes": mes, "metodo": ajuste["metodo"], "delta": ajuste["delta"],
                    "fator": ajuste["fator"], "fonte": "WorldClim v2.1" + ("" if tipo == "historico" else f" CMIP6 {comb['modelo']}"),
                    "motor": f"motor_mapeamento {__version__}"}
            if tipo == "projecao":
                tags.update(ssp=comb["ssp"], periodo=comb["periodo"], modelo=comb["modelo"])
            _gravar_tif(tif, arr, grade, tags, f"{var} corrigido mês {mes}")
            arquivos_saida.append(tif)
            camadas.append({"tipo": tipo, "variavel": var, "mes": mes, "nome": nome, "tif": tif,
                            "n_estacoes": reg["n_estacoes"], "n_locais": reg["n_locais"]})

    # Coerência Tmin ≤ Tmax.
    coerencia = []
    for tipo in ("proj", "hist"):
        for mes in range(1, 13):
            a, b = corrigidos.get((tipo, "tmin", mes)), corrigidos.get((tipo, "tmax", mes))
            if a is not None and b is not None:
                n = int(np.sum(np.isfinite(a) & np.isfinite(b) & (a > b)))
                coerencia.append({"produto": tipo, "mes": mes, "pixels_tmin_maior_que_tmax": n})
                if n:
                    avisos.append(f"{'Projeção' if tipo == 'proj' else 'Histórico'} corrigido, mês {mes}: "
                                  f"{n} pixels com Tmin > Tmax após a correção.")

    avaliacoes = {v: avaliar_eta(v, eta_linhas.get(v, []), p["regra_validacao_eta"])
                  for v in sorted({v for v, _ in prep.historicos})}
    for v, a in avaliacoes.items():
        if a["status"] == "não validado":
            avisos.append(f"Avaliação comparativa ({v}): o ETA-HadGEM2-ES teve desempenho igual ou melhor que o "
                          f"WorldClim pelos critérios definidos; o WorldClim NÃO foi validado para {v}.")

    # Limites de simbologia.
    limites = {}
    for var in sorted({v for v, _ in prep.historicos}):
        cfg = p["simbologia"].get(var, {}) or {}
        if cfg.get("min") is not None and cfg.get("max") is not None:
            limites[var] = {"min": float(cfg["min"]), "max": float(cfg["max"]), "origem": "fixo (configuração)"}
        else:
            vals = np.concatenate([corrigidos[("proj", var, m)][dentro] for (v, m) in prep.historicos if v == var])
            vals = vals[np.isfinite(vals)]
            lo, hi = np.percentile(vals, p["percentis_simbologia"])
            if hi <= lo:
                hi = lo + 1e-6
            limites[var] = {"min": float(lo), "max": float(hi),
                            "origem": f"percentis {p['percentis_simbologia']} dos meses desta análise"}
            avisos.append(f"Simbologia de {var}: limites calculados nesta análise (percentis). Para comparar mapas "
                          f"entre cenários, modelos ou períodos, defina limites fixos em parametros.simbologia.")
        if cfg.get("qml"):
            limites[var]["qml"] = str(t.caminho(cfg["qml"]))

    tab = saida / "tabelas"
    tab.mkdir(parents=True, exist_ok=True)
    prog(50, "Gravando tabelas")
    tabelas = {
        "ajustes_delta.csv": ajustes,
        "estatisticas.csv": stats_rows,
        "estacoes.csv": prep.obs.estacoes_publicas(),
        "valores_por_estacao.csv": [{**v, "local": v["local"].split(":", 1)[1]} for v in prep.obs.valores],
        "medias_regionais_observadas.csv": prep.obs.regional,
        "tendencias_normais.csv": prep.obs.tendencias,
        "diagnostico_pareado.csv": pareados,
        "avaliacao_eta_mensal.csv": [{"variavel": v, **l} for v, a in avaliacoes.items() for l in a.get("linhas", [])],
        "coerencia_tmin_tmax.csv": coerencia,
    }
    for nome, linhas in tabelas.items():
        _csv(tab / nome, linhas)
        arquivos_saida.append(tab / nome)

    mapas_info = {"gerados": False, "motivo": "desativado (gerar_mapas = false)"}
    if p["gerar_mapas"]:
        try:
            from .layouts_qgis import gerar_layouts
            mapas_info = gerar_layouts(saida, camadas, prep, limites, prog.faixa(52, 97))
            arquivos_saida.extend(Path(x) for x in mapas_info.get("arquivos", []))
        except ImportError as exc:
            mapas_info = {"gerados": False, "motivo": f"PyQGIS indisponível: {exc}"}
            avisos.append("Mapas não gerados: PyQGIS indisponível neste ambiente.")

    prog(97, "Escrevendo relatório e manifesto")
    from .relatorio import escrever_relatorio
    rel = escrever_relatorio(saida, prep, ajustes, avaliacoes, stats_rows, limites, avisos, mapas_info, coerencia)
    arquivos_saida.append(rel)

    situacao = "concluído com avisos" if avisos else "concluído"
    manifesto = {
        "motor": {"nome": "motor_mapeamento (AdaptaHorts)", "versao": __version__},
        "interface": t.bruto.get("interface", {"nome": "linha de comando", "versao": __version__}),
        "versoes_bibliotecas": _versoes(),
        "situacao": situacao,
        "trabalho": t.bruto,
        "parametros_efetivos": p,
        "combinacao": comb,
        "referencia_historica": {"fonte": "WorldClim v2.1", "periodo": "1970-2000", "resolucao": "30 segundos de arco",
                                 "crs": "EPSG:4326"},
        "grade_analise": {"geotransform_gdal": grade.transform_lista(), "largura": grade.largura, "altura": grade.altura,
                          "crs": "EPSG:4326", "reamostragem": "nenhuma"},
        "entradas": {
            "worldclim_historico": [{"variavel": k[0], "mes": k[1], "identificacao": h["fonte_identificacao"],
                                     **h["info"].resumo()} for k, h in sorted(prep.historicos.items())],
            "worldclim_projecao": [{"variavel": v, "modelo": f["modelo"], "ssp": f["ssp"], "periodo": f["periodo"],
                                    "identificacao": f["fonte_identificacao"], **f["info"].resumo()}
                                   for v, f in sorted(prep.projecoes.items())],
            "eta_historico": [{"variavel": k[0], "mes": k[1], "banda": e["banda"], "unidade_declarada": e["unidade"],
                               "periodo": e.get("periodo"), **e["info"].resumo()} for k, e in sorted(prep.etas.items())],
            "observados": {"arquivo": Path(t.observados["arquivo"]).name,
                           "fonte_declarada": t.observados.get("fonte_declarada"),
                           "tipo_declarado": t.observados.get("tipo_declarado"),
                           "responsabilidade_confirmada": True,
                           "texto_responsabilidade_pt": AVISO_RESPONSABILIDADE_PT,
                           "texto_responsabilidade_en": AVISO_RESPONSABILIDADE_EN,
                           "registros_descartados": prep.obs.descartes},
            "sha256": prep.entradas_hash,
        },
        "ajustes_delta": ajustes,
        "tendencias_normais": prep.obs.tendencias,
        "avaliacao_comparativa_eta": {v: {k: a[k] for k in a if k != "linhas"} for v, a in avaliacoes.items()},
        "etapa_eta_adicional": {"ativada": False, "motivo": "método ainda não especificado; desativada por padrão"},
        "simbologia": limites,
        "mapas": {k: v for k, v in mapas_info.items() if k != "arquivos"},
        "avisos": avisos,
        "saidas_sha256": {str(Path(a).relative_to(saida)): sha256(Path(a)) for a in sorted(set(arquivos_saida))},
        "nota_integridade": "SHA-256 garante integridade dos arquivos, não autoria.",
    }
    return {"situacao": situacao, "saida": str(saida), "avisos": avisos, "manifesto": manifesto,
            "avaliacoes": avaliacoes, "ajustes": ajustes, "mapas": mapas_info}
