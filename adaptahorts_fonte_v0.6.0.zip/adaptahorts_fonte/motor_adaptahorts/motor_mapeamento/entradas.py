"""Leitura e validação das entradas espaciais: ZIPs, GeoTIFFs, shapefile e grade de análise."""

from __future__ import annotations

import hashlib
import math
import re
import shutil
import unicodedata
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

from . import geo
from .config import SSPS, VARIAVEIS, ErroValidacao
from .geo import Area, GeoTransform, InfoRaster

RE_HIST = re.compile(r"^wc2\.1_(30s|2\.5m|5m|10m)_(tmin|tmax|prec)_(\d{2})\.tiff?$", re.I)
RE_FUT = re.compile(
    r"^wc2\.1_(30s|2\.5m|5m|10m)_(tmin|tmax|prec)_(.+)_(ssp\d{3})_(\d{4})-(\d{4})\.tiff?$", re.I)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for bloco in iter(lambda: f.read(1024 * 1024), b""):
            h.update(bloco)
    return h.hexdigest()


def extrair_zip_seguro(zip_path: Path, destino: Path) -> list[Path]:
    """Extrai um ZIP impedindo path traversal. Testa a integridade antes."""
    try:
        with zipfile.ZipFile(zip_path) as zf:
            ruim = zf.testzip()
            if ruim is not None:
                raise ErroValidacao([f"{zip_path.name}: arquivo corrompido dentro do ZIP ({ruim})."])
            raiz = destino.resolve()
            saida: list[Path] = []
            for info in zf.infolist():
                alvo = (destino / info.filename).resolve()
                if alvo != raiz and raiz not in alvo.parents:
                    raise ErroValidacao([f"{zip_path.name}: caminho inseguro no ZIP ({info.filename})."])
                if info.is_dir():
                    alvo.mkdir(parents=True, exist_ok=True)
                    continue
                alvo.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(info) as src, alvo.open("wb") as dst:
                    shutil.copyfileobj(src, dst)
                saida.append(alvo)
            return saida
    except zipfile.BadZipFile:
        raise ErroValidacao([f"{zip_path.name}: não é um ZIP válido ou está corrompido."])


def expandir_entradas(entradas: list[Any], resolver, temp: Path, rotulo: str) -> list[dict]:
    """Converte entradas (caminho ou dict) em dicts {arquivo, origem, ...}; expande ZIPs."""
    out: list[dict] = []
    erros: list[str] = []
    for i, e in enumerate(entradas):
        item = {"arquivo": e} if isinstance(e, (str, Path)) else dict(e)
        if "arquivo" not in item:
            erros.append(f"{rotulo}[{i}]: falta o campo 'arquivo'.")
            continue
        p = resolver(item["arquivo"])
        if not p.exists():
            erros.append(f"{rotulo}: arquivo não encontrado: {p}")
            continue
        if p.suffix.lower() == ".zip":
            arquivos = extrair_zip_seguro(p, temp / f"{rotulo}_{i}_{p.stem}")
            tifs = sorted(a for a in arquivos if a.suffix.lower() in (".tif", ".tiff"))
            if not tifs:
                erros.append(f"{rotulo}: nenhum GeoTIFF dentro de {p.name}.")
            for t in tifs:
                novo = {k: v for k, v in item.items() if k != "arquivo"}
                novo.update(arquivo=t, origem=p)
                out.append(novo)
        else:
            item.update(arquivo=p, origem=p)
            out.append(item)
    if erros:
        raise ErroValidacao(erros)
    return out


def identificar_historico(item: dict) -> dict:
    nome = Path(item["arquivo"]).name
    m = RE_HIST.match(nome)
    var = item.get("variavel") or (m.group(2).lower() if m else None)
    mes = item.get("mes") or (int(m.group(3)) if m else None)
    if var is None or mes is None:
        raise ErroValidacao([
            f"WorldClim histórico '{nome}': não foi possível identificar variável e mês pelo nome "
            f"(padrão esperado wc2.1_30s_<tmin|tmax|prec>_<MM>.tif). Informe 'variavel' e 'mes' explicitamente."])
    var = str(var).lower()
    if var not in VARIAVEIS or not 1 <= int(mes) <= 12:
        raise ErroValidacao([f"WorldClim histórico '{nome}': variável '{var}' ou mês '{mes}' inválido."])
    return {**item, "variavel": var, "mes": int(mes), "fonte_identificacao": "nome do arquivo" if m else "informado"}


def identificar_projecao(item: dict) -> dict:
    nome = Path(item["arquivo"]).name
    m = RE_FUT.match(nome)
    var = item.get("variavel") or (m.group(2).lower() if m else None)
    modelo = item.get("modelo") or (m.group(3) if m else None)
    ssp = item.get("ssp") or (SSPS.get(m.group(4).lower()) if m else None)
    periodo = item.get("periodo") or (f"{m.group(5)}-{m.group(6)}" if m else None)
    faltam = [n for n, v in (("variavel", var), ("modelo", modelo), ("ssp", ssp), ("periodo", periodo)) if not v]
    if faltam:
        raise ErroValidacao([
            f"Projeção '{nome}': não foi possível identificar {', '.join(faltam)} pelo nome "
            f"(padrão esperado wc2.1_30s_<var>_<MODELO>_<sspXYZ>_<AAAA-AAAA>.tif). Informe explicitamente."])
    var = str(var).lower()
    if var not in VARIAVEIS:
        raise ErroValidacao([f"Projeção '{nome}': variável '{var}' inválida."])
    if ssp not in SSPS.values():
        raise ErroValidacao([f"Projeção '{nome}': SSP '{ssp}' não reconhecido; use um de {list(SSPS.values())}."])
    return {**item, "variavel": var, "modelo": modelo, "ssp": ssp, "periodo": periodo,
            "fonte_identificacao": "nome do arquivo" if m else "informado"}


MESES_NOMES = {
    "janeiro": 1, "fevereiro": 2, "marco": 3, "abril": 4, "maio": 5, "junho": 6, "julho": 7, "agosto": 8,
    "setembro": 9, "outubro": 10, "novembro": 11, "dezembro": 12,
    "january": 1, "february": 2, "march": 3, "april": 4, "may": 5, "june": 6, "july": 7, "august": 8,
    "september": 9, "october": 10, "november": 11, "december": 12,
}
VARIAVEIS_NOMES = [("temperatura_maxima", "tmax"), ("temperatura_minima", "tmin"), ("precipitacao", "prec"),
                   ("tmax", "tmax"), ("tmin", "tmin"), ("prec", "prec")]


def normalizar_nome(nome: str) -> str:
    """'Histórico_Média' ou 'Hist#U00f3rico_M#U00e9dia' (ZIP sem UTF-8) → 'historico_media'."""
    nome = re.sub(r"#U([0-9a-fA-F]{4})", lambda m: chr(int(m.group(1), 16)), nome)
    nome = unicodedata.normalize("NFKD", nome).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]+", "_", nome.lower()).strip("_")


def identificar_eta(nome_arquivo: str) -> tuple[str | None, int | None]:
    """Variável e mês pelo nome dos arquivos do Portal de Projeções do INPE
    (ex.: Modelo_Regional_Eta_HadGEM2-ES__Histórico_Média_Temperatura_Máxima_Mensal_Abril.tif)."""
    n = "_" + normalizar_nome(Path(nome_arquivo).stem) + "_"
    var = next((v for chave, v in VARIAVEIS_NOMES if f"_{chave}_" in n), None)
    meses = {m for nome, m in MESES_NOMES.items() if f"_{nome}_" in n}
    return var, (meses.pop() if len(meses) == 1 else None)


def inspecionar_raster(caminho: Path) -> InfoRaster:
    try:
        return geo.inspecionar(caminho)
    except (RuntimeError, ValueError) as exc:
        raise ErroValidacao([f"{Path(caminho).name}: não foi possível ler o GeoTIFF ({exc})."])


def checar_grade_worldclim(info: InfoRaster, params: dict, rotulo: str) -> list[str]:
    erros = []
    if info.srs is None:
        return [f"{rotulo} '{info.caminho.name}': raster sem SRC (CRS)."]
    if info.epsg != 4326:
        erros.append(f"{rotulo} '{info.caminho.name}': SRC {info.resumo()['crs']}; esperado EPSG:4326 (WGS 84).")
    res, tol = params["resolucao_graus"], params["tolerancia_resolucao"]
    if not (math.isclose(abs(info.gt.dx), res, abs_tol=tol) and math.isclose(abs(info.gt.dy), res, abs_tol=tol)):
        erros.append(f"{rotulo} '{info.caminho.name}': resolução {abs(info.gt.dx):.8f}°; "
                     f"esperado {res:.8f}° (30 segundos de arco).")
    if info.gt.dy >= 0:
        erros.append(f"{rotulo} '{info.caminho.name}': grade invertida não suportada.")
    return erros


def alinhadas(a: InfoRaster, b: InfoRaster, tol_frac: float = 1e-3) -> bool:
    """Mesma resolução e origem deslocada por número inteiro de pixels."""
    if not (math.isclose(a.gt.dx, b.gt.dx, rel_tol=1e-9) and math.isclose(a.gt.dy, b.gt.dy, rel_tol=1e-9)):
        return False
    dx = (a.gt.x0 - b.gt.x0) / a.gt.dx
    dy = (a.gt.y0 - b.gt.y0) / a.gt.dy
    return abs(dx - round(dx)) < tol_frac and abs(dy - round(dy)) < tol_frac


def ler_area(caminho: Path, temp: Path) -> Area:
    if caminho.suffix.lower() == ".zip":
        arquivos = extrair_zip_seguro(caminho, temp / "area")
        shps = [a for a in arquivos if a.suffix.lower() == ".shp"]
        if len(shps) != 1:
            raise ErroValidacao([f"{caminho.name}: esperado exatamente um .shp; encontrados {len(shps)}."])
        shp = shps[0]
    else:
        shp = caminho
    if not shp.exists():
        raise ErroValidacao([f"Arquivo da área de estudo não encontrado: {shp}"])
    if shp.suffix.lower() == ".shp":
        faltam = [e for e in (".shx", ".dbf", ".prj")
                  if not any(shp.with_suffix(x).exists() for x in (e, e.upper()))]
        if faltam:
            raise ErroValidacao([f"Shapefile '{shp.name}': falta o componente {e}." for e in faltam])
    area, erros = geo.ler_vetor_area(shp)
    if erros:
        raise ErroValidacao(erros)
    return area


@dataclass
class Grade:
    gt: GeoTransform
    largura: int
    altura: int
    epsg: int = 4326

    @property
    def forma(self) -> tuple[int, int]:
        return (self.altura, self.largura)

    def transform_lista(self) -> list[float]:
        return list(self.gt.para_gdal())


def grade_da_area(ref: InfoRaster, area: Area, margem_px: int = 2) -> Grade:
    """Recorte da grade de referência que cobre a área (com margem), alinhado aos pixels."""
    minx, miny, maxx, maxy = area.limites
    t = ref.gt
    c0 = math.floor((minx - t.x0) / t.dx) - margem_px
    c1 = math.ceil((maxx - t.x0) / t.dx) + margem_px
    r0 = math.floor((maxy - t.y0) / t.dy) - margem_px
    r1 = math.ceil((miny - t.y0) / t.dy) + margem_px
    return Grade(GeoTransform(t.x0 + c0 * t.dx, t.dx, t.y0 + r0 * t.dy, t.dy), c1 - c0, r1 - r0)


def area_dentro(info: InfoRaster, area: Area) -> bool:
    minx, miny, maxx, maxy = area.limites
    l, b, r, t = info.limites
    return minx >= l and maxx <= r and miny >= b and maxy <= t


def ler_banda_na_grade(caminho: Path, banda: int, grade: Grade) -> np.ndarray:
    """Lê uma banda apenas na janela da grade de análise; NoData e fora da extensão viram NaN."""
    return geo.ler_janela(caminho, banda, grade.gt, grade.largura, grade.altura)


def mascara_area(grade: Grade, area: Area, tocados: bool = False) -> np.ndarray:
    return geo.mascara(area.wkt(), geo.srs_wgs84(), grade.gt, grade.largura, grade.altura, geo.srs_wgs84(), tocados)


def amostrar_pixel(caminho: Path, lon: float, lat: float, raio: int) -> tuple[float | None, float]:
    return geo.amostrar_pixel(caminho, lon, lat, raio)
