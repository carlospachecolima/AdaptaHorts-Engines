"""Cálculos: média regional, delta, diagnóstico pareado, avaliação ETA e estatísticas."""

from __future__ import annotations

import calendar
import math

import numpy as np

from . import geo
from .config import VARIAVEIS, ErroValidacao
from .entradas import Grade, amostrar_pixel

RAIO_TERRA_KM = 6371.0088


def pesos_lat(grade: Grade) -> np.ndarray:
    lins = np.arange(grade.altura)
    lat = grade.gt.y0 + (lins + 0.5) * grade.gt.dy
    return np.broadcast_to(np.cos(np.deg2rad(lat))[:, None], grade.forma)


def area_celulas_km2(grade: Grade) -> np.ndarray:
    lins = np.arange(grade.altura + 1)
    bordas = np.deg2rad(grade.gt.y0 + lins * grade.gt.dy)
    faixa = np.abs(np.sin(bordas[:-1]) - np.sin(bordas[1:]))
    a = RAIO_TERRA_KM ** 2 * math.radians(abs(grade.gt.dx)) * faixa
    return np.broadcast_to(a[:, None], grade.forma)


def media_regional(arr: np.ndarray, mascara: np.ndarray, grade: Grade, modo: str) -> tuple[float, int]:
    ok = mascara & np.isfinite(arr)
    n = int(ok.sum())
    if n == 0:
        raise ErroValidacao(["Nenhum pixel válido do WorldClim dentro da área de estudo."])
    if modo == "simples":
        return float(arr[ok].mean()), n
    if modo == "ponderada_area":
        return float(np.average(arr[ok], weights=pesos_lat(grade)[ok])), n
    raise ErroValidacao([f"media_raster inválida: {modo} (use 'simples' ou 'ponderada_area')."])


def calcular_ajuste(obs: float, wc: float, metodo: str, var: str) -> dict:
    if metodo == "aditivo":
        return {"metodo": "aditivo", "delta": obs - wc, "fator": None}
    if metodo == "multiplicativo":
        if var != "prec":
            raise ErroValidacao([f"Método multiplicativo só é permitido para precipitação (recebido para {var})."])
        if wc <= 0:
            raise ErroValidacao([f"{var}: média WorldClim ≤ 0; fator multiplicativo indefinido."])
        return {"metodo": "multiplicativo", "delta": obs - wc, "fator": obs / wc}
    raise ErroValidacao([f"metodo_delta inválido para {var}: {metodo}."])


def aplicar_ajuste(arr: np.ndarray, mascara: np.ndarray, ajuste: dict, var: str) -> tuple[np.ndarray, dict]:
    """Aplica o ajuste aos pixels válidos dentro da área. Fora da área = NaN."""
    out = np.full(arr.shape, np.nan, dtype="float64")
    ok = mascara & np.isfinite(arr)
    if ajuste["metodo"] == "aditivo":
        out[ok] = arr[ok] + ajuste["delta"]
    else:
        out[ok] = arr[ok] * ajuste["fator"]
    info = {"pixels_limitados_a_zero": 0, "soma_negativa_removida_mm": 0.0}
    if var == "prec":
        neg = ok & (out < 0)
        info["pixels_limitados_a_zero"] = int(neg.sum())
        info["soma_negativa_removida_mm"] = float(-out[neg].sum()) if neg.any() else 0.0
        out[neg] = 0.0
    return out, info


def diagnostico_pareado(caminho_hist, usados: list[dict], estacoes: list[dict], raio: int) -> dict:
    """WorldClim no pixel de cada estação × valor observado; agregado por local."""
    cad = {e["estacao_id"]: e for e in estacoes}
    linhas = []
    for v in usados:
        e = cad[v["estacao_id"]]
        wc, desloc = amostrar_pixel(caminho_hist, float(e["lon"]), float(e["lat"]), raio)
        linhas.append(dict(estacao_id=v["estacao_id"], local=v["local"].split(":", 1)[1], obs=v["valor"],
                           wc_pixel=wc, deslocamento_px=desloc, diferenca=None if wc is None else v["valor"] - wc))
    validas = [l for l in linhas if l["diferenca"] is not None]
    if not validas:
        return {"estacoes": linhas, "delta_pareado": None, "n_locais": 0}
    por_local: dict[str, list[float]] = {}
    for l in validas:
        por_local.setdefault(l["local"], []).append(l["diferenca"])
    difs = np.array([np.mean(v) for v in por_local.values()])
    return {
        "estacoes": linhas, "delta_pareado": float(difs.mean()), "n_locais": int(difs.size),
        "dp_entre_locais": float(difs.std(ddof=1)) if difs.size > 1 else None,
        "min": float(difs.min()), "max": float(difs.max()),
    }


# Faixas físicas aceitas para o ETA, na unidade declarada. Valores fora delas (como o código
# -999000000 dos GeoTIFFs do Portal de Projeções do INPE, que não declaram NoData) são ausência.
FAIXAS_ETA = {
    ("temperatura", "c"): (-90.0, 70.0), ("temperatura", "k"): (183.0, 343.0),
    ("precipitacao", "mes"): (0.0, 5000.0), ("precipitacao", "dia"): (0.0, 200.0),
}


def media_regional_eta(caminho, banda: int, area: geo.Area, unidade: str, var: str, mes: int,
                       usar_tocados: bool, nodata=None) -> dict:
    info = geo.inspecionar(caminho)
    if info.srs is None:
        raise ErroValidacao([f"ETA '{caminho.name}': raster sem SRC."])
    arr = geo.ler_janela(caminho, banda, info.gt, info.largura, info.altura)
    if nodata is not None:
        arr[arr == float(nodata)] = np.nan
    u0 = unidade.strip().lower()
    tipo = VARIAVEIS[var]["tipo"]
    chave = (tipo, "k" if u0 in ("k", "kelvin") else ("dia" if "dia" in u0 or "day" in u0 else
                                                       ("mes" if tipo == "precipitacao" else "c")))
    lo, hi = FAIXAS_ETA[chave]
    fora = np.isfinite(arr) & ((arr < lo) | (arr > hi))
    arr[fora] = np.nan
    modo = "centro do pixel"
    m = geo.mascara(area.wkt(), geo.srs_wgs84(), info.gt, info.largura, info.altura, info.srs)
    if not (m & np.isfinite(arr)).any():
        if not usar_tocados:
            raise ErroValidacao([f"ETA '{caminho.name}': nenhum pixel válido dentro da área."])
        m = geo.mascara(area.wkt(), geo.srs_wgs84(), info.gt, info.largura, info.altura, info.srs, tocados=True)
        modo = "pixels tocados (área menor que a célula do ETA)"
    ok = m & np.isfinite(arr)
    if not ok.any():
        raise ErroValidacao([f"ETA '{caminho.name}': nenhum pixel válido na área."])
    v = float(arr[ok].mean())
    descartados_area = int((m & fora).sum())
    nodata_usado = {"declarado_no_arquivo": info.nodata, "informado": nodata,
                    "faixa_fisica": [lo, hi], "pixels_fora_da_faixa_no_arquivo": int(fora.sum())}
    u = unidade.strip().lower()
    conv = "nenhuma"
    if VARIAVEIS[var]["tipo"] == "temperatura":
        if u in ("k", "kelvin"):
            v -= 273.15
            conv = "K → °C"
        elif u not in ("°c", "ºc", "c", "degc", "celsius"):
            raise ErroValidacao([f"ETA '{caminho.name}': unidade '{unidade}' inválida para {var} (use °C ou K)."])
    else:
        if u in ("mm/dia", "mm/day", "mm dia-1"):
            dias = calendar.monthrange(2001, mes)[1]
            v *= dias
            conv = f"mm/dia × {dias} dias"
        elif u not in ("mm", "mm/mês", "mm/mes", "mm/month"):
            raise ErroValidacao([f"ETA '{caminho.name}': unidade '{unidade}' inválida para prec (use mm/mês ou mm/dia)."])
    return {"valor": v, "n_pixels": int(ok.sum()), "selecao_pixels": modo, "conversao": conv,
            "valores_descartados_area": descartados_area, "nodata_usado": nodata_usado}


def _metricas(modelo: np.ndarray, obs: np.ndarray) -> dict:
    vies = modelo - obs
    r = None
    if obs.size >= 3 and np.std(obs) > 0 and np.std(modelo) > 0:
        r = float(np.corrcoef(modelo, obs)[0, 1])
    return {"vies_medio": float(vies.mean()), "mae": float(np.abs(vies).mean()),
            "rmse": float(np.sqrt((vies ** 2).mean())), "pearson": r}


def avaliar_eta(var: str, linhas: list[dict], regra: list[str]) -> dict:
    """linhas: [{mes, obs, worldclim, eta}] apenas meses com os três valores (amostras comparáveis)."""
    linhas = sorted(linhas, key=lambda l: l["mes"])
    if not linhas:
        return {"variavel": var, "status": "não avaliado (sem ETA)", "meses": []}
    obs = np.array([l["obs"] for l in linhas])
    wc = np.array([l["worldclim"] for l in linhas])
    eta = np.array([l["eta"] for l in linhas])
    m_wc, m_eta = _metricas(wc, obs), _metricas(eta, obs)
    criterios, inconclusivo = {}, []
    for c in regra:
        if c in ("mae", "rmse"):
            criterios[c] = m_wc[c] <= m_eta[c]
        elif c == "pearson":
            if m_wc["pearson"] is None or m_eta["pearson"] is None:
                inconclusivo.append("pearson (menos de 3 meses ou variância nula)")
            else:
                criterios[c] = m_wc["pearson"] >= m_eta["pearson"]
        else:
            raise ErroValidacao([f"regra_validacao_eta: métrica desconhecida '{c}'."])
    if inconclusivo and not criterios:
        status = "inconclusivo"
    else:
        status = "validado" if all(criterios.values()) else "não validado"
    anual = None
    if len(linhas) == 12:
        f = np.sum if var == "prec" else np.mean
        anual = {"obs": float(f(obs)), "worldclim": float(f(wc)), "eta": float(f(eta))}
    return {
        "variavel": var, "status": status, "meses": [l["mes"] for l in linhas], "n_meses": len(linhas),
        "worldclim": m_wc, "eta": m_eta, "criterios": criterios, "criterios_inconclusivos": inconclusivo,
        "regra": f"WorldClim validado se melhor ou igual ao ETA em: {', '.join(regra)}",
        "anual": anual, "linhas": linhas,
    }


def estatisticas(arr: np.ndarray, mascara: np.ndarray, var: str, area_cel: np.ndarray,
                 classes: list[float] | None = None) -> dict:
    ok = mascara & np.isfinite(arr)
    v = arr[ok]
    if v.size == 0:
        raise ErroValidacao(["Sem pixels válidos para estatísticas."])
    media, dp = float(v.mean()), float(v.std(ddof=0))
    cv = None
    if var == "prec":
        cv = (100.0 * dp / media) if media != 0 else None
    meia = 1.96 * dp / math.sqrt(v.size)
    out = {
        "n_pixels": int(v.size), "area_km2": float(area_cel[ok].sum()),
        "minimo": float(v.min()), "maximo": float(v.max()), "amplitude": float(v.max() - v.min()),
        "media": media, "mediana": float(np.median(v)), "dp_populacional": dp,
        "cv_percentual": cv, "ic95_media_inf": media - meia, "ic95_media_sup": media + meia,
    }
    if classes:
        lim = [-np.inf] + sorted(classes) + [np.inf]
        for a, b in zip(lim[:-1], lim[1:]):
            sel = ok & (arr >= a) & (arr < b)
            rot = f"area_km2_[{a:g};{b:g})"
            out[rot] = float(area_cel[sel].sum())
    return out
