"""Operações geoespaciais com GDAL/OGR e numpy apenas.

GDAL e numpy acompanham todas as instalações do QGIS e estão disponíveis em
servidores (pacote GDAL do sistema ou conda), então o motor roda nos dois lugares
sem dependências extras.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

import numpy as np
from osgeo import gdal, ogr, osr

# Não alteramos o modo de exceções do GDAL (gdal.UseExceptions), que é global e
# afetaria o QGIS e outros complementos. Os retornos são verificados explicitamente.


def _abrir_raster(caminho) -> gdal.Dataset:
    ds = gdal.Open(str(caminho))
    if ds is None:
        raise RuntimeError(gdal.GetLastErrorMsg() or f"não foi possível abrir {caminho}")
    return ds


def _ok(codigo, oque: str) -> None:
    if codigo not in (0, None):
        raise RuntimeError(f"{oque}: {gdal.GetLastErrorMsg() or f'código {codigo}'}")


def _epsg(codigo: int) -> osr.SpatialReference:
    s = osr.SpatialReference()
    _ok(s.ImportFromEPSG(codigo), f"EPSG:{codigo}")
    s.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
    return s

RAIO_TERRA_KM = 6371.0088


def srs_wgs84() -> osr.SpatialReference:
    return _epsg(4326)  # ordem lon, lat


def epsg_de(srs: osr.SpatialReference | None) -> int | None:
    if srs is None:
        return None
    s = srs.Clone()
    try:
        s.AutoIdentifyEPSG()  # retorna código de erro (ou exceção) se não identificar; ambos ignorados
    except RuntimeError:
        pass
    code = s.GetAuthorityCode(None)
    return int(code) if code and code.isdigit() else None


@dataclass(frozen=True)
class GeoTransform:
    """Transformação afim de uma grade sem rotação (norte para cima)."""
    x0: float
    dx: float
    y0: float
    dy: float  # negativo

    @classmethod
    def de_gdal(cls, gt: Sequence[float]) -> "GeoTransform":
        if gt[2] != 0 or gt[4] != 0:
            raise ValueError("grade rotacionada")
        return cls(gt[0], gt[1], gt[3], gt[5])

    def para_gdal(self) -> tuple:
        return (self.x0, self.dx, 0.0, self.y0, 0.0, self.dy)

    def lin_col(self, x: float, y: float) -> tuple[int, int]:
        return int(math.floor((y - self.y0) / self.dy)), int(math.floor((x - self.x0) / self.dx))

    def centro(self, lin: int, col: int) -> tuple[float, float]:
        return self.x0 + (col + 0.5) * self.dx, self.y0 + (lin + 0.5) * self.dy


@dataclass
class InfoRaster:
    caminho: Path
    srs: osr.SpatialReference | None
    epsg: int | None
    gt: GeoTransform
    largura: int
    altura: int
    bandas: int
    nodata: float | None
    tipo: str
    descricoes: list[str]

    @property
    def limites(self) -> tuple[float, float, float, float]:
        x1 = self.gt.x0 + self.largura * self.gt.dx
        y1 = self.gt.y0 + self.altura * self.gt.dy
        return (min(self.gt.x0, x1), min(self.gt.y0, y1), max(self.gt.x0, x1), max(self.gt.y0, y1))

    def resumo(self) -> dict:
        return {"arquivo": self.caminho.name, "crs": f"EPSG:{self.epsg}" if self.epsg else
                (self.srs.ExportToProj4() if self.srs else None),
                "resolucao": [abs(self.gt.dx), abs(self.gt.dy)], "largura": self.largura, "altura": self.altura,
                "bandas": self.bandas, "nodata": self.nodata, "tipo": self.tipo, "limites": list(self.limites)}


def inspecionar(caminho: Path) -> InfoRaster:
    ds = _abrir_raster(caminho)
    wkt = ds.GetProjection()
    srs = None
    if wkt:
        srs = osr.SpatialReference()
        srs.ImportFromWkt(wkt)
        srs.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
    b = ds.GetRasterBand(1)
    info = InfoRaster(Path(caminho), srs, epsg_de(srs), GeoTransform.de_gdal(ds.GetGeoTransform()),
                      ds.RasterXSize, ds.RasterYSize, ds.RasterCount, b.GetNoDataValue(),
                      gdal.GetDataTypeName(b.DataType),
                      [ds.GetRasterBand(i).GetDescription() for i in range(1, ds.RasterCount + 1)])
    ds = None
    return info


def ler_janela(caminho: Path, banda: int, gt_destino: GeoTransform, largura: int, altura: int) -> np.ndarray:
    """Lê a janela de uma grade alinhada; fora da extensão e NoData viram NaN (float64)."""
    ds = _abrir_raster(caminho)
    gt = GeoTransform.de_gdal(ds.GetGeoTransform())
    col0 = int(round((gt_destino.x0 - gt.x0) / gt.dx))
    lin0 = int(round((gt_destino.y0 - gt.y0) / gt.dy))
    out = np.full((altura, largura), np.nan, dtype="float64")
    c_a, l_a = max(col0, 0), max(lin0, 0)
    c_b, l_b = min(col0 + largura, ds.RasterXSize), min(lin0 + altura, ds.RasterYSize)
    if c_b > c_a and l_b > l_a:
        b = ds.GetRasterBand(banda)
        nativo = b.ReadAsArray(c_a, l_a, c_b - c_a, l_b - l_a)
        arr = nativo.astype("float64")
        nd = b.GetNoDataValue()
        if nd is not None and not np.isnan(nd):
            # compara no tipo nativo: -3.4e38 em float32 não é igual a -3.4e38 em float64
            arr[nativo == np.array(nd).astype(nativo.dtype)] = np.nan
        out[l_a - lin0:l_b - lin0, c_a - col0:c_b - col0] = arr
    ds = None
    return out


def ler_banda(caminho: Path, banda: int) -> tuple[np.ndarray, GeoTransform, osr.SpatialReference | None]:
    info = inspecionar(caminho)
    arr = ler_janela(caminho, banda, info.gt, info.largura, info.altura)
    return arr, info.gt, info.srs


def gravar_geotiff(caminho: Path, arr: np.ndarray, gt: GeoTransform, epsg: int, nodata: float,
                   tags: dict, descricao: str) -> None:
    caminho.parent.mkdir(parents=True, exist_ok=True)
    drv = gdal.GetDriverByName("GTiff")
    opcoes = ["TILED=YES", "BLOCKXSIZE=256", "BLOCKYSIZE=256", "COMPRESS=DEFLATE", "PREDICTOR=3"]
    ds = drv.Create(str(caminho), arr.shape[1], arr.shape[0], 1, gdal.GDT_Float32, options=opcoes)
    if ds is None:
        raise RuntimeError(f"não foi possível criar {caminho}: {gdal.GetLastErrorMsg()}")
    ds.SetGeoTransform(gt.para_gdal())
    ds.SetProjection(_epsg(epsg).ExportToWkt())
    ds.SetMetadata({str(k): str(v) for k, v in tags.items()})
    b = ds.GetRasterBand(1)
    b.SetNoDataValue(nodata)
    b.SetDescription(descricao)
    _ok(b.WriteArray(np.where(np.isfinite(arr), arr, nodata).astype("float32")), f"gravar {caminho.name}")
    b.FlushCache()
    ds = None
    aux = Path(str(caminho) + ".aux.xml")
    if aux.exists():
        aux.unlink()


# ----------------------------------------------------------------------------- vetores

class Area:
    """Área de estudo: um (multi)polígono em WGS 84 (lon, lat)."""

    def __init__(self, geom: ogr.Geometry):
        self.geom = geom

    @property
    def limites(self) -> tuple[float, float, float, float]:
        minx, maxx, miny, maxy = self.geom.GetEnvelope()
        return (minx, miny, maxx, maxy)

    def wkt(self) -> str:
        return self.geom.ExportToWkt()

    def para_srs(self, srs: osr.SpatialReference) -> ogr.Geometry:
        g = self.geom.Clone()
        g.AssignSpatialReference(srs_wgs84())
        alvo = srs.Clone()
        alvo.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
        _ok(g.TransformTo(alvo), "reprojetar a área")
        return g

    def srs_utm(self) -> osr.SpatialReference:
        c = self.geom.Centroid()
        lon, lat = c.GetX(), c.GetY()
        zona = int((lon + 180) // 6) + 1
        return _epsg((32700 if lat < 0 else 32600) + zona)

    def distancia_km(self, lon: float, lat: float) -> float:
        """Distância (km) do ponto à área; 0 se dentro. Calculada em UTM da área."""
        utm = self.srs_utm()
        a = self.para_srs(utm)
        p = ogr.Geometry(ogr.wkbPoint)
        p.AddPoint_2D(lon, lat)
        p.AssignSpatialReference(srs_wgs84())
        _ok(p.TransformTo(utm), "reprojetar ponto")
        return a.Distance(p) / 1000.0

    def salvar_gpkg(self, caminho: Path) -> None:
        drv = ogr.GetDriverByName("GPKG")
        if caminho.exists():
            drv.DeleteDataSource(str(caminho))
        ds = drv.CreateDataSource(str(caminho))
        if ds is None:
            raise RuntimeError(f"não foi possível criar {caminho}")
        lyr = ds.CreateLayer("area_estudo", srs_wgs84(), ogr.wkbMultiPolygon)
        lyr.CreateField(ogr.FieldDefn("nome", ogr.OFTString))
        f = ogr.Feature(lyr.GetLayerDefn())
        f.SetField("nome", "area_estudo")
        f.SetGeometry(ogr.ForceToMultiPolygon(self.geom.Clone()))
        lyr.CreateFeature(f)
        ds = None


def ler_vetor_area(caminho: Path) -> tuple[Area | None, list[str]]:
    """Lê polígonos, valida, une e reprojeta para WGS 84. Retorna (área, erros)."""
    erros: list[str] = []
    ds = ogr.Open(str(caminho))
    if ds is None or ds.GetLayerCount() == 0:
        return None, [f"Não foi possível ler a área de estudo: {Path(caminho).name}."]
    lyr = ds.GetLayer(0)
    srs = lyr.GetSpatialRef()
    if srs is None:
        return None, ["Área de estudo sem SRC (.prj ausente ou ilegível)."]
    srs = srs.Clone()
    srs.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
    trans = osr.CoordinateTransformation(srs, srs_wgs84())
    uniao = None
    n = 0
    for f in lyr:
        g = f.GetGeometryRef()
        if g is None or g.IsEmpty():
            continue
        g = g.Clone()
        tipo = ogr.GT_Flatten(g.GetGeometryType())
        if tipo not in (ogr.wkbPolygon, ogr.wkbMultiPolygon):
            erros.append("A área de estudo deve conter apenas polígonos.")
            break
        if not g.IsValid():
            g = g.MakeValid()
            if g is None:
                return None, ["A área de estudo contém geometria inválida que não pôde ser corrigida."]
        _ok(g.Transform(trans), "reprojetar a área para WGS 84")
        uniao = g if uniao is None else uniao.Union(g)
        n += 1
    ds = None
    if erros:
        return None, erros
    if uniao is None or n == 0:
        return None, ["Área de estudo sem geometrias válidas."]
    if ogr.GT_Flatten(uniao.GetGeometryType()) == ogr.wkbGeometryCollection:
        partes = [uniao.GetGeometryRef(i) for i in range(uniao.GetGeometryCount())]
        mp = ogr.Geometry(ogr.wkbMultiPolygon)
        for p in partes:
            t = ogr.GT_Flatten(p.GetGeometryType())
            if t == ogr.wkbPolygon:
                mp.AddGeometry(p)
            elif t == ogr.wkbMultiPolygon:
                for i in range(p.GetGeometryCount()):
                    mp.AddGeometry(p.GetGeometryRef(i))
        uniao = mp
    return Area(uniao), []


def mascara(area_geom_wkt: str, srs_area: osr.SpatialReference, gt: GeoTransform, largura: int, altura: int,
            srs_grade: osr.SpatialReference | None, tocados: bool = False) -> np.ndarray:
    """Pixels cujo centro está na área (regra do GDAL, a mesma do recorte do QGIS)."""
    mem = (ogr.GetDriverByName("Memory") or ogr.GetDriverByName("MEM")).CreateDataSource("m")
    lyr = mem.CreateLayer("a", srs_area, ogr.wkbMultiPolygon)
    f = ogr.Feature(lyr.GetLayerDefn())
    g = ogr.CreateGeometryFromWkt(area_geom_wkt)
    if srs_grade is not None and epsg_de(srs_grade) != epsg_de(srs_area):
        g.AssignSpatialReference(srs_area)
        alvo = srs_grade.Clone()
        alvo.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
        _ok(g.TransformTo(alvo), "reprojetar a área para a grade")
    f.SetGeometry(g)
    lyr.CreateFeature(f)
    r = gdal.GetDriverByName("MEM").Create("", largura, altura, 1, gdal.GDT_Byte)
    r.SetGeoTransform(gt.para_gdal())
    if srs_grade is not None:
        r.SetProjection(srs_grade.ExportToWkt())
    opcoes = ["ALL_TOUCHED=TRUE"] if tocados else []
    _ok(gdal.RasterizeLayer(r, [1], lyr, burn_values=[1], options=opcoes), "rasterizar a área")
    m = r.GetRasterBand(1).ReadAsArray().astype(bool)
    r = None
    mem = None
    return m


def amostrar_pixel(caminho: Path, lon: float, lat: float, raio: int) -> tuple[float | None, float]:
    """Valor no pixel do ponto; se NoData, o pixel válido mais próximo no raio. (valor, deslocamento_px)."""
    info = inspecionar(caminho)
    lin, col = info.gt.lin_col(lon, lat)
    gt = GeoTransform(info.gt.x0 + (col - raio) * info.gt.dx, info.gt.dx, info.gt.y0 + (lin - raio) * info.gt.dy,
                      info.gt.dy)
    arr = ler_janela(caminho, 1, gt, 2 * raio + 1, 2 * raio + 1)
    if np.isfinite(arr[raio, raio]):
        return float(arr[raio, raio]), 0.0
    ii, jj = np.where(np.isfinite(arr))
    if ii.size == 0:
        return None, float("nan")
    d = np.hypot(ii - raio, jj - raio)
    k = int(np.argmin(d))
    return float(arr[ii[k], jj[k]]), float(d[k])


def distancia_haversine_km(lon1: float, lat1: float, lon2: float, lat2: float) -> float:
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dl, dp = math.radians(lon2 - lon1), p2 - p1
    h = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * RAIO_TERRA_KM * math.asin(math.sqrt(h))


# ----------------------------------------------------------------------------- planilhas

def ler_tabela_ogr(caminho: Path, aba: str | None = None) -> list[dict[str, str]]:
    """Lê .xlsx/.ods via OGR como texto (primeira linha = cabeçalho)."""
    gdal.SetConfigOption("OGR_XLSX_HEADERS", "FORCE")
    gdal.SetConfigOption("OGR_XLSX_FIELD_TYPES", "STRING")
    gdal.SetConfigOption("OGR_ODS_HEADERS", "FORCE")
    gdal.SetConfigOption("OGR_ODS_FIELD_TYPES", "STRING")
    try:
        ds = ogr.Open(str(caminho))
        if ds is None:
            raise ValueError(f"não foi possível abrir {Path(caminho).name}")
        lyr = ds.GetLayerByName(aba) if aba else None
        if lyr is None:
            lyr = ds.GetLayer(0)
        defn = lyr.GetLayerDefn()
        nomes = [defn.GetFieldDefn(i).GetName() for i in range(defn.GetFieldCount())]
        linhas = []
        for f in lyr:
            linhas.append({n: (f.GetFieldAsString(i) if f.IsFieldSetAndNotNull(i) else "") for i, n in enumerate(nomes)})
        ds = None
        return linhas
    finally:
        for k in ("OGR_XLSX_HEADERS", "OGR_XLSX_FIELD_TYPES", "OGR_ODS_HEADERS", "OGR_ODS_FIELD_TYPES"):
            gdal.SetConfigOption(k, None)


def escrever_xlsx(caminho: Path, abas: list[tuple[str, list[str], list[list]]]) -> None:
    """Cria um .xlsx com várias abas de texto via OGR."""
    drv = ogr.GetDriverByName("XLSX")
    if caminho.exists():
        caminho.unlink()
    ds = drv.CreateDataSource(str(caminho))
    if ds is None:
        raise RuntimeError(f"não foi possível criar {caminho}")
    for nome, cab, linhas in abas:
        lyr = ds.CreateLayer(nome, geom_type=ogr.wkbNone)
        for c in cab:
            lyr.CreateField(ogr.FieldDefn(c, ogr.OFTString))
        for l in linhas:
            f = ogr.Feature(lyr.GetLayerDefn())
            for i, v in enumerate(l):
                f.SetField(i, "" if v is None else str(v))
            lyr.CreateFeature(f)
    ds = None


# ----------------------------------------------------------------------------- utilidades do módulo de risco

def ler_feicoes(caminho: Path) -> list[tuple[ogr.Geometry, dict]]:
    """Lê feições (geometria em WGS 84, atributos como texto) da primeira camada."""
    ds = ogr.Open(str(caminho))
    if ds is None or ds.GetLayerCount() == 0:
        raise RuntimeError(f"não foi possível ler {Path(caminho).name}")
    lyr = ds.GetLayer(0)
    srs = lyr.GetSpatialRef()
    trans = None
    if srs is not None:
        srs = srs.Clone()
        srs.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
        trans = osr.CoordinateTransformation(srs, srs_wgs84())
    defn = lyr.GetLayerDefn()
    nomes = [defn.GetFieldDefn(i).GetName() for i in range(defn.GetFieldCount())]
    out = []
    for f in lyr:
        g = f.GetGeometryRef()
        if g is None or g.IsEmpty():
            continue
        g = g.Clone()
        if not g.IsValid():
            g = g.MakeValid() or g
        if trans is not None:
            _ok(g.Transform(trans), f"reprojetar feição de {Path(caminho).name}")
        attrs = {n: (f.GetFieldAsString(i) if f.IsFieldSetAndNotNull(i) else "") for i, n in enumerate(nomes)}
        out.append((g, attrs))
    ds = None
    return out


def rasterizar_valores(feicoes: list[tuple[ogr.Geometry, float]], gt: GeoTransform, largura: int, altura: int,
                       tocados: bool = False) -> np.ndarray:
    """Rasteriza valores numéricos de polígonos (WGS 84) na grade; fora dos polígonos = NaN."""
    mem = (ogr.GetDriverByName("Memory") or ogr.GetDriverByName("MEM")).CreateDataSource("v")
    lyr = mem.CreateLayer("v", srs_wgs84(), ogr.wkbUnknown)
    lyr.CreateField(ogr.FieldDefn("valor", ogr.OFTReal))
    for g, v in feicoes:
        f = ogr.Feature(lyr.GetLayerDefn())
        f.SetField("valor", float(v))
        f.SetGeometry(g)
        lyr.CreateFeature(f)
    r = gdal.GetDriverByName("MEM").Create("", largura, altura, 1, gdal.GDT_Float64)
    r.SetGeoTransform(gt.para_gdal())
    r.SetProjection(srs_wgs84().ExportToWkt())
    b = r.GetRasterBand(1)
    b.Fill(np.nan)
    opcoes = ["ATTRIBUTE=valor"] + (["ALL_TOUCHED=TRUE"] if tocados else [])
    _ok(gdal.RasterizeLayer(r, [1], lyr, options=opcoes), "rasterizar polígonos")
    arr = b.ReadAsArray().astype("float64")
    r = None
    mem = None
    return arr


def reamostrar_para_grade(caminho: Path, gt: GeoTransform, largura: int, altura: int, metodo: str = "bilinear") -> np.ndarray:
    """Reprojeta/reamostra a banda 1 para a grade (WGS 84); NoData e fora da extensão = NaN."""
    src = _abrir_raster(caminho)
    nd = src.GetRasterBand(1).GetNoDataValue()
    dst = gdal.GetDriverByName("MEM").Create("", largura, altura, 1, gdal.GDT_Float64)
    dst.SetGeoTransform(gt.para_gdal())
    dst.SetProjection(srs_wgs84().ExportToWkt())
    dst.GetRasterBand(1).Fill(np.nan)
    dst.GetRasterBand(1).SetNoDataValue(float("nan"))
    opc = gdal.WarpOptions(resampleAlg=metodo, srcNodata=nd, dstNodata=float("nan"))
    res = gdal.Warp(dst, src, options=opc)
    if res is None:
        raise RuntimeError(f"falha ao reamostrar {Path(caminho).name}: {gdal.GetLastErrorMsg()}")
    arr = dst.GetRasterBand(1).ReadAsArray().astype("float64")
    src = dst = None
    return arr


def ponto_em(feicoes: list[tuple[ogr.Geometry, dict]], lon: float, lat: float) -> int | None:
    p = ogr.Geometry(ogr.wkbPoint)
    p.AddPoint_2D(lon, lat)
    for i, (g, _) in enumerate(feicoes):
        if g.Contains(p) or g.Touches(p):
            return i
    return None
