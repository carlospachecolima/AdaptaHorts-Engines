"""Relatório de validação em Markdown (português)."""

from __future__ import annotations

from pathlib import Path

from . import __version__
from .config import AVISO_RESPONSABILIDADE_PT, MESES, VARIAVEIS


def _f(x, d=2):
    if x is None:
        return "—"
    try:
        return f"{float(x):.{d}f}"
    except (TypeError, ValueError):
        return str(x)


def _tabela(cab: list[str], linhas: list[list]) -> str:
    out = ["| " + " | ".join(cab) + " |", "|" + "|".join("---" for _ in cab) + "|"]
    out += ["| " + " | ".join(str(c) for c in l) + " |" for l in linhas]
    return "\n".join(out)


def escrever_relatorio(saida: Path, prep, ajustes, avaliacoes, stats_rows, limites, avisos, mapas, coerencia) -> Path:
    t, comb, p = prep.trabalho, prep.combinacao, prep.trabalho.parametros
    j0, j1 = p["janela_referencia"]
    L = [f"# Relatório de validação — motor de mapeamento AdaptaHorts v{__version__}", ""]
    L += [f"**Modelo:** {comb['modelo']} · **Cenário:** {comb['ssp']} · **Período:** {comb['periodo']}  ",
          f"**Referência histórica:** WorldClim v2.1, {j0}–{j1}, 30 segundos de arco (EPSG:4326)  ",
          f"**Situação:** {'concluído com avisos' if avisos else 'concluído'}", ""]

    L += ["## Responsabilidade pelos dados observados", "", f"> {AVISO_RESPONSABILIDADE_PT}", "",
          f"Fonte declarada: **{t.observados.get('fonte_declarada')}** · tipo declarado: "
          f"**{t.observados.get('tipo_declarado')}** · confirmação: **sim**", ""]

    L += ["## Método", "",
          "Correção regional pelo método Delta (Lima et al., 2026, *Land Degradation & Development*, seção 2.6): "
          "para cada variável e mês, o ajuste é a diferença entre a média regional das estações (peso igual por local) "
          "e a média regional dos pixels do WorldClim histórico dentro da área. O mesmo ajuste é aplicado à projeção "
          "CMIP6 e ao histórico WorldClim. Precipitação corrigida negativa é limitada a zero.", "",
          f"- Média raster: **{p['media_raster']}**",
          f"- Métodos: " + ", ".join(f"{v} = {m}" for v, m in p["metodo_delta"].items()),
          f"- Janela de referência: {j0}–{j1}; mínimo recomendado: {p['anos_minimos_recomendados']} anos válidos "
          f"(política para abaixo do mínimo: **{p['politica_abaixo_minimo']}**)",
          "- Reamostragem: nenhuma (grades WorldClim idênticas exigidas)", ""]

    est = prep.obs.estacoes_publicas()
    L += ["## Estações", "", _tabela(
        ["Estação", "Nome", "Local", "Lon", "Lat", "Dist. à área (km)", "Incluída"],
        [[e["estacao_id"], e["nome"] or "—", e["local"], _f(e["lon"], 4), _f(e["lat"], 4),
          _f(e["distancia_area_km"], 1), "sim" if e["incluida"] else f"não ({e['motivo_exclusao']})"] for e in est]),
        "", f"Registros descartados: {prep.obs.descartes}", ""]

    L += ["## Ajustes mensais (Delta)", ""]
    for var in VARIAVEIS:
        linhas = [a for a in ajustes if a["variavel"] == var]
        if not linhas:
            continue
        u = VARIAVEIS[var]["unidade_pt"]
        L += [f"### {VARIAVEIS[var]['pt']} ({u})", "", _tabela(
            ["Mês", "Obs. regional", "WorldClim regional", "Delta", "Fator", "N estações / locais",
             "Delta pareado (diag.)", "DP entre locais", "Pixels limitados a 0"],
            [[MESES[a["mes"] - 1][0], _f(a["media_observada_regional"]), _f(a["media_worldclim_regional"]),
              f"{a['delta']:+.2f}", _f(a["fator"], 3), f"{a['n_estacoes']} / {a['n_locais']}",
              _f(a["delta_pareado_diagnostico"]), _f(a["dp_entre_locais_pareado"]),
              a["proj_pixels_limitados_a_zero"]] for a in linhas]), ""]
    L += ["O delta pareado (WorldClim no pixel de cada estação) é apenas diagnóstico; não é aplicado aos rasters.", ""]

    tend = prep.obs.tendencias
    if tend:
        ref = (j0 + j1) / 2
        L += ["## Normais climatológicas: médias da localidade e taxas por década", "",
              "Para cada período de normal, a média é de todas as estações disponíveis na localidade (peso igual por "
              "local e, se informada, por sub-região). A taxa por década é a inclinação da reta dessas médias contra o "
              f"ano central de cada período (Lima et al., 2026, seção 2.7). A referência usada no delta é o valor da "
              f"reta em {ref:g}, ano central da climatologia WorldClim ({j0}–{j1}).", ""]
        nomes = {"tmin": "Tmin (°C)", "tmax": "Tmax (°C)", "tmed": "Tmed (°C)", "prec": "Prec (mm)", "etp": "ETp (mm)"}
        for var in [v for v in nomes if any(t["variavel"] == v for t in tend)]:
            ls = [t for t in tend if t["variavel"] == var]
            pers = sorted({p for t in ls for p in t["periodos"].split(";") if p})
            ref_var = {r["mes"]: r["valor_regional"] for r in prep.obs.regional if r["variavel"] == var}
            linhas = []
            for t in ls:
                rot = "Anual" if t["mes"] == "anual" else MESES[t["mes"] - 1][0]
                linhas.append([rot] + [_f(t.get(f"media_{p}")) for p in pers] +
                              [_f(ref_var.get(t["mes"])) if t["mes"] != "anual" else "—",
                               (f"{t['taxa_por_decada']:+.3f}" if t.get("taxa_por_decada") is not None else "—")])
            L += [f"### {nomes[var]}", "", _tabela(["Mês"] + pers + [f"Referência {ref:g}", "Taxa por década"], linhas),
                  ""]
        L += ["Taxa anual: média dos meses (temperatura) ou soma dos meses (precipitação e ETp). Tmed e ETp não "
              "corrigem os mapas; servem para avaliação.", ""]

    L += ["## Avaliação comparativa WorldClim × ETA-HadGEM2-ES (histórico)", ""]
    for var, a in avaliacoes.items():
        L += [f"### {VARIAVEIS[var]['pt']}", ""]
        if not a.get("meses"):
            L += [f"Não avaliado: {a['status']}.", ""]
            continue
        L += [f"**Resultado: {a['status']}** — {a['regra']}. Meses comparados: {a['n_meses']}.", "",
              _tabela(["Fonte", "Viés médio", "MAE", "RMSE", "r de Pearson"],
                      [["WorldClim v2.1", _f(a["worldclim"]["vies_medio"]), _f(a["worldclim"]["mae"]),
                        _f(a["worldclim"]["rmse"]), _f(a["worldclim"]["pearson"], 3)],
                       ["ETA-HadGEM2-ES", _f(a["eta"]["vies_medio"]), _f(a["eta"]["mae"]),
                        _f(a["eta"]["rmse"]), _f(a["eta"]["pearson"], 3)]]), ""]
        if a.get("anual"):
            an = a["anual"]
            L += [f"Anual — observado {_f(an['obs'], 1)}, WorldClim {_f(an['worldclim'], 1)}, ETA {_f(an['eta'], 1)}.", ""]
        if a["criterios_inconclusivos"]:
            L += [f"Critérios inconclusivos: {', '.join(a['criterios_inconclusivos'])}.", ""]
    L += ["A etapa adicional de correção baseada no ETA está **desativada** (método não especificado).", ""]

    L += ["## Estatísticas da projeção corrigida", ""]
    for var in VARIAVEIS:
        linhas = [s for s in stats_rows if s["variavel"] == var and s["produto"] == "projecao"]
        if not linhas:
            continue
        cab = ["Mês", "Mín", "Máx", "Amplitude", "Média", "Mediana", "DP"] + (["CV (%)"] if var == "prec" else []) + ["Anomalia"]
        L += [f"### {VARIAVEIS[var]['pt']} ({VARIAVEIS[var]['unidade_pt']})", "", _tabela(cab, [
            [s["mes_pt"], _f(s["minimo"]), _f(s["maximo"]), _f(s["amplitude"]), _f(s["media"]), _f(s["mediana"]),
             _f(s["dp_populacional"])] + ([_f(s["cv_percentual"], 1)] if var == "prec" else [])
            + [f"{s['anomalia_media_vs_historico_corrigido']:+.2f}"] for s in linhas]), ""]
    L += ["DP populacional dos pixels válidos. CV apenas para precipitação. Anomalia = média projetada − média "
          "histórica corrigida.", ""]

    L += ["## Simbologia dos mapas", ""] + [
        f"- {v}: {_f(l['min'])} a {_f(l['max'])} ({l['origem']})" + (f"; estilo QML {Path(l['qml']).name}" if l.get("qml") else "")
        for v, l in limites.items()] + [""]
    L += ["## Mapas", "", (f"{mapas.get('n_mapas', 0)} layouts gerados ({', '.join(p['formatos_mapa'])})."
                           if mapas.get("gerados") else f"Não gerados: {mapas.get('motivo')}."), ""]
    L += ["## Avisos", ""] + ([f"- {a}" for a in avisos] if avisos else ["Nenhum aviso."]) + [""]
    caminho = saida / "relatorio_validacao.md"
    caminho.write_text("\n".join(L), encoding="utf-8")
    return caminho
