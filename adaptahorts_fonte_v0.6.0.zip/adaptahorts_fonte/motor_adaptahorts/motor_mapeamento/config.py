"""Parâmetros padrão, constantes e carregamento do arquivo de trabalho (JSON)."""

from __future__ import annotations

import copy
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

VARIAVEIS = {
    "tmin": {"pt": "Temperatura mínima", "en": "Minimum temperature",
             "unidade": "°C", "unidade_pt": "°C", "unidade_en": "°C", "tipo": "temperatura"},
    "tmax": {"pt": "Temperatura máxima", "en": "Maximum temperature",
             "unidade": "°C", "unidade_pt": "°C", "unidade_en": "°C", "tipo": "temperatura"},
    "prec": {"pt": "Precipitação", "en": "Precipitation",
             "unidade": "mm", "unidade_pt": "mm/mês", "unidade_en": "mm/month", "tipo": "precipitacao"},
}

MESES = [
    ("Janeiro", "January", "Jan"), ("Fevereiro", "February", "Fev"),
    ("Março", "March", "Mar"), ("Abril", "April", "Abr"),
    ("Maio", "May", "Mai"), ("Junho", "June", "Jun"),
    ("Julho", "July", "Jul"), ("Agosto", "August", "Ago"),
    ("Setembro", "September", "Set"), ("Outubro", "October", "Out"),
    ("Novembro", "November", "Nov"), ("Dezembro", "December", "Dez"),
]

SSPS = {"ssp126": "SSP1-2.6", "ssp245": "SSP2-4.5", "ssp370": "SSP3-7.0", "ssp585": "SSP5-8.5"}
PERIODOS_FUTUROS = ["2021-2040", "2041-2060", "2061-2080", "2081-2100"]

AVISO_RESPONSABILIDADE_PT = (
    "O usuário é responsável pela seleção, origem e qualidade dos dados observados "
    "fornecidos (séries de estações ou normais climatológicas), bem como por sua "
    "representatividade para a área analisada. A plataforma verifica formato, unidades, "
    "coordenadas, período e completude, mas não avalia se as estações escolhidas "
    "representam adequadamente o clima da região. A correção regional depende "
    "diretamente desses dados."
)
AVISO_RESPONSABILIDADE_EN = (
    "The user is responsible for the selection, source and quality of the observed data "
    "provided (station series or climatological normals), as well as their "
    "representativeness for the study area. The platform checks format, units, "
    "coordinates, period and completeness, but does not assess whether the selected "
    "stations adequately represent the regional climate. The regional correction "
    "depends directly on these data."
)

PADROES: dict[str, Any] = {
    # Climatologia de referência do WorldClim v2.1 e mínimo recomendado de anos.
    "janela_referencia": [1970, 2000],
    "anos_minimos_recomendados": 20,
    # O que fazer com estação/variável/mês abaixo do mínimo:
    # "perguntar" (interrompe e pede decisão), "manter" (usa e marca), "excluir".
    "politica_abaixo_minimo": "perguntar",
    # Normais climatológicas com mais de um período por estação:
    # "tendencia" (padrão; Lima et al., 2026, seção 2.7): médias da localidade por período → reta → valor no
    # ano central da janela (1985) e taxa por década; "media": média simples dos períodos; "unica": um período só.
    "normais_metodo": "tendencia",
    # Estações usadas no cálculo da taxa: "todas" (média de todas as estações disponíveis em cada período) ou
    # "completas" (só as que têm todos os períodos informados, evitando efeito de composição).
    "normais_taxa_estacoes": "todas",
    # Mês de uma série é inválido se dias_faltantes > este limite (só se a coluna existir).
    "max_dias_faltantes_mes": 10,
    # Média regional do raster: "simples" (como no artigo/QGIS) ou "ponderada_area" (cos lat).
    "media_raster": "simples",
    # Método de correção por variável: "aditivo" (artigo) ou "multiplicativo".
    "metodo_delta": {"tmin": "aditivo", "tmax": "aditivo", "prec": "aditivo"},
    # Distância máxima estação–área (km). None = aceita todas, com distância registrada.
    "distancia_max_estacao_km": None,
    # Estações distintas mais próximas que isto (km), sem local_id comum, são sinalizadas.
    "distancia_estacoes_proximas_km": 1.0,
    # Diagnóstico pareado: raio (pixels) para buscar pixel válido mais próximo.
    "raio_busca_pixel": 3,
    # Grade esperada: 30 segundos de arco.
    "resolucao_graus": 1.0 / 120.0,
    "tolerancia_resolucao": 1e-7,
    # ETA: se nenhum centro de pixel cair na área, usar pixels tocados (com aviso).
    "eta_pixels_tocados_se_vazio": True,
    # Regra de validação WorldClim × ETA: o WorldClim é validado para a variável se
    # for melhor ou igual ao ETA em todas as métricas listadas ("mae", "rmse", "pearson").
    "regra_validacao_eta": ["mae"],
    # Simbologia: por variável, {"min": x, "max": y} fixos e/ou {"qml": caminho}.
    # Sem limites fixos, usa percentis comuns aos meses da análise.
    "simbologia": {"tmin": {}, "tmax": {}, "prec": {}},
    "percentis_simbologia": [2, 98],
    # Classes para área por classe (km²), por variável: lista de limites. Opcional.
    "classes_area": {},
    "gerar_mapas": True,
    "mapas_historico": False,
    "idiomas": ["pt", "en"],
    "formatos_mapa": ["pdf", "png"],
    "dpi": 300,
    "salvar_projeto_qgis": True,
    "gerar_zip": True,
}


class ErroValidacao(Exception):
    """Erros corrigíveis encontrados na validação. Contém lista de mensagens."""

    def __init__(self, mensagens: list[str]):
        self.mensagens = list(mensagens)
        super().__init__("\n".join(f"- {m}" for m in self.mensagens))


class Cancelado(Exception):
    """O usuário cancelou o processamento."""


class DecisaoNecessaria(Exception):
    """O processamento depende de uma decisão explícita do usuário."""

    def __init__(self, mensagens: list[str], parametro: str, opcoes: list[str]):
        self.mensagens = list(mensagens)
        self.parametro = parametro
        self.opcoes = opcoes
        texto = "\n".join(f"- {m}" for m in self.mensagens)
        super().__init__(
            f"{texto}\nDefina o parâmetro '{parametro}' como um de {opcoes} e execute novamente."
        )


def _mesclar(base: dict, extra: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (extra or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _mesclar(out[k], v)
        else:
            out[k] = v
    return out


@dataclass
class Trabalho:
    arquivo: Path
    base: Path
    area: Path
    worldclim_historico: list[Any]
    worldclim_projecao: list[Any]
    eta_historico: list[dict]
    observados: dict
    saida: Path
    parametros: dict = field(default_factory=dict)
    bruto: dict = field(default_factory=dict)

    def caminho(self, p: str | Path) -> Path:
        p = Path(p)
        return p if p.is_absolute() else (self.base / p).resolve()


def carregar_trabalho(caminho: str | Path) -> Trabalho:
    caminho = Path(caminho).resolve()
    dados = json.loads(caminho.read_text(encoding="utf-8"))
    faltando = [k for k in ("area", "worldclim_historico", "worldclim_projecao", "observados", "saida")
                if k not in dados]
    if faltando:
        raise ErroValidacao([f"Arquivo de trabalho sem o campo obrigatório '{k}'." for k in faltando])
    base = caminho.parent
    params = _mesclar(PADROES, dados.get("parametros", {}))
    t = Trabalho(
        arquivo=caminho, base=base, area=Path(), worldclim_historico=[], worldclim_projecao=[],
        eta_historico=[], observados={}, saida=Path(), parametros=params, bruto=dados,
    )
    t.area = t.caminho(dados["area"])
    t.saida = t.caminho(dados["saida"])
    t.worldclim_historico = _lista(dados["worldclim_historico"])
    t.worldclim_projecao = _lista(dados["worldclim_projecao"])
    t.eta_historico = _lista(dados.get("eta_historico", []))
    t.observados = dict(dados["observados"])
    return t


def _lista(v: Any) -> list:
    return v if isinstance(v, list) else [v]
