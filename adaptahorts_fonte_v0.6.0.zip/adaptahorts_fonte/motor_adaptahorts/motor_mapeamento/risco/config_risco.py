"""Parâmetros do módulo de risco climático (ameaça × exposição × vulnerabilidade).

Cada valor padrão traz a origem. "Modelo integrado" = documento "Modelagem integrada de risco
climático na olericultura" (Pacheco Lima, Embrapa Hortaliças/CNPq 18/2024), Tabela 1 e seção 3.
Valores marcados como PROPOSTA não constam dos documentos e devem ser revisados pelo autor.
"""

from __future__ import annotations

PARAMETROS_RISCO: dict = {
    # ---------------------------------------------------------------- pesos (médias do bootstrap)
    # Médias das distribuições bootstrap (N = 100.000; PAERC/IPSV-AF N = 10.000), IC 95%.
    # Não usar a coluna "Peso final" arredondada da Tabela 1, que diverge do bootstrap no ISCC e no ISSA.
    "pesos": {
        "isoc": {"I": 0.460, "D": 0.352, "C": 0.188},
        "isdh": {"I": 0.446, "D": 0.354, "C": 0.200},
        "iscc": {"I": 0.372, "D": 0.231, "C": 0.397},
        "issa": {"I": 0.432, "D": 0.406, "C": 0.162},
        "paerc": {"CE": 0.473, "CT": 0.388, "CI": 0.139},
    },
    # Agregação da ameaça: média ponderada dos índices disponíveis (renormalizada se faltar algum).
    "pesos_ameaca": {"isoc": 0.25, "isdh": 0.25, "iscc": 0.25, "issa": 0.25},  # PROPOSTA: pesos iguais

    # ---------------------------------------------------------------- ET0 / ETc (Modelo integrado, seção 4)
    "kc_alface": 1.00,              # FAO-56, Kc médio
    "eficiencia_irrigacao": 0.85,   # gotejamento

    # ---------------------------------------------------------------- ISOC (ondas de calor)
    "isoc_tmax_critica": 30.0,      # Modelo integrado: limiar térmico crítico da alface
    "isoc_tmax_severa": 35.0,       # PROPOSTA: intensidade = 1 quando a Tmax média do mês mais quente chega a 35 °C
    "isoc_dp_diario_tmax": 2.0,     # PROPOSTA: desvio-padrão da Tmax diária no mês (°C); calibrar com dados diários do INMET

    # ---------------------------------------------------------------- ISDH (déficit hídrico)
    "isdh_deficit_relativo_dano": 0.30,  # Modelo integrado: déficits de 30–40% reduzem a biomassa em 33–43%
    "isdh_intensidade_max": 1.00,        # intensidade = déficit anual / ETc anual (0 = sem déficit; 1 = sem chuva útil)

    # ---------------------------------------------------------------- ISCC (concentração de chuvas)
    "iscc_pci_min": 10.0,   # Oliver (1980): PCI ≤ 10 = distribuição uniforme
    "iscc_pci_max": 20.0,   # Oliver (1980): PCI > 20 = forte concentração
    "iscc_r_min": 2452.0,   # Carvalho (2008): R ≤ 2452 MJ mm ha⁻¹ h⁻¹ ano⁻¹ = erosividade fraca
    "iscc_r_max": 9810.0,   # Carvalho (2008): R > 9810 = erosividade muito forte
    "iscc_excedente_encharcamento_mm": 100.0,  # PROPOSTA: mês com P − ETc ≥ 100 mm conta como encharcamento

    # ---------------------------------------------------------------- ISSA (suscetibilidade à salinização)
    "issa_ce_limiar": 1.5,  # Modelo integrado: CE crítica da alface (dS/m)
    "issa_ce_max": 6.0,     # Modelo integrado: CE 3,2–6,0 dS/m → até 58% de perda de massa fresca
    # Modo do ISSA: "suscetibilidade" (só clima; padrão) ou, se houver raster de CE do solo medida,
    # "estresse" (CE medida contra os limiares da alface).
    # CE da água de referência (dS/m), só para o produto auxiliar "ECe com água de referência":
    # limite de "nenhuma restrição de uso" da FAO-29 (Tabela 1).
    "issa_ce_agua": 0.7,
    "issa_lf_min": 0.05,    # PROPOSTA: fração de lixiviação mínima (evita ECe infinita sem drenagem)

    # ---------------------------------------------------------------- exposição e PAERC
    # Exposição = 1 − adoção de sistemas conservacionistas (≈ 10% na alface → exposição 0,90).
    "adocao_conservacionista": 0.10,
    # PAERC a partir do questionário estruturado (faixas do documento "PAERC – índice de adaptação e
    # resiliência"): agregação regional pela mediana das respostas e intervalo de confiança por bootstrap.
    "paerc_agregacao": "mediana",            # "mediana" ou "media" (o documento admite as duas)
    "paerc_diversificacao": "especies",      # "especies" (nº de espécies) ou "shannon" (H')
    "paerc_proximidade": "distancia",        # "distancia" (km) ou "tempo" (min)
    "paerc_bootstrap_iteracoes": 10000,      # documento: 10 mil iterações, IC 95%
    "paerc_bootstrap_semente": 20260101,     # semente fixa: resultados reprodutíveis
    "paerc_min_questionarios": 5,            # PROPOSTA: abaixo disso a microrregião recebe aviso

    # ---------------------------------------------------------------- classes de risco
    # PROPOSTA: intervalos iguais. Os documentos não definem limites (e classificam o mesmo valor de forma diferente).
    "classes_limites": [0.2, 0.4, 0.6, 0.8],
    "classes_nomes_pt": ["Muito baixo", "Baixo", "Médio", "Alto", "Muito alto"],
    "classes_nomes_en": ["Very low", "Low", "Medium", "High", "Very high"],

    # Modo "somente_ameaca": calcula e mapeia só os índices (ISOC, ISDH, ISCC, ISSA) e a ameaça agregada.
    "somente_ameaca": False,
    # Modo "indice": "isoc", "isdh", "iscc" ou "issa" calcula e mapeia só esse índice (com I, D e C).
    "indice": None,
    # Produtos com mapa (None = padrão do modo). Ex.: ["isoc", "isdh", "iscc", "issa", "ameaca"].
    "mapas_produtos": None,
    "gerar_mapas": True,
    "idiomas": ["pt", "en"],
    "formatos_mapa": ["pdf", "png"],
    "dpi": 300,
    "gerar_zip": True,
}

FONTES = {
    "pesos": ("Médias do bootstrap (IC 95%): ISOC-Alface 0,460/0,352/0,188 (Fig. 1 do modelo integrado); "
              "ISDH-Alface 0,446/0,354/0,200 (Fig. 2; a tabela-síntese traz 0,452/0,346/0,202); "
              "ISCC 0,372/0,231/0,397 (Fig. 3); ISSA 0,432/0,406/0,162 (Fig. 4); "
              "PAERC/IPSV-AF CE 0,473 [0,435–0,512], CT 0,388 [0,348–0,427], CI 0,139 [0,115–0,165] "
              "(Relatório técnico IPSV-AF, Tabela 2)"),
    "pesos_ameaca": "PROPOSTA (pesos iguais); os documentos indicam soma, que sairia da escala [0, 1]",
    "isoc_tmax_critica": "Modelo integrado, seção 2.1",
    "isoc_tmax_severa": "PROPOSTA",
    "isoc_dp_diario_tmax": "PROPOSTA; calibrar com Tmax diária do INMET",
    "isdh_deficit_relativo_dano": "Modelo integrado, seção 2.2",
    "iscc_pci": "Oliver (1980), Professional Geographer 32:300–309",
    "iscc_r": "Carvalho (2008), Erosividade da chuva, classes de R",
    "erosividade": "Lombardi Neto & Moldenhauer (1992): EI30 = 67,355 (r²/P)^0,85",
    "iscc_excedente_encharcamento_mm": "PROPOSTA",
    "issa_ce": "Modelo integrado, seção 2.4",
    "issa_balanco_sais": "FAO-29 (Ayers & Westcot, 1985) e Rhoades (1974): ECe = ECi (1 + LF) / (5 LF)",
    "issa_ce_agua": "FAO-29, Tabela 1: ECw < 0,7 dS/m = nenhuma restrição de uso (água de referência)",
    "issa_lf_min": "PROPOSTA",
    "et0": "Hargreaves & Samani (1985); Ra pela FAO-56 (Allen et al., 1998), dia 15 de cada mês",
    "exposicao": "Informado pelo autor: exposição = 1 − adoção de sistemas conservacionistas (≈ 10% na alface)",
    "paerc_questionario": "Documento 'PAERC – índice de adaptação e resiliência' (faixas de classificação por indicador)",
    "paerc_dimensoes": "Média simples dos indicadores de cada dimensão (o documento não define pesos internos)",
    "classes_limites": "PROPOSTA (intervalos iguais)",
}
