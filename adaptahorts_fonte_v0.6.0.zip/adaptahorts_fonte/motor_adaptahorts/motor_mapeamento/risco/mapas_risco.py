"""Layouts dos índices e do risco (PyQGIS): A4 paisagem, PDF e PNG, português e inglês."""

from __future__ import annotations

from pathlib import Path

from qgis.core import (Qgis, QgsColorRampShader, QgsCoordinateReferenceSystem, QgsFillSymbol,  # noqa: E402
                       QgsLayoutExporter, QgsLayoutItemLegend, QgsLayoutItemMap, QgsLayoutItemMapGrid,
                       QgsLayoutItemPicture, QgsLayoutItemScaleBar, QgsLayoutPoint, QgsLayoutSize,
                       QgsLegendRenderer, QgsLegendStyle, QgsMapLayerLegendUtils, QgsPalettedRasterRenderer,
                       QgsPrintLayout, QgsProject, QgsRasterLayer, QgsRasterShader, QgsScaleBarSettings,
                       QgsSingleBandPseudoColorRenderer, QgsUnitTypes, QgsVectorLayer, QgsBasicNumericFormat,
                       QgsColorRampLegendNodeSettings)
from osgeo import gdal
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor

from .. import __version__
from ..layouts_qgis import _fmt, _intervalo_grade, _rotulo, _seta_norte, iniciar_qgis
from .pipeline_risco import PRODUTOS

YLORRD = ["#ffffcc", "#ffeda0", "#fed976", "#feb24c", "#fd8d3c", "#fc4e2a", "#e31a1c", "#bd0026", "#800026"]
CORES_CLASSES = ["#1a9850", "#91cf60", "#fee08b", "#fc8d59", "#d73027"]
MAPEAR = ["isoc", "isdh", "iscc", "issa", "ecw_critica", "ameaca", "risco_potencial", "risco", "risco_classes"]
MAPEAR_AMEACA = ["isoc", "isdh", "iscc", "issa", "ecw_critica", "ameaca"]
ECW_LIMITES = (0.0, 3.0)  # dS/m; FAO-29: < 0,7 sem restrição, 0,7–3,0 restrição leve a moderada, > 3,0 severa

TX = {
    "pt": {"hist": "Histórico corrigido · 1970–2000", "proj": "Modelo: {m} · Cenário: {s} · Período: {p}",
           "fonte": "Risco = Ameaça × Exposição × (1 − PAERC). Ameaça: ISOC, ISDH, ISCC{issa} (pesos do modelo "
                    "integrado AdaptaHorts); clima: WorldClim v2.1{cmip}, corrigido com estações INMET/BDMEP.",
           "tec": "SRC: WGS 84 (EPSG:4326) · Resolução: 30 segundos de arco (≈ 0,9 km no Equador) · Motor AdaptaHorts v{v}",
           "fonte_indice": "{ind} = {i:.3f}·I + {d:.3f}·D + {c:.3f}·C (médias do bootstrap, IC 95%); clima: "
                           "WorldClim v2.1{cmip}, corrigido com estações INMET/BDMEP.",
           "classe": "Classe", "escala": "Escala 0–1"},
    "en": {"hist": "Bias-corrected historical · 1970–2000", "proj": "Model: {m} · Scenario: {s} · Period: {p}",
           "fonte": "Risk = Hazard × Exposure × (1 − PAERC). Hazard: ISOC, ISDH, ISCC{issa} (AdaptaHorts integrated "
                    "model weights); climate: WorldClim v2.1{cmip}, bias-corrected with INMET/BDMEP stations.",
           "tec": "CRS: WGS 84 (EPSG:4326) · Resolution: 30 arc-seconds (≈ 0.9 km at the Equator) · AdaptaHorts engine v{v}",
           "fonte_indice": "{ind} = {i:.3f}·I + {d:.3f}·D + {c:.3f}·C (bootstrap means, 95% CI); climate: "
                           "WorldClim v2.1{cmip}, bias-corrected with INMET/BDMEP stations.",
           "classe": "Class", "escala": "0–1 scale"},
}


def estilo_continuo(camada: QgsRasterLayer, vmin: float = 0.0, vmax: float = 1.0, invertido: bool = False) -> None:
    fn = QgsColorRampShader(vmin, vmax)
    fn.setColorRampType(QgsColorRampShader.Interpolated)
    cores = YLORRD[::-1] if invertido else YLORRD
    n = len(cores)
    fn.setColorRampItemList([QgsColorRampShader.ColorRampItem(vmin + (vmax - vmin) * i / (n - 1), QColor(c))
                             for i, c in enumerate(cores)])
    fn.setClip(False)
    num = QgsBasicNumericFormat()
    num.setNumberDecimalPlaces(1)
    num.setShowTrailingZeros(True)
    leg = QgsColorRampLegendNodeSettings()
    leg.setUseContinuousLegend(True)
    leg.setNumericFormat(num)
    fn.setLegendSettings(leg)
    sh = QgsRasterShader()
    sh.setRasterShaderFunction(fn)
    r = QgsSingleBandPseudoColorRenderer(camada.dataProvider(), 1, sh)
    r.setClassificationMin(vmin)
    r.setClassificationMax(vmax)
    camada.setRenderer(r)


def estilo_classes(camada: QgsRasterLayer, nomes: list[str]) -> None:
    classes = [QgsPalettedRasterRenderer.Class(i + 1, QColor(c), nomes[i]) for i, c in enumerate(CORES_CLASSES)]
    camada.setRenderer(QgsPalettedRasterRenderer(camada.dataProvider(), 1, classes))


def _layout(projeto, camada, contornos, nome, titulo, subtitulo, titulo_leg, rodape, tecnico, ext):
    lay = QgsPrintLayout(projeto)
    lay.initializeDefaults()
    lay.setName(nome)
    _rotulo(lay, titulo, 10, 7, 277, 10, 17, True, Qt.AlignHCenter)
    _rotulo(lay, subtitulo, 10, 17, 277, 6, 10, False, Qt.AlignHCenter)
    mapa = QgsLayoutItemMap(lay)
    mapa.setCrs(QgsCoordinateReferenceSystem("EPSG:4326"))
    mapa.setLayers(contornos + [camada])
    mapa.setKeepLayerSet(True)
    mapa.setFrameEnabled(True)
    lay.addLayoutItem(mapa)
    mapa.attemptMove(QgsLayoutPoint(14, 26, QgsUnitTypes.LayoutMillimeters))
    mapa.attemptResize(QgsLayoutSize(200, 154, QgsUnitTypes.LayoutMillimeters))
    mapa.zoomToExtent(ext)
    grade = QgsLayoutItemMapGrid("grade", mapa)
    mapa.grids().addGrid(grade)
    iv = _intervalo_grade(mapa.extent())
    grade.setIntervalX(iv)
    grade.setIntervalY(iv)
    grade.setStyle(QgsLayoutItemMapGrid.Solid)
    sym = grade.lineSymbol()
    sym.setColor(QColor(0, 0, 0, 60))
    sym.setWidth(0.1)
    grade.setFrameStyle(QgsLayoutItemMapGrid.Zebra)
    grade.setFrameWidth(1.2)
    grade.setAnnotationEnabled(True)
    grade.setAnnotationFormat(QgsLayoutItemMapGrid.DecimalWithSuffix)
    grade.setAnnotationPrecision(2 if iv < 0.1 else (1 if iv < 1 else 0))
    grade.setAnnotationTextFormat(_fmt(7))
    for lado in (QgsLayoutItemMapGrid.Left, QgsLayoutItemMapGrid.Right):
        grade.setAnnotationDirection(QgsLayoutItemMapGrid.Vertical, lado)
    leg = QgsLayoutItemLegend(lay)
    leg.setLinkedMap(mapa)
    leg.setAutoUpdateModel(False)
    raiz = leg.model().rootGroup()
    raiz.clear()
    no = raiz.addLayer(camada)
    QgsLegendRenderer.setNodeLegendStyle(no, QgsLegendStyle.Hidden)
    nos = leg.model().layerLegendNodes(no)
    if len(nos) > 1 and type(nos[0]).__name__ == "QgsSimpleLegendNode":  # remove a linha "Band 1: ... (Gray)"
        QgsMapLayerLegendUtils.setLegendNodeOrder(no, list(range(1, len(nos))))
        leg.model().refreshLayerLegend(no)
    leg.setTitle(titulo_leg)
    leg.rstyle(QgsLegendStyle.Title).setTextFormat(_fmt(10, True))
    leg.rstyle(QgsLegendStyle.SymbolLabel).setTextFormat(_fmt(8))
    if isinstance(camada.renderer(), QgsSingleBandPseudoColorRenderer):
        leg.setSymbolHeight(45)
        leg.setSymbolWidth(6)
    lay.addLayoutItem(leg)
    leg.attemptMove(QgsLayoutPoint(222, 30, QgsUnitTypes.LayoutMillimeters))
    leg.refresh()
    seta = _seta_norte()
    if seta:
        pic = QgsLayoutItemPicture(lay)
        pic.setPicturePath(seta)
        lay.addLayoutItem(pic)
        pic.attemptMove(QgsLayoutPoint(232, 112, QgsUnitTypes.LayoutMillimeters))
        pic.attemptResize(QgsLayoutSize(14, 20, QgsUnitTypes.LayoutMillimeters))
    esc = QgsLayoutItemScaleBar(lay)
    esc.setStyle("Single Box")
    esc.setLinkedMap(mapa)
    esc.setUnits(Qgis.DistanceUnit.Kilometers)
    esc.setUnitLabel("km")
    esc.setNumberOfSegmentsLeft(0)
    esc.setNumberOfSegments(2)
    esc.setSegmentSizeMode(QgsScaleBarSettings.SegmentSizeFitWidth)
    esc.setMinimumBarWidth(25)
    esc.setMaximumBarWidth(55)
    esc.setTextFormat(_fmt(7))
    lay.addLayoutItem(esc)
    esc.attemptMove(QgsLayoutPoint(222, 145, QgsUnitTypes.LayoutMillimeters))
    esc.update()
    _rotulo(lay, rodape, 14, 189, 270, 9, 7)
    _rotulo(lay, tecnico, 14, 199, 270, 6, 7)
    return lay


def _contorno(caminho: Path, nome: str, cor: str, largura: str, tracejado: bool = False) -> QgsVectorLayer:
    c = QgsVectorLayer(str(caminho), nome, "ogr")
    if not c.isValid():
        raise RuntimeError(f"Não foi possível carregar {caminho.name} no QGIS.")
    props = {"color": "0,0,0,0", "outline_color": cor, "outline_width": largura}
    if tracejado:
        props["outline_style"] = "dash"
    c.setRenderer(c.renderer().clone())
    c.renderer().setSymbol(QgsFillSymbol.createSimple(props))
    return c


def gerar_mapas(saida: Path, resultados: dict, rotulo: dict, comb: dict, prep: dict, p: dict, pa: dict | None,
                prog=None) -> dict:
    iniciar_qgis()
    projeto = QgsProject()
    projeto.setCrs(QgsCoordinateReferenceSystem("EPSG:4326"))
    projeto.setEllipsoid("EPSG:7030")
    pasta_proj = saida / "projeto_qgis"
    pasta_proj.mkdir(parents=True, exist_ok=True)
    pref = p["indice"] if p.get("indice") else "risco"
    projeto.setFileName(str(pasta_proj / f"{pref}_{rotulo['projecao']}.qgz"))
    projeto.writeEntryBool("Paths", "/Absolute", False)
    contornos = []
    if prep["area"] is not None:
        prep["area"].salvar_gpkg(pasta_proj / "area_estudo.gpkg")
        contornos.append(_contorno(pasta_proj / "area_estudo.gpkg", "Área de estudo", "30,30,30,255", "0.5"))
    if pa:
        from osgeo import ogr
        from .. import geo
        drv = ogr.GetDriverByName("GPKG")
        f = pasta_proj / "microrregioes.gpkg"
        if f.exists():
            drv.DeleteDataSource(str(f))
        d = drv.CreateDataSource(str(f))
        lyr = d.CreateLayer("microrregioes", geo.srs_wgs84(), ogr.wkbMultiPolygon)
        lyr.CreateField(ogr.FieldDefn("nome", ogr.OFTString))
        for g, a in pa["feicoes"]:
            ft = ogr.Feature(lyr.GetLayerDefn())
            ft.SetField("nome", a[pa["campo"]])
            ft.SetGeometry(ogr.ForceToMultiPolygon(g.Clone()))
            lyr.CreateFeature(ft)
        d = None
        contornos.append(_contorno(f, "Microrregiões", "70,70,70,255", "0.3", tracejado=True))
    for c in contornos:
        projeto.addMapLayer(c)
    if contornos:
        ext = contornos[0].extent()
    else:
        primeiro = sorted((saida / "rasters" / "historico").glob("*.tif"))[0]
        ext = QgsRasterLayer(str(primeiro), "x", "gdal").extent()
    ext.grow(max(ext.width(), ext.height()) * 0.05)

    tem_issa = "issa" in resultados["historico"]["produtos"]
    ind = p.get("indice")
    if ind:
        lista = p.get("mapas_produtos") or [ind, f"{ind}_I", f"{ind}_D", f"{ind}_C"] + (
            ["ecw_critica"] if ind == "issa" else [])
    else:
        lista = p.get("mapas_produtos") or (MAPEAR_AMEACA if p.get("somente_ameaca") else MAPEAR)
    itens = [(cen, prod) for cen in ("historico", "projecao") for prod in lista
             if prod in resultados[cen]["produtos"]]
    arquivos, n = [], 0
    raiz = projeto.layerTreeRoot()
    for i, (cen, prod) in enumerate(itens):
        if prog is not None:
            prog(100.0 * i / len(itens), f"Mapas: {prod} ({cen})")
        tif = saida / "rasters" / cen / f"{rotulo[cen]}_{prod}.tif"
        cam = None
        for idioma in p["idiomas"]:
            tx = TX[idioma]
            # classes: uma camada por idioma (os rótulos das classes ficam na simbologia)
            if cam is None or prod == "risco_classes":
                cam = QgsRasterLayer(str(tif), tif.stem + (f"_{idioma}" if prod == "risco_classes" else ""), "gdal")
                if not cam.isValid():
                    raise RuntimeError(f"Raster inválido para o QGIS: {tif}")
                if prod == "risco_classes":
                    estilo_classes(cam, p[f"classes_nomes_{idioma}"])
                elif prod == "ecw_critica":  # quanto menor a CE tolerável da água, maior o risco (vermelho)
                    estilo_continuo(cam, *ECW_LIMITES, invertido=True)
                else:
                    estilo_continuo(cam)
                projeto.addMapLayer(cam, False)
                (raiz.findGroup(cen) or raiz.addGroup(cen)).addLayer(cam)
            desc = PRODUTOS[prod][0 if idioma == "pt" else 1]
            sub = tx["hist"] if cen == "historico" else tx["proj"].format(m=comb.get("modelo"), s=comb.get("ssp"),
                                                                           p=comb.get("periodo"))
            leg_tit = (tx["classe"] if prod == "risco_classes" else
                       "dS/m" if prod == "ecw_critica" else tx["escala"])
            cmip = f"; CMIP6 {comb.get('modelo')} {comb.get('ssp')} {comb.get('periodo')}" if cen == "projecao" else ""
            if ind:
                w = p["pesos"][ind]
                rod = tx["fonte_indice"].format(ind=ind.upper(), i=w["I"], d=w["D"], c=w["C"], cmip=cmip)
            else:
                rod = tx["fonte"].format(issa=", ISSA" if tem_issa else "", cmip=cmip)
            if prod in ("issa", "ecw_critica") and "ecw_critica" in resultados[cen]["produtos"]:
                rod += (" ISSA = suscetibilidade climática à salinização (balanço de sais FAO-29)."
                        if idioma == "pt" else " ISSA = climatic salinization susceptibility (FAO-29 salt balance).")
            nome = f"{tif.stem}_{idioma}"
            lay = _layout(projeto, cam, contornos, nome, desc, sub, leg_tit, rod, tx["tec"].format(v=__version__), ext)
            projeto.layoutManager().addLayout(lay)
            exp = QgsLayoutExporter(lay)
            destino = saida / "mapas" / cen / idioma
            destino.mkdir(parents=True, exist_ok=True)
            base = destino / nome
            if "pdf" in p["formatos_mapa"]:
                cfg = QgsLayoutExporter.PdfExportSettings()
                cfg.dpi = p["dpi"]
                cfg.rasterizeWholeImage = False
                cfg.exportMetadata = False
                if exp.exportToPdf(str(base) + ".pdf", cfg) != QgsLayoutExporter.Success:
                    raise RuntimeError(f"Falha ao exportar {base}.pdf")
                arquivos.append(str(base) + ".pdf")
            if "png" in p["formatos_mapa"]:
                cfg = QgsLayoutExporter.ImageExportSettings()
                cfg.dpi = p["dpi"]
                cfg.exportMetadata = False
                gdal.PushErrorHandler("CPLQuietErrorHandler")
                try:
                    ok = exp.exportToImage(str(base) + ".png", cfg)
                finally:
                    gdal.PopErrorHandler()
                if ok != QgsLayoutExporter.Success:
                    raise RuntimeError(f"Falha ao exportar {base}.png")
                arquivos.append(str(base) + ".png")
            n += 1
    if not projeto.write():
        raise RuntimeError("Falha ao salvar o projeto QGIS do risco.")
    arquivo_proj = projeto.fileName()
    projeto.clear()  # libera os GeoPackages antes de calcular os hashes
    arquivos.append(arquivo_proj)
    arquivos.extend(str(f) for f in pasta_proj.glob("*.gpkg"))
    return {"gerados": True, "n_mapas": n, "arquivos": arquivos}
