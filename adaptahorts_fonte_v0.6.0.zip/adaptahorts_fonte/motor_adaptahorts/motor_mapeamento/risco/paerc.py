"""PAERC – Potencial de Adoção de Estratégias de Resiliência Climática, a partir de questionário estruturado.

O questionário e as faixas de pontuação seguem o documento "PAERC – índice de adaptação e
resiliência" (Pacheco Lima). Fluxo:
  1. cada propriedade responde ao questionário (valores brutos: R$, nº de espécies, km, sim/não...);
  2. por propriedade: faixas → indicadores [0, 1] → CE, CT, CI (médias simples) → PAERC;
  3. por microrregião: mediana (ou média) das respostas brutas → mesmas faixas → PAERC regional
     ("para agregação regional, aplique as mesmas faixas ao valor médio/mediana da microrregião"),
     com intervalo de confiança de 95% por bootstrap das propriedades.
PAERC = 0,40·CE + 0,35·CT + 0,25·CI.
"""

from __future__ import annotations

import csv
import math
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
from osgeo import ogr, osr

from .. import geo
from ..config import ErroValidacao

SIM = {"sim", "s", "1", "true", "verdadeiro", "yes", "y", "x"}
NAO = {"nao", "não", "n", "0", "false", "falso", "no", ""}

# ----------------------------------------------------------------------------- questionário

# tipo: numero | inteiro | sim_nao | opcao | texto
QUESTOES: list[dict] = [
    # Identificação
    {"campo": "id_questionario", "dim": "ID", "tipo": "texto", "obrigatorio": True,
     "pergunta": "Código do questionário"},
    {"campo": "data", "dim": "ID", "tipo": "texto", "obrigatorio": False, "pergunta": "Data da entrevista (AAAA-MM-DD)"},
    {"campo": "entrevistador", "dim": "ID", "tipo": "texto", "obrigatorio": False, "pergunta": "Entrevistador(a)"},
    {"campo": "microrregiao", "dim": "ID", "tipo": "texto", "obrigatorio": False,
     "pergunta": "Microrregião / região produtora (igual ao nome no mapa de microrregiões; "
                 "dispensável se houver coordenadas)"},
    {"campo": "lon", "dim": "ID", "tipo": "numero", "obrigatorio": False,
     "pergunta": "Longitude da propriedade (graus decimais, WGS 84)"},
    {"campo": "lat", "dim": "ID", "tipo": "numero", "obrigatorio": False,
     "pergunta": "Latitude da propriedade (graus decimais, WGS 84)"},
    # Dimensão econômica (CE)
    {"campo": "renda_mensal", "dim": "CE", "tipo": "numero", "obrigatorio": True, "unidade": "R$",
     "pergunta": "Renda líquida mensal da família com a atividade (R$)"},
    {"campo": "credito_pronaf", "dim": "CE", "tipo": "sim_nao", "obrigatorio": True,
     "pergunta": "Teve crédito rural (Pronaf) ativo no último ciclo?"},
    {"campo": "seguro_rural", "dim": "CE", "tipo": "sim_nao", "obrigatorio": True,
     "pergunta": "Possui seguro rural (Proagro ou apólice privada) ativo?"},
    # Dimensão técnica (CT)
    {"campo": "n_especies", "dim": "CT", "tipo": "inteiro", "obrigatorio": True,
     "pergunta": "Número de espécies/hortaliças comerciais cultivadas no ano"},
    {"campo": "shannon", "dim": "CT", "tipo": "numero", "obrigatorio": False,
     "pergunta": "Índice de Shannon H' das culturas (opcional; usado se a configuração pedir Shannon)"},
    {"campo": "tec_estufa", "dim": "CT", "tipo": "sim_nao", "obrigatorio": True, "grupo": "tecnologias",
     "pergunta": "Usa estufa / cultivo protegido?"},
    {"campo": "tec_mulching", "dim": "CT", "tipo": "sim_nao", "obrigatorio": True, "grupo": "tecnologias",
     "pergunta": "Usa mulching (cobertura plástica ou orgânica)?"},
    {"campo": "tec_irrigacao_eficiente", "dim": "CT", "tipo": "sim_nao", "obrigatorio": True, "grupo": "tecnologias",
     "pergunta": "Usa irrigação eficiente (gotejamento/microaspersão)?"},
    {"campo": "tec_fertilizacao_eficiente", "dim": "CT", "tipo": "sim_nao", "obrigatorio": True, "grupo": "tecnologias",
     "pergunta": "Usa fertilização eficiente (fertirrigação, análise de solo)?"},
    {"campo": "tec_sistemas_regenerativos", "dim": "CT", "tipo": "sim_nao", "obrigatorio": True,
     "grupo": "tecnologias", "pergunta": "Usa sistemas regenerativos (plantio direto, SAF, adubação verde)?"},
    {"campo": "tec_outras", "dim": "CT", "tipo": "inteiro", "obrigatorio": False, "grupo": "tecnologias",
     "pergunta": "Número de outras tecnologias resilientes adotadas"},
    {"campo": "ater_visitas_ano", "dim": "CT", "tipo": "inteiro", "obrigatorio": True,
     "pergunta": "Número de visitas/contatos de assistência técnica (ATER) por ano"},
    # Dimensão institucional (CI)
    {"campo": "caf", "dim": "CI", "tipo": "opcao", "obrigatorio": True,
     "opcoes": {"inexistente": 0.0, "pendente": 0.5, "valido": 1.0},
     "pergunta": "Situação do CAF (Cadastro Nacional da Agricultura Familiar): inexistente, pendente ou valido"},
    {"campo": "prog_abc", "dim": "CI", "tipo": "sim_nao", "obrigatorio": True, "grupo": "programas",
     "pergunta": "Participa do Plano ABC+?"},
    {"campo": "prog_ater_qualificada", "dim": "CI", "tipo": "sim_nao", "obrigatorio": True, "grupo": "programas",
     "pergunta": "Participa de programa de ATER qualificada?"},
    {"campo": "prog_agroecologia", "dim": "CI", "tipo": "sim_nao", "obrigatorio": True, "grupo": "programas",
     "pergunta": "Participa de programa de agroecologia / transição agroecológica?"},
    {"campo": "prog_irrigacao", "dim": "CI", "tipo": "sim_nao", "obrigatorio": True, "grupo": "programas",
     "pergunta": "Participa de programa público de irrigação?"},
    {"campo": "prog_outros", "dim": "CI", "tipo": "inteiro", "obrigatorio": False, "grupo": "programas",
     "pergunta": "Número de outros programas públicos (PAA, PNAE, cooperativas etc.)"},
    {"campo": "dist_ceasa_km", "dim": "CI", "tipo": "numero", "obrigatorio": True,
     "pergunta": "Distância até a CEASA ou polo consumidor (km)"},
    {"campo": "tempo_ceasa_min", "dim": "CI", "tipo": "numero", "obrigatorio": False,
     "pergunta": "Tempo até a CEASA pela rodovia principal (min; usado se a configuração pedir tempo)"},
    # Itens listados no documento ainda sem faixas: registrados, mas fora do índice.
    {"campo": "qualidade_ater", "dim": "PENDENTE", "tipo": "texto", "obrigatorio": False,
     "pergunta": "Qualidade da ATER (sem faixas definidas; não entra no PAERC)"},
    {"campo": "compras_publicas", "dim": "PENDENTE", "tipo": "texto", "obrigatorio": False,
     "pergunta": "Compras públicas (sem faixas definidas; não entra no PAERC)"},
    {"campo": "acesso_informacao_digital", "dim": "PENDENTE", "tipo": "texto", "obrigatorio": False,
     "pergunta": "Acesso à informação, tecnologias digitais e comunicação (sem faixas; não entra no PAERC)"},
    {"campo": "nivel_educacional", "dim": "PENDENTE", "tipo": "texto", "obrigatorio": False,
     "pergunta": "Nível educacional (sem faixas definidas; não entra no PAERC)"},
    {"campo": "implementos_agricolas", "dim": "PENDENTE", "tipo": "texto", "obrigatorio": False,
     "pergunta": "Implementos agrícolas – mecanização, automação, máquinas (sem faixas; não entra no PAERC)"},
    {"campo": "agregacao_valor", "dim": "PENDENTE", "tipo": "texto", "obrigatorio": False,
     "pergunta": "Agregação de valor (sem faixas definidas; não entra no PAERC)"},
]
CAMPOS = [q["campo"] for q in QUESTOES]
QUESTAO = {q["campo"]: q for q in QUESTOES}

# Faixas de pontuação: lista de (limite superior inclusivo, pontuação); a última vale para o restante.
FAIXAS = {
    "renda": [(2000, 0.00), (3000, 0.25), (4000, 0.50), (5000, 0.75), (math.inf, 1.00)],
    "credito_pct": [(0, 0.00), (25, 0.25), (50, 0.50), (75, 0.75), (math.inf, 1.00)],
    "especies": [(1, 0.00), (3, 0.25), (5, 0.50), (8, 0.75), (math.inf, 1.00)],
    "shannon": [(0.5, 0.00), (1.0, 0.25), (1.5, 0.50), (2.0, 0.75), (math.inf, 1.00)],
    "tecnologias": [(0, 0.00), (1, 0.33), (2, 0.66), (math.inf, 1.00)],
    "ater_visitas": [(0, 0.00), (1, 0.25), (2, 0.50), (4, 0.75), (math.inf, 1.00)],
    "programas": [(0, 0.00), (1, 0.33), (2, 0.66), (math.inf, 1.00)],
}
# Proximidade: quanto menor a distância/tempo, maior a pontuação (limite inferior exclusivo).
FAIXAS_PROXIMIDADE = {
    "distancia": [(60, 0.00), (40, 0.25), (20, 0.50), (10, 0.75), (-math.inf, 1.00)],   # > 60 → 0 ... ≤ 10 → 1
    "tempo": [(90, 0.00), (60, 0.25), (40, 0.50), (20, 0.75), (-math.inf, 1.00)],
}
DESCRICAO_FAIXAS = [
    ("Renda líquida mensal (R$)", "≤ 2.000 → 0,00 | 2.001–3.000 → 0,25 | 3.001–4.000 → 0,50 | 4.001–5.000 → 0,75 | ≥ 5.001 → 1,00"),
    ("Crédito Pronaf (% de produtores com crédito ativo)", "0% → 0,00 | 1–25% → 0,25 | 26–50% → 0,50 | 51–75% → 0,75 | 76–100% → 1,00; por propriedade: sim = 1, não = 0"),
    ("Seguro rural", "Não → 0,00 | Sim → 1,00; na microrregião: proporção de propriedades com seguro"),
    ("Diversificação (nº de espécies)", "1 → 0,00 | 2–3 → 0,25 | 4–5 → 0,50 | 6–8 → 0,75 | ≥ 9 → 1,00"),
    ("Diversificação (Shannon H')", "≤ 0,5 → 0,00 | 0,51–1,0 → 0,25 | 1,01–1,5 → 0,50 | 1,51–2,0 → 0,75 | ≥ 2,01 → 1,00"),
    ("Tecnologias resilientes (nº)", "0 → 0,00 | 1 → 0,33 | 2 → 0,66 | ≥ 3 → 1,00"),
    ("ATER (visitas/contatos por ano)", "0 → 0,00 | 1 → 0,25 | 2 → 0,50 | 3–4 → 0,75 | ≥ 5 → 1,00"),
    ("CAF", "Inexistente → 0,00 | Pendente/irregular → 0,50 | Válido/atualizado → 1,00"),
    ("Programas públicos (nº)", "0 → 0,00 | 1 → 0,33 | 2 → 0,66 | ≥ 3 → 1,00"),
    ("Distância à CEASA (km)", "> 60 → 0,00 | 40–60 → 0,25 | 20–40 → 0,50 | 10–20 → 0,75 | ≤ 10 → 1,00"),
    ("Tempo até a CEASA (min)", "> 90 → 0,00 | 60–90 → 0,25 | 40–60 → 0,50 | 20–40 → 0,75 | ≤ 20 → 1,00"),
]


def faixa(x: np.ndarray, tabela) -> np.ndarray:
    x = np.asarray(x, dtype="float64")
    out = np.full(x.shape, np.nan)
    resto = np.isfinite(x)
    for lim, pont in tabela:
        sel = resto & (x <= lim)
        out[sel] = pont
        resto &= ~sel
    return out


def faixa_proximidade(x: np.ndarray, tabela) -> np.ndarray:
    x = np.asarray(x, dtype="float64")
    out = np.full(x.shape, np.nan)
    resto = np.isfinite(x)
    for lim, pont in tabela:
        sel = resto & (x > lim)
        out[sel] = pont
        resto &= ~sel
    return out


# ----------------------------------------------------------------------------- leitura das respostas

def _num(v):
    s = str(v if v is not None else "").strip().replace(",", ".")
    if s == "":
        return None
    try:
        x = float(s)
    except ValueError:
        return "invalido"
    return x if math.isfinite(x) else "invalido"


def _sim_nao(v):
    s = str(v if v is not None else "").strip().lower()
    if s in SIM:
        return 1.0
    if s in NAO - {""}:
        return 0.0
    return None if s == "" else "invalido"


def _opcao(v, opcoes):
    import unicodedata
    s = unicodedata.normalize("NFKD", str(v or "")).encode("ascii", "ignore").decode().strip().lower()
    s = {"valido/atualizado": "valido", "valida": "valido", "ativo": "valido", "ativa": "valido",
         "pendente/irregular": "pendente", "irregular": "pendente", "inativo": "pendente",
         "nao": "inexistente", "não": "inexistente"}.get(s, s)
    if s == "":
        return None
    return opcoes.get(s, "invalido")


def ler_respostas(caminho: Path) -> list[dict]:
    """Lê questionários de .xlsx/.ods (aba 'respostas'), .csv ou camada .gpkg/.shp (pontos)."""
    suf = caminho.suffix.lower()
    linhas: list[dict] = []
    if suf in (".gpkg", ".shp", ".geojson"):
        ds = ogr.Open(str(caminho))
        if ds is None:
            raise ErroValidacao([f"Não foi possível abrir os questionários: {caminho.name}."])
        lyr = ds.GetLayerByName("questionario_paerc") or ds.GetLayer(0)
        srs = lyr.GetSpatialRef()
        trans = None
        if srs is not None:
            srs = srs.Clone()
            srs.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
            trans = osr.CoordinateTransformation(srs, geo.srs_wgs84())
        defn = lyr.GetLayerDefn()
        nomes = [defn.GetFieldDefn(i).GetName() for i in range(defn.GetFieldCount())]
        for f in lyr:
            d = {n.lower(): (f.GetFieldAsString(i) if f.IsFieldSetAndNotNull(i) else "") for i, n in enumerate(nomes)}
            g = f.GetGeometryRef()
            if g is not None and not g.IsEmpty():
                g = g.Clone()
                if trans is not None:
                    g.Transform(trans)
                d.setdefault("lon", "")
                d.setdefault("lat", "")
                if not d["lon"] and not d["lat"]:
                    d["lon"], d["lat"] = str(g.GetX()), str(g.GetY())
            linhas.append(d)
        ds = None
    elif suf in (".xlsx", ".ods"):
        linhas = [{k.lower(): v for k, v in l.items()} for l in geo.ler_tabela_ogr(caminho, "respostas")]
    elif suf in (".csv", ".txt"):
        texto = caminho.read_text(encoding="utf-8-sig")
        prim = texto.splitlines()[0] if texto.strip() else ""
        sep = ";" if prim.count(";") > prim.count(",") else ","
        linhas = [{(k or "").strip().lower(): (v or "") for k, v in l.items()}
                  for l in csv.DictReader(texto.splitlines(), delimiter=sep)]
    else:
        raise ErroValidacao([f"Questionários '{caminho.name}': use .xlsx, .ods, .csv ou .gpkg."])
    linhas = [l for l in linhas if any(str(v).strip() for v in l.values())]
    return [l for l in linhas if not str(l.get("id_questionario", "")).strip().upper().startswith("EXEMPLO")]


@dataclass
class Questionarios:
    respostas: list[dict]              # valores convertidos
    erros: list[str] = field(default_factory=list)
    avisos: list[str] = field(default_factory=list)


def validar_respostas(linhas: list[dict], params: dict) -> Questionarios:
    erros, avisos, out = [], [], []
    if not linhas:
        raise ErroValidacao(["Nenhum questionário preenchido."])
    faltam_col = [q["campo"] for q in QUESTOES if q["obrigatorio"] and q["campo"] not in linhas[0]]
    if faltam_col:
        raise ErroValidacao([f"Questionários sem as colunas: {', '.join(faltam_col)}. Use o modelo gerado pelo complemento."])
    ids = set()
    for i, l in enumerate(linhas, start=2):
        r = {"_linha": i}
        for q in QUESTOES:
            v = l.get(q["campo"], "")
            if q["tipo"] in ("numero", "inteiro"):
                x = _num(v)
                if x == "invalido" or (x is not None and (x < 0 and q["campo"] not in ("lon", "lat"))):
                    erros.append(f"Questionário linha {i}: '{q['campo']}' = '{v}' inválido.")
                    x = None
                if x is not None and q["tipo"] == "inteiro" and x != int(x):
                    erros.append(f"Questionário linha {i}: '{q['campo']}' deve ser número inteiro.")
            elif q["tipo"] == "sim_nao":
                x = _sim_nao(v)
                if x == "invalido":
                    erros.append(f"Questionário linha {i}: '{q['campo']}' deve ser sim ou não (recebido '{v}').")
                    x = None
            elif q["tipo"] == "opcao":
                x = _opcao(v, q["opcoes"])
                if x == "invalido":
                    erros.append(f"Questionário linha {i}: '{q['campo']}' deve ser um de {list(q['opcoes'])} (recebido '{v}').")
                    x = None
            else:
                x = str(v).strip()
            if q["obrigatorio"] and (x is None or x == ""):
                erros.append(f"Questionário linha {i}: resposta obrigatória ausente em '{q['campo']}'.")
            r[q["campo"]] = x
        if r["id_questionario"] in ids:
            erros.append(f"Questionário linha {i}: id_questionario '{r['id_questionario']}' repetido.")
        ids.add(r["id_questionario"])
        if params["paerc_diversificacao"] == "shannon" and r.get("shannon") is None:
            erros.append(f"Questionário linha {i}: a configuração usa Shannon, mas 'shannon' está vazio.")
        if params["paerc_proximidade"] == "tempo" and r.get("tempo_ceasa_min") is None:
            erros.append(f"Questionário linha {i}: a configuração usa tempo, mas 'tempo_ceasa_min' está vazio.")
        if not r.get("microrregiao") and (r.get("lon") is None or r.get("lat") is None):
            erros.append(f"Questionário linha {i}: informe a microrregião ou as coordenadas da propriedade.")
        out.append(r)
    pend = [q["campo"] for q in QUESTOES if q["dim"] == "PENDENTE" and any(r.get(q["campo"]) for r in out)]
    if pend:
        avisos.append("Itens respondidos mas sem faixas de pontuação definidas (não entram no PAERC): " + ", ".join(pend) + ".")
    return Questionarios(out, erros, avisos)


# ----------------------------------------------------------------------------- pontuação

def _brutos(rs: list[dict], params: dict) -> dict[str, np.ndarray]:
    """Valores brutos por indicador, um por propriedade."""
    g = lambda c: np.array([np.nan if r.get(c) is None else float(r[c]) for r in rs], dtype="float64")
    soma = lambda grupo: np.nansum(np.vstack([np.nan_to_num(g(q["campo"]), nan=0.0) for q in QUESTOES
                                              if q.get("grupo") == grupo]), axis=0)
    return {
        "renda": g("renda_mensal"), "credito": g("credito_pronaf"), "seguro": g("seguro_rural"),
        "diversificacao": g("shannon") if params["paerc_diversificacao"] == "shannon" else g("n_especies"),
        "tecnologias": soma("tecnologias"), "ater": g("ater_visitas_ano"),
        "caf": g("caf"), "programas": soma("programas"),
        "proximidade": g("tempo_ceasa_min") if params["paerc_proximidade"] == "tempo" else g("dist_ceasa_km"),
    }


def _pontuar(b: dict[str, np.ndarray], params: dict, regional: bool) -> dict[str, np.ndarray]:
    """Aplica as faixas. Em nível regional, crédito vira % de produtores (faixas do documento)
    e seguro/CAF entram como proporção/média das pontuações."""
    div = "shannon" if params["paerc_diversificacao"] == "shannon" else "especies"
    p = {
        "renda": faixa(b["renda"], FAIXAS["renda"]),
        "credito": faixa(b["credito"] * 100.0, FAIXAS["credito_pct"]) if regional else b["credito"],
        "seguro": b["seguro"],
        "diversificacao": faixa(b["diversificacao"], FAIXAS[div]),
        "tecnologias": faixa(b["tecnologias"], FAIXAS["tecnologias"]),
        "ater": faixa(b["ater"], FAIXAS["ater_visitas"]),
        "caf": b["caf"],
        "programas": faixa(b["programas"], FAIXAS["programas"]),
        "proximidade": faixa_proximidade(b["proximidade"], FAIXAS_PROXIMIDADE[params["paerc_proximidade"]]),
    }
    p["CE"] = (p["renda"] + p["credito"] + p["seguro"]) / 3.0
    p["CT"] = (p["diversificacao"] + p["tecnologias"] + p["ater"]) / 3.0
    p["CI"] = (p["caf"] + p["programas"] + p["proximidade"]) / 3.0
    w = params["pesos"]["paerc"]
    p["PAERC"] = w["CE"] * p["CE"] + w["CT"] * p["CT"] + w["CI"] * p["CI"]
    return p


def paerc_propriedades(rs: list[dict], params: dict) -> list[dict]:
    pts = _pontuar(_brutos(rs, params), params, regional=False)
    return [{"id_questionario": r["id_questionario"], "microrregiao": r.get("regiao_atribuida", r.get("microrregiao")),
             **{k: float(v[i]) for k, v in pts.items()}} for i, r in enumerate(rs)]


def _agregar(b: dict[str, np.ndarray], idx: np.ndarray, modo: str) -> dict[str, np.ndarray]:
    """Agrega por reamostra: idx (B, n) → valores (B,) por indicador.
    Proporções (crédito, seguro) e CAF usam média; demais seguem 'mediana' ou 'media'."""
    out = {}
    for k, v in b.items():
        amostras = v[idx]
        if k in ("credito", "seguro", "caf") or modo == "media":
            out[k] = np.nanmean(amostras, axis=1)
        else:
            out[k] = np.nanmedian(amostras, axis=1)
    return out


def paerc_regioes(rs: list[dict], params: dict) -> list[dict]:
    """PAERC por microrregião (campo 'regiao_atribuida'), com IC 95% por bootstrap das propriedades."""
    rng = np.random.default_rng(int(params["paerc_bootstrap_semente"]))
    nb = int(params["paerc_bootstrap_iteracoes"])
    regioes: dict[str, list[dict]] = {}
    for r in rs:
        regioes.setdefault(r["regiao_atribuida"], []).append(r)
    out = []
    for nome in sorted(regioes):
        grupo = regioes[nome]
        b = _brutos(grupo, params)
        n = len(grupo)
        pontual = _pontuar(_agregar(b, np.arange(n)[None, :], params["paerc_agregacao"]), params, regional=True)
        reg = {"microrregiao": nome, "n_questionarios": n, **{k: float(v[0]) for k, v in pontual.items()}}
        if n >= 2 and nb > 0:
            idx = rng.integers(0, n, size=(nb, n))
            boot = _pontuar(_agregar(b, idx, params["paerc_agregacao"]), params, regional=True)["PAERC"]
            reg["PAERC_ic95_inf"], reg["PAERC_ic95_sup"] = (float(x) for x in np.nanpercentile(boot, [2.5, 97.5]))
            reg["PAERC_bootstrap_media"] = float(np.nanmean(boot))
        else:
            reg["PAERC_ic95_inf"] = reg["PAERC_ic95_sup"] = reg["PAERC_bootstrap_media"] = None
        out.append(reg)
    return out


# ----------------------------------------------------------------------------- modelos de questionário

def criar_modelo_xlsx(destino: Path) -> Path:
    """Planilha do questionário: abas 'respostas' (preencher), 'perguntas', 'faixas' e 'instrucoes'."""
    destino = Path(destino)
    destino.parent.mkdir(parents=True, exist_ok=True)
    perguntas = [[q["campo"], q["dim"], q["pergunta"], q["tipo"],
                  "; ".join(q.get("opcoes", {})) if q["tipo"] == "opcao" else ("sim / não" if q["tipo"] == "sim_nao" else q.get("unidade", "")),
                  "sim" if q["obrigatorio"] else "não"] for q in QUESTOES]
    instr = [
        ["Preencha uma linha por propriedade na aba 'respostas'. Não altere os nomes das colunas."],
        ["A linha EXEMPLO-APAGUE é só ilustrativa: pode apagá-la ou deixá-la (linhas com código EXEMPLO são ignoradas)."],
        ["Respostas sim/não: escreva sim ou não. CAF: inexistente, pendente ou valido."],
        ["Informe a microrregião (igual ao nome no mapa de microrregiões) ou as coordenadas lon/lat da propriedade."],
        ["PAERC = 0,40·CE + 0,35·CT + 0,25·CI; CE, CT e CI são médias das pontuações dos indicadores (aba 'faixas')."],
        ["Na microrregião, aplica-se a faixa à mediana das respostas; crédito vira % de produtores com crédito."],
        ["Itens da dimensão PENDENTE são registrados, mas ainda não entram no índice (faixas não definidas)."],
        ["Os dados pessoais coletados devem seguir a LGPD; use códigos em vez de nomes sempre que possível."],
    ]
    exemplo = {"id_questionario": "EXEMPLO-APAGUE", "data": "2026-10-22", "microrregiao": "Nome da microrregião",
               "renda_mensal": 3500, "credito_pronaf": "sim", "seguro_rural": "não", "n_especies": 5,
               "tec_estufa": "não", "tec_mulching": "sim", "tec_irrigacao_eficiente": "sim",
               "tec_fertilizacao_eficiente": "não", "tec_sistemas_regenerativos": "não", "ater_visitas_ano": 2,
               "caf": "valido", "prog_abc": "não", "prog_ater_qualificada": "sim", "prog_agroecologia": "não",
               "prog_irrigacao": "não", "dist_ceasa_km": 35}
    geo.escrever_xlsx(destino, [
        # A linha de exemplo garante o cabeçalho na planilha; linhas com id "EXEMPLO..." são ignoradas.
        ("respostas", CAMPOS, [[exemplo.get(c, "") for c in CAMPOS]]),
        ("perguntas", ["campo", "dimensao", "pergunta", "tipo", "opcoes_ou_unidade", "obrigatorio"], perguntas),
        ("faixas", ["indicador", "faixas_e_pontuacao"], [list(x) for x in DESCRICAO_FAIXAS]),
        ("instrucoes", ["instrucao"], instr),
    ])
    return destino
