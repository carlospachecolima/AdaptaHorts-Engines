"""Cálculo pixel a pixel (numpy) de ET0/ETc, ISOC, ISDH, ISCC, ISSA, ameaça, PAERC e risco.

Entradas mensais: arrays (12, linhas, colunas) de Tmin, Tmax (°C) e precipitação (mm/mês).
Toda dimensão (I, D, C) fica em [0, 1] por limiares fixos, para que histórico e cenários
futuros sejam comparáveis entre si.
"""

from __future__ import annotations

import math
import warnings

import numpy as np

DIAS_MES = np.array([31, 28.25, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31], dtype="float64")
DIA_JULIANO_MEIO = np.array([15, 46, 74, 105, 135, 166, 196, 227, 258, 288, 319, 349], dtype="float64")
GSC = 0.0820  # constante solar, MJ m⁻² min⁻¹ (FAO-56)


def norm(x, a: float, b: float) -> np.ndarray:
    """Normalização linear com limiares fixos: 0 em a, 1 em b, limitada a [0, 1]."""
    return np.clip((np.asarray(x, dtype="float64") - a) / (b - a), 0.0, 1.0)


def ra_mj(lat_graus, dia_juliano) -> np.ndarray:
    """Radiação extraterrestre diária (MJ m⁻² dia⁻¹), FAO-56 eq. 21–25."""
    phi = np.deg2rad(lat_graus)
    j = np.asarray(dia_juliano, dtype="float64")
    dr = 1 + 0.033 * np.cos(2 * np.pi * j / 365)
    dec = 0.409 * np.sin(2 * np.pi * j / 365 - 1.39)
    ws = np.arccos(np.clip(-np.tan(phi) * np.tan(dec), -1.0, 1.0))
    return (24 * 60 / np.pi) * GSC * dr * (ws * np.sin(phi) * np.sin(dec) + np.cos(phi) * np.cos(dec) * np.sin(ws))


def et0_hargreaves(tmin, tmax, lat) -> np.ndarray:
    """ET0 mensal (mm/mês) por Hargreaves & Samani (1985). lat: (linhas, colunas) em graus."""
    ra = np.stack([ra_mj(lat, j) for j in DIA_JULIANO_MEIO]) * 0.408  # mm/dia
    tmed = (tmin + tmax) / 2.0
    amp = np.sqrt(np.clip(tmax - tmin, 0.0, None))
    return 0.0023 * ra * (tmed + 17.8) * amp * DIAS_MES[:, None, None]


def concentracao(x) -> np.ndarray:
    """Índice de concentração (forma do PCI de Oliver) de uma série mensal, normalizado:
    0 = distribuição uniforme nos 12 meses; 1 = tudo num único mês. Soma zero → 0."""
    x = np.clip(np.asarray(x, dtype="float64"), 0.0, None)
    s = x.sum(axis=0)
    with np.errstate(invalid="ignore", divide="ignore"):
        pci = 100.0 * (x ** 2).sum(axis=0) / s ** 2
    c = norm(pci, 100.0 / 12.0, 100.0)
    return np.where(s > 0, c, 0.0)


def _cdf_normal(z) -> np.ndarray:
    erf = np.vectorize(math.erf, otypes=[float])
    return 0.5 * (1.0 + erf(np.asarray(z) / math.sqrt(2.0)))


def isoc(tmax, p: dict) -> dict:
    """Ondas de calor. Com dados mensais, os dias com Tmax ≥ limiar são estimados supondo Tmax diária
    normal em torno da média mensal (desvio-padrão configurável)."""
    tc, ts, dp = p["isoc_tmax_critica"], p["isoc_tmax_severa"], p["isoc_dp_diario_tmax"]
    prob = 1.0 - _cdf_normal((tc - tmax) / dp)
    dias = prob * DIAS_MES[:, None, None]
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)  # pixels fora da área (todos NaN)
        tmax_max = np.nanmax(tmax, axis=0)
    comp = {"I": norm(tmax_max, tc, ts),
            "D": np.clip(dias.sum(axis=0) / 365.25, 0, 1),
            "C": concentracao(dias)}
    w = p["pesos"]["isoc"]
    return {"indice": w["I"] * comp["I"] + w["D"] * comp["D"] + w["C"] * comp["C"], **comp,
            "dias_quentes_ano": dias.sum(axis=0)}


def balanco(etc, prec) -> dict:
    deficit = np.clip(etc - prec, 0.0, None)
    with np.errstate(invalid="ignore", divide="ignore"):
        rel = np.where(etc > 0, deficit / etc, 0.0)
    return {"deficit_mensal": deficit, "deficit_relativo": rel}


def isdh(etc, prec, p: dict) -> dict:
    b = balanco(etc, prec)
    etc_a, def_a = etc.sum(axis=0), b["deficit_mensal"].sum(axis=0)
    with np.errstate(invalid="ignore", divide="ignore"):
        rel_anual = np.where(etc_a > 0, def_a / etc_a, 0.0)
    comp = {"I": norm(rel_anual, 0.0, p["isdh_intensidade_max"]),
            "D": (b["deficit_relativo"] >= p["isdh_deficit_relativo_dano"]).sum(axis=0) / 12.0,
            "C": concentracao(b["deficit_mensal"])}
    w = p["pesos"]["isdh"]
    return {"indice": w["I"] * comp["I"] + w["D"] * comp["D"] + w["C"] * comp["C"], **comp}


def erosividade(prec) -> np.ndarray:
    """R anual (MJ mm ha⁻¹ h⁻¹ ano⁻¹), Lombardi Neto & Moldenhauer (1992): EI = 67,355 (r²/P)^0,85."""
    pa = prec.sum(axis=0)
    with np.errstate(invalid="ignore", divide="ignore"):
        ei = 67.355 * np.where(pa > 0, (prec ** 2) / pa, 0.0) ** 0.85
    return ei.sum(axis=0)


def pci_oliver(prec) -> np.ndarray:
    s = prec.sum(axis=0)
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(s > 0, 100.0 * (prec ** 2).sum(axis=0) / s ** 2, np.nan)


def iscc(etc, prec, p: dict) -> dict:
    pci = pci_oliver(prec)
    r = erosividade(prec)
    pa = prec.sum(axis=0)
    comp = {"C": norm(pci, p["iscc_pci_min"], p["iscc_pci_max"]),
            "I": norm(r, p["iscc_r_min"], p["iscc_r_max"]),
            "D": ((prec - etc) >= p["iscc_excedente_encharcamento_mm"]).sum(axis=0) / 12.0}
    w = p["pesos"]["iscc"]
    with np.errstate(invalid="ignore", divide="ignore"):
        isc = np.where(pa > 0, pci * r / pa, np.nan)  # ISC = PCI · R/P (Modelo integrado, seção 2.3)
    return {"indice": w["I"] * comp["I"] + w["D"] * comp["D"] + w["C"] * comp["C"], **comp,
            "pci": pci, "erosividade_R": r, "isc": isc}


def issa(ce, etc, prec, p: dict) -> dict:
    """Salinização. I = CE (dS/m) entre o limiar e o máximo; D = meses sem lixiviação (P < ETc);
    C = concentração do déficit. Abaixo do limiar de CE não há estresse salino: ISSA = 0."""
    b = balanco(etc, prec)
    comp = {"I": norm(ce, p["issa_ce_limiar"], p["issa_ce_max"]),
            "D": (b["deficit_mensal"] > 0).sum(axis=0) / 12.0,
            "C": concentracao(b["deficit_mensal"])}
    w = p["pesos"]["issa"]
    bruto = w["I"] * comp["I"] + w["D"] * comp["D"] + w["C"] * comp["C"]
    return {"indice": np.where(ce > p["issa_ce_limiar"], bruto, np.where(np.isfinite(ce), 0.0, np.nan)), **comp}


def fator_concentracao_sais(etc, prec, eficiencia: float, lf_min: float) -> dict:
    """Quanto o clima concentra os sais da água de irrigação no solo (balanço de sais em equilíbrio,
    FAO-29 – Ayers & Westcot, 1985; Rhoades, 1974).

    Balanço hídrico anual (sem escoamento): a irrigação bruta repõe o déficit mensal (ETc − P);
    drenagem = irrigação bruta + chuva − ETc; fração de lixiviação LF = drenagem / água aplicada.
    A chuva não traz sais: a água que entra tem CE = ECw · Irrigação / (Irrigação + P).
    ECe = ECi · (1 + LF) / (5 · LF)  ⇒  fator FC = ECe / ECw = [Irr / (Irr + P)] · (1 + LF) / (5 · LF).
    FC não depende da qualidade da água: é uma propriedade do clima (e da eficiência de irrigação).
    Sem irrigação (chuva supre a ETc em todos os meses), FC = 0."""
    b = balanco(etc, prec)
    irrig = b["deficit_mensal"].sum(axis=0) / eficiencia
    pa, etca = prec.sum(axis=0), etc.sum(axis=0)
    entrada = irrig + pa
    with np.errstate(invalid="ignore", divide="ignore"):
        lf = np.clip(np.where(entrada > 0, (entrada - etca) / entrada, 1.0), lf_min, 1.0)
        fc = np.where(irrig > 0, (irrig / entrada) * (1 + lf) / (5 * lf), 0.0)
    return {"fc": fc, "lf": lf, "irrigacao_bruta": irrig}


def issa_suscetibilidade(etc, prec, p: dict) -> dict:
    """ISSA como suscetibilidade climática à salinização (não depende de dados de salinidade).
    I = fator de concentração de sais FC, de 0 (sem irrigação) ao máximo teórico com LF mínima e sem chuva;
    D = fração dos meses sem lixiviação (P < ETc); C = concentração do déficit no ano.
    Produtos auxiliares: ECe esperada com a água de referência e a CE máxima da água de irrigação
    que mantém o solo abaixo do limiar da alface (ECw crítica = limiar / FC)."""
    f = fator_concentracao_sais(etc, prec, p["eficiencia_irrigacao"], p["issa_lf_min"])
    lfm = p["issa_lf_min"]
    fc_max = (1 + lfm) / (5 * lfm)
    b = balanco(etc, prec)
    comp = {"I": norm(f["fc"], 0.0, fc_max),
            "D": (b["deficit_mensal"] > 0).sum(axis=0) / 12.0,
            "C": concentracao(b["deficit_mensal"])}
    w = p["pesos"]["issa"]
    with np.errstate(invalid="ignore", divide="ignore"):
        ecw_crit = np.where(f["fc"] > 0, p["issa_ce_limiar"] / f["fc"], np.nan)
    return {"indice": w["I"] * comp["I"] + w["D"] * comp["D"] + w["C"] * comp["C"], **comp,
            "fator_concentracao_sais": f["fc"], "fracao_lixiviacao": f["lf"],
            "ece_agua_referencia": p["issa_ce_agua"] * f["fc"], "ecw_critica": ecw_crit}


def ameaca(indices: dict, pesos: dict) -> tuple[np.ndarray, dict]:
    """Média ponderada dos índices disponíveis, renormalizando os pesos."""
    usados = {k: float(pesos[k]) for k in indices if k in pesos and float(pesos[k]) > 0}
    soma = sum(usados.values())
    if soma <= 0:
        raise ValueError("Pesos da ameaça somam zero.")
    h = sum(indices[k] * (w / soma) for k, w in usados.items())
    return h, {k: w / soma for k, w in usados.items()}


def classificar(r, limites: list[float]) -> np.ndarray:
    c = np.digitize(r, limites, right=False).astype("float64") + 1.0
    return np.where(np.isfinite(r), c, np.nan)
