"""Relatório do risco climático (Markdown)."""

from __future__ import annotations

from pathlib import Path

from .. import __version__
from .config_risco import FONTES, PARAMETROS_RISCO


def _f(x, d=3):
    if x is None:
        return "—"
    try:
        return f"{float(x):.{d}f}"
    except (TypeError, ValueError):
        return str(x)


def _tab(cab, linhas):
    return "\n".join(["| " + " | ".join(cab) + " |", "|" + "|".join("---" for _ in cab) + "|"] +
                     ["| " + " | ".join(str(c) for c in l) + " |" for l in linhas])


def _definicoes(p: dict, ce_medida: bool) -> dict:
    return {
        "isoc": f"- **ISOC:** I = Tmax média do mês mais quente entre {p['isoc_tmax_critica']} °C (0) e {p['isoc_tmax_severa']} °C (1); "
         f"D = fração do ano com Tmax ≥ {p['isoc_tmax_critica']} °C, estimada supondo Tmax diária normal em torno da "
         f"média mensal (DP = {p['isoc_dp_diario_tmax']} °C); C = concentração desses dias no ano.",
        "isdh": f"- **ISDH:** I = déficit anual / ETc anual; D = fração dos meses com déficit ≥ "
         f"{int(100 * p['isdh_deficit_relativo_dano'])}% da ETc; C = concentração do déficit. "
         f"ETc = ET0 (Hargreaves–Samani) × Kc {p['kc_alface']:.2f}.",
        "iscc": f"- **ISCC:** C = PCI de Oliver entre {p['iscc_pci_min']:.0f} e {p['iscc_pci_max']:.0f}; I = erosividade R "
         f"(Lombardi Neto & Moldenhauer) entre {p['iscc_r_min']:.0f} e {p['iscc_r_max']:.0f} MJ mm ha⁻¹ h⁻¹ ano⁻¹ "
         f"(classes de Carvalho); D = fração dos meses com excedente P − ETc ≥ "
         f"{p['iscc_excedente_encharcamento_mm']:.0f} mm. O ISC = PCI·R/P é gravado à parte.",
        "issa": (f"- **ISSA (estresse, CE do solo medida):** I = CE entre {p['issa_ce_limiar']} e {p['issa_ce_max']} dS/m; "
          "D = fração dos meses sem lixiviação (P < ETc); C = concentração do déficit; ISSA = 0 onde a CE não passa "
          "do limiar." if ce_medida else
          "- **ISSA (suscetibilidade climática à salinização):** balanço de sais em equilíbrio da FAO-29 "
          "(Ayers & Westcot, 1985): a irrigação repõe o déficit mensal, a drenagem é irrigação + chuva − ETc, a fração "
          "de lixiviação LF = drenagem / água aplicada e a chuva dilui a água de irrigação. O fator de concentração "
          "FC = ECe/ECw = [Irr/(Irr + P)]·(1 + LF)/(5·LF) depende só do clima. "
          f"I = FC entre 0 e o máximo teórico (LF = {p['issa_lf_min']}, sem chuva); D = fração dos meses sem "
          "lixiviação (P < ETc); C = concentração do déficit. Produtos auxiliares: ECe esperada com água de "
          f"referência de {p['issa_ce_agua']} dS/m (FAO-29, sem restrição de uso) e a CE máxima da água de irrigação "
          f"que mantém o solo abaixo de {p['issa_ce_limiar']} dS/m (= {p['issa_ce_limiar']}/FC). O ISSA indica onde o "
          "clima favorece o acúmulo de sais, não a salinidade atual do solo."),
    }


def escrever(saida: Path, t: dict, comb: dict, resumo: list[dict], pa: dict | None, pesos_ameaca: dict,
             desc_exp: str, avisos: list[str], mapas: dict, ce_medida: bool = False) -> Path:
    p = t["parametros"]
    if p.get("indice"):
        return _escrever_indice(saida, t, comb, resumo, avisos, mapas, ce_medida)
    w = p["pesos"]
    titulo = ("Índices de ameaça climática da alface (ISOC, ISDH, ISCC, ISSA)" if p.get("somente_ameaca")
              else "Risco climático da alface")
    L = [f"# {titulo} — AdaptaHorts v{__version__}", "",
         f"**Projeção:** {comb.get('modelo')} · {comb.get('ssp')} · {comb.get('periodo')} · "
         f"**Referência:** histórico corrigido 1970–2000", "",
         "## Equação", "",
         "**Risco = Ameaça × Exposição × (1 − PAERC)**, com todos os termos em [0, 1].", "",
         f"- Ameaça = média ponderada dos índices disponíveis: " +
         ", ".join(f"{k.upper()} {v:.3f}" for k, v in pesos_ameaca.items()) + ".",
         f"- Exposição: {desc_exp}.",
         "- Vulnerabilidade = 1 − PAERC; PAERC = "
         f"{w['paerc']['CE']:.3f}·CE + {w['paerc']['CT']:.3f}·CT + {w['paerc']['CI']:.3f}·CI (IPSV-AF, médias do "
         "bootstrap), a partir do questionário estruturado.",
         "", "## Índices de severidade (pesos = médias do bootstrap, IC 95%)", "",
         _tab(["Índice", "Intensidade (I)", "Duração (D)", "Concentração (C)"],
              [[k.upper(), f"{v['I']:.3f}", f"{v['D']:.3f}", f"{v['C']:.3f}"]
               for k, v in w.items() if k != "paerc"]), "",
         "Operacionalização com dados mensais (limiares fixos, iguais para histórico e projeção):", "",
         *_definicoes(p, ce_medida).values(),
         f"- Irrigação bruta = déficit × 10 / {p['eficiencia_irrigacao']:.2f} (m³/ha/ano).", "",
         "## Resumo por cenário (médias na área)", "",
         _tab(["Cenário", "ETc (mm)", "Chuva (mm)", "Déficit (mm)", "Irrigação (m³/ha)", "Var. irrig.", "ISOC",
               "ISDH", "ISCC", "ISSA", "Ameaça", "Exposição", "PAERC", "Risco potencial", "Risco"],
              [[r["cenario"], _f(r["etc_anual"], 1), _f(r["prec_anual"], 1), _f(r["deficit_anual"], 1),
                _f(r["irrigacao_bruta"], 0), (f"{r['variacao_irrigacao_pct']:+.1f}%" if r["variacao_irrigacao_pct"] is not None else "—"),
                _f(r["isoc"]), _f(r["isdh"]), _f(r["iscc"]), _f(r["issa"]), _f(r["ameaca"]), _f(r["exposicao"], 2),
                _f(r["paerc"]), _f(r["risco_potencial"]), _f(r["risco"])] for r in resumo]), ""]
    if not ce_medida:
        L += ["### Salinização (balanço de sais)", "",
              _tab(["Cenário", "Fator de concentração FC", "Fração de lixiviação", f"ECe c/ água de {p['issa_ce_agua']} dS/m",
                    "CE máxima da água de irrigação (dS/m)"],
                   [[r["cenario"], _f(r.get("fator_concentracao_sais"), 2), _f(r.get("fracao_lixiviacao"), 2),
                     _f(r.get("ece_agua_referencia"), 2), _f(r.get("ecw_critica"), 2)] for r in resumo]), ""]
    if any(k.startswith("area_pct_") for k in resumo[0]):
        nomes = p["classes_nomes_pt"]
        L += ["### Área por classe de risco (%)", "",
              _tab(["Cenário"] + nomes, [[r["cenario"]] + [_f(r.get(f"area_pct_{n}"), 1) for n in nomes] for r in resumo]),
              "", f"Limites das classes: {', '.join(_f(x, 2) for x in p['classes_limites'])} ({FONTES['classes_limites']}).", ""]
    if pa:
        L += ["## PAERC por microrregião (questionário estruturado)", "",
              f"{pa['n']} questionário(s). Agregação regional pela {p['paerc_agregacao']} das respostas e faixas do documento; "
              f"IC 95% por bootstrap ({p['paerc_bootstrap_iteracoes']} iterações, semente {p['paerc_bootstrap_semente']}).", "",
              _tab(["Microrregião", "N", "CE", "CT", "CI", "PAERC", "IC 95%"],
                   [[r["microrregiao"], r["n_questionarios"], _f(r["CE"]), _f(r["CT"]), _f(r["CI"]), _f(r["PAERC"]),
                     f"[{_f(r['PAERC_ic95_inf'])} – {_f(r['PAERC_ic95_sup'])}]" if r["PAERC_ic95_inf"] is not None else "—"]
                    for r in pa["regioes"]]), ""]
    L += ["## Parâmetros que ainda são propostas", "",
          "Estes valores não constam dos documentos de referência e devem ser revisados:", ""]
    L += [f"- `{k}`: {v}" for k, v in FONTES.items() if "PROPOSTA" in v] + [""]
    L += ["## Mapas", "", (f"{mapas.get('n_mapas', 0)} layouts gerados." if mapas.get("gerados") else
                           f"Não gerados: {mapas.get('motivo')}."), ""]
    L += ["## Avisos", ""] + ([f"- {a}" for a in avisos] if avisos else ["Nenhum aviso."]) + [""]
    f = saida / "relatorio_risco.md"
    f.write_text("\n".join(L), encoding="utf-8")
    return f


def _escrever_indice(saida: Path, t: dict, comb: dict, resumo: list[dict], avisos: list[str], mapas: dict,
                     ce_medida: bool) -> Path:
    p = t["parametros"]
    ind = p["indice"]
    w = p["pesos"][ind]
    nomes = {"isoc": "Ondas de Calor", "isdh": "Déficit Hídrico", "iscc": "Concentração de Chuvas",
             "issa": "Salinização" + ("" if ce_medida else " (suscetibilidade climática)")}
    L = [f"# {ind.upper()} – Índice de Severidade de {nomes[ind]} da alface — AdaptaHorts v{__version__}", "",
         f"**Projeção:** {comb.get('modelo')} · {comb.get('ssp')} · {comb.get('periodo')} · "
         f"**Referência:** histórico corrigido 1970–2000", "",
         "## Equação", "",
         f"**{ind.upper()} = {w['I']:.3f}·I + {w['D']:.3f}·D + {w['C']:.3f}·C**, com I, D e C em [0, 1].", "",
         "Pesos: médias da distribuição bootstrap (100.000 iterações, IC 95%) do modelo integrado de risco"
         + ("; a tabela-síntese do CNPq traz 0,452/0,346/0,202 para o ISDH." if ind == "isdh" else ".")
         + " Pesos diferentes dos padrões foram informados pelo usuário." * (w != PARAMETROS_RISCO["pesos"][ind]), "",
         "Operacionalização com dados mensais (limiares fixos, iguais para histórico e projeção):", "",
         _definicoes(p, ce_medida)[ind]]
    if ind != "isoc":
        L.append(f"- ETc = ET0 (Hargreaves–Samani) × Kc {p['kc_alface']:.2f}; irrigação bruta = déficit × 10 / "
                 f"{p['eficiencia_irrigacao']:.2f} (m³/ha/ano).")
    L += ["", "## Resumo por cenário (médias na área)", ""]
    cab = ["Cenário", "I", "D", "C", ind.upper()]
    extra = {"isoc": [("dias_tmax_acima_limiar", "Dias Tmax ≥ limiar", 1)],
             "isdh": [("etc_anual", "ETc (mm)", 1), ("prec_anual", "Chuva (mm)", 1), ("deficit_anual", "Déficit (mm)", 1),
                      ("irrigacao_bruta", "Irrigação (m³/ha)", 0)],
             "iscc": [("prec_anual", "Chuva (mm)", 1), ("pci", "PCI", 1), ("erosividade_R", "R", 0), ("isc", "ISC", 1)],
             "issa": [("fator_concentracao_sais", "FC", 2), ("fracao_lixiviacao", "LF", 2),
                      ("ece_agua_referencia", f"ECe c/ água {p['issa_ce_agua']} dS/m", 2),
                      ("ecw_critica", "CE máx. água (dS/m)", 2)]}[ind]
    cab += [e[1] for e in extra]
    linhas = [[r["cenario"], _f(r.get(f"{ind}_I")), _f(r.get(f"{ind}_D")), _f(r.get(f"{ind}_C")), _f(r.get(ind))] +
              [_f(r.get(k), d) for k, _, d in extra] for r in resumo]
    L += [_tab(cab, linhas), ""]
    if len(resumo) == 2 and resumo[0].get(ind) is not None and resumo[1].get(ind) is not None:
        L += [f"Variação do {ind.upper()} (projeção − histórico): {resumo[1][ind] - resumo[0][ind]:+.3f}.", ""]
    prop = [f"- `{k}`: {v}" for k, v in FONTES.items() if "PROPOSTA" in v and (k.startswith(ind) or k == "classes_limites")]
    prop = [x for x in prop if "classes_limites" not in x]
    if prop:
        L += ["## Parâmetros que ainda são propostas", ""] + prop + [""]
    L += ["## Mapas", "", (f"{mapas.get('n_mapas', 0)} layouts gerados." if mapas.get("gerados") else
                           f"Não gerados: {mapas.get('motivo')}."), ""]
    L += ["## Avisos", ""] + ([f"- {a}" for a in avisos] if avisos else ["Nenhum aviso."]) + [""]
    f = saida / f"relatorio_{ind}.md"
    f.write_text("\n".join(L), encoding="utf-8")
    return f
