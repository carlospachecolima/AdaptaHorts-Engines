"""Risco climático da alface: Risco = Ameaça × Exposição × (1 − PAERC).

Entrada principal: a pasta de resultados do motor de mapeamento (histórico 1970–2000 e projeção
corrigidos, 12 meses de Tmin, Tmax e precipitação). Os índices são calculados para os dois
períodos com os mesmos limiares, e a variação (projeção − histórico) é gravada à parte.
"""

from __future__ import annotations

import copy
import json
import re
import shutil
import unicodedata
import zipfile
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from .. import __version__, geo
from ..config import Cancelado, ErroValidacao, _mesclar
from ..entradas import sha256
from ..pipeline import _csv, _Progresso, _versoes
from . import indices as ix
from . import paerc as pq
from .config_risco import FONTES, PARAMETROS_RISCO

VARS = ("tmin", "tmax", "prec")
NODATA = -9999.0
ARQUIVOS_PREVIOS = {"trabalho_risco.json", "entradas"}

PRODUTOS = {  # nome do arquivo: (descrição pt, descrição en, unidade)
    "et0_anual": ("ET0 anual (Hargreaves–Samani)", "Annual ET0 (Hargreaves–Samani)", "mm/ano"),
    "etc_anual": ("ETc anual da alface", "Annual lettuce ETc", "mm/ano"),
    "prec_anual": ("Precipitação anual", "Annual precipitation", "mm/ano"),
    "deficit_anual": ("Déficit hídrico anual", "Annual water deficit", "mm/ano"),
    "irrigacao_bruta": ("Necessidade bruta de irrigação", "Gross irrigation requirement", "m³/ha/ano"),
    "isoc": ("Índice de Severidade de Ondas de Calor (ISOC)", "Heat Wave Severity Index (ISOC)", "0–1"),
    "isdh": ("Índice de Severidade de Déficit Hídrico (ISDH)", "Water Deficit Severity Index (ISDH)", "0–1"),
    "iscc": ("Índice de Severidade de Concentração de Chuvas (ISCC)", "Rainfall Concentration Severity Index (ISCC)", "0–1"),
    "issa": ("Índice de Severidade de Salinização (ISSA)", "Salinization Severity Index (ISSA)", "0–1"),
    "fator_concentracao_sais": ("Fator de concentração de sais (ECe/ECw)", "Salt concentration factor (ECe/ECw)", "–"),
    "fracao_lixiviacao": ("Fração de lixiviação", "Leaching fraction", "–"),
    "ece_agua_referencia": ("CE do solo esperada com água de referência", "Expected soil EC with reference water", "dS/m"),
    "ecw_critica": ("CE máxima da água de irrigação para a alface", "Maximum irrigation water EC for lettuce", "dS/m"),
    "ameaca": ("Ameaça climática agregada", "Aggregated climate hazard", "0–1"),
    "exposicao": ("Exposição", "Exposure", "0–1"),
    "paerc": ("PAERC (capacidade adaptativa)", "PAERC (adaptive capacity)", "0–1"),
    "vulnerabilidade": ("Vulnerabilidade (1 − PAERC)", "Vulnerability (1 − PAERC)", "0–1"),
    "risco_potencial": ("Risco potencial (Ameaça × Exposição)", "Potential risk (Hazard × Exposure)", "0–1"),
    "risco": ("Risco climático", "Climate risk", "0–1"),
    "risco_classes": ("Classes de risco climático", "Climate risk classes", "classe"),
}
INDICES = ("isoc", "isdh", "iscc", "issa")
_COMP = {"I": ("Intensidade", "Intensity"), "D": ("Duração", "Duration"), "C": ("Concentração sazonal", "Seasonal concentration")}
for _k in INDICES:
    for _c, (_pt, _en) in _COMP.items():
        PRODUTOS[f"{_k}_{_c}"] = (f"{_k.upper()} – componente {_pt} ({_c})", f"{_k.upper()} – {_en} component ({_c})", "0–1")
PRODUTOS["dias_tmax_acima_limiar"] = ("Dias com Tmax acima do limiar da alface", "Days with Tmax above the lettuce threshold", "dias/ano")
PRODUTOS["pci"] = ("Índice de concentração da precipitação (PCI)", "Precipitation Concentration Index (PCI)", "%")
PRODUTOS["erosividade_R"] = ("Erosividade da chuva (R)", "Rainfall erosivity (R)", "MJ mm/ha/h/ano")
PRODUTOS["isc"] = ("Índice de severidade concentrada (ISC = PCI·R/P)", "Concentrated severity index (ISC)", "–")
# Produtos gravados no modo de índice único, além de ET0/ETc/chuva/déficit/irrigação.
AUXILIARES = {"isoc": ["dias_tmax_acima_limiar"], "isdh": [], "iscc": ["pci", "erosividade_R", "isc"],
              "issa": ["fator_concentracao_sais", "fracao_lixiviacao", "ece_agua_referencia", "ecw_critica"]}


def _sem_acento(s: str) -> str:
    s = unicodedata.normalize("NFKD", str(s)).encode("ascii", "ignore").decode()
    return re.sub(r"\s+", " ", s.strip().lower())


def carregar(caminho: Path, indice: str | None = None) -> dict:
    caminho = Path(caminho).resolve()
    d = json.loads(caminho.read_text(encoding="utf-8"))
    base = caminho.parent
    res = lambda p: None if not p else (Path(p) if Path(p).is_absolute() else (base / p).resolve())
    for k in ("mapeamento", "saida"):
        if not d.get(k):
            raise ErroValidacao([f"Trabalho de risco sem o campo obrigatório '{k}'."])
    t = {"arquivo": caminho, "bruto": d, "mapeamento": res(d["mapeamento"]), "saida": res(d["saida"]),
         "area": res(d.get("area")), "ce_salinidade": res(d.get("ce_salinidade")),
         "exposicao": dict(d.get("exposicao") or {"tipo": "constante"}),
         "paerc": dict(d["paerc"]) if d.get("paerc") else None,
         "parametros": _mesclar(PARAMETROS_RISCO, d.get("parametros", {}))}
    if indice:
        t["parametros"]["indice"] = indice
    ind = t["parametros"].get("indice")
    if ind is not None:
        ind = str(ind).lower()
        if ind not in INDICES:
            raise ErroValidacao([f"Parâmetro 'indice' inválido ('{ind}'); use isoc, isdh, iscc ou issa."])
        t["parametros"]["indice"] = ind
        t["parametros"]["somente_ameaca"] = True  # sem exposição nem PAERC
        t["paerc"] = None
    if t["exposicao"].get("arquivo"):
        t["exposicao"]["arquivo"] = res(t["exposicao"]["arquivo"])
    if t["paerc"]:
        for k in ("questionarios", "microrregioes"):
            if t["paerc"].get(k):
                t["paerc"][k] = res(t["paerc"][k])
    return t


def _ler_mapeamento(pasta: Path, erros: list[str]) -> dict:
    man_p = pasta / "manifesto.json"
    if not man_p.exists():
        erros.append(f"'{pasta}' não parece uma pasta de resultados do motor de mapeamento (falta manifesto.json).")
        return {}
    man = json.loads(man_p.read_text(encoding="utf-8"))
    arquivos = {}
    for cen, sub in (("historico", "historico_corrigido"), ("projecao", "projecao_corrigida")):
        for var in VARS:
            for m in range(1, 13):
                achados = sorted((pasta / "rasters" / sub / var).glob(f"*_{var}_{m:02d}*.tif"))
                if len(achados) != 1:
                    erros.append(f"Mapeamento: esperado 1 raster de {var}, mês {m} em {sub}; encontrados {len(achados)}.")
                    continue
                arquivos[(cen, var, m)] = achados[0]
    return {"manifesto": man, "manifesto_sha256": sha256(man_p), "arquivos": arquivos}


def _area(t: dict, pasta_map: Path) -> tuple[geo.Area | None, Path | None]:
    candidatos = [t["area"]] if t["area"] else [pasta_map / "entradas" / "area_estudo.gpkg",
                                               pasta_map / "projeto_qgis" / "area_estudo.gpkg"]
    for c in candidatos:
        if c and Path(c).exists():
            area, erros = geo.ler_vetor_area(Path(c))
            if erros:
                raise ErroValidacao(erros)
            return area, Path(c)
    if t["area"]:
        raise ErroValidacao([f"Área de estudo não encontrada: {t['area']}"])
    return None, None


def preparar(t: dict) -> dict:
    erros: list[str] = []
    avisos: list[str] = []
    p = t["parametros"]
    mp = _ler_mapeamento(t["mapeamento"], erros) if t["mapeamento"] and t["mapeamento"].exists() else {}
    if not mp and not erros:
        erros.append(f"Pasta de resultados do mapeamento não encontrada: {t['mapeamento']}")
    exp = t["exposicao"]
    if exp.get("tipo", "constante") == "constante":
        a = float(exp.get("adocao_conservacionista", p["adocao_conservacionista"]))
        if not 0 <= a <= 1:
            erros.append("Adoção de sistemas conservacionistas deve estar entre 0 e 1.")
    elif exp["tipo"] in ("raster", "poligonos"):
        if not exp.get("arquivo") or not Path(exp["arquivo"]).exists():
            erros.append(f"Exposição: arquivo não encontrado ({exp.get('arquivo')}).")
        if exp["tipo"] == "poligonos" and not exp.get("campo"):
            erros.append("Exposição por polígonos: informe o campo com o valor de exposição (0–1).")
    else:
        erros.append(f"Exposição: tipo '{exp.get('tipo')}' inválido (constante, raster ou poligonos).")
    if t["ce_salinidade"] and not t["ce_salinidade"].exists():
        erros.append(f"Raster de CE não encontrado: {t['ce_salinidade']}")
    pa = t["paerc"]
    if pa:
        for k in ("questionarios", "microrregioes"):
            if not pa.get(k) or not Path(pa[k]).exists():
                erros.append(f"PAERC: arquivo de {k} não encontrado ({pa.get(k)}).")
        if not pa.get("campo_nome"):
            erros.append("PAERC: informe o campo com o nome da microrregião na camada de microrregiões.")
    soma = sum(float(v) for v in p["pesos_ameaca"].values())
    if soma <= 0:
        erros.append("Pesos da ameaça somam zero.")
    for k, w in p["pesos"].items():
        s = sum(w.values())
        if abs(s - 1) > 1e-6:
            erros.append(f"Pesos de {k.upper()} somam {s:.3f}; devem somar 1.")
    lim = p["classes_limites"]
    if sorted(lim) != list(lim) or len(lim) != len(p["classes_nomes_pt"]) - 1:
        erros.append("Classes de risco: limites devem ser crescentes e um a menos que o número de nomes.")
    if erros:
        raise ErroValidacao(erros)
    area, area_arq = _area(t, t["mapeamento"])
    if area is None:
        avisos.append("Área de estudo não encontrada; os mapas sairão sem o contorno da área.")
    return {"mapeamento": mp, "area": area, "area_arquivo": area_arq, "avisos": avisos}


def _questionarios(t: dict, p: dict, avisos: list[str]) -> dict:
    pa = t["paerc"]
    rs = pq.validar_respostas(pq.ler_respostas(Path(pa["questionarios"])), p)
    if rs.erros:
        raise ErroValidacao(rs.erros[:60] + ([f"... e mais {len(rs.erros) - 60} erros."] if len(rs.erros) > 60 else []))
    avisos.extend(rs.avisos)
    feicoes = geo.ler_feicoes(Path(pa["microrregioes"]))
    campo = pa["campo_nome"]
    if feicoes and campo not in feicoes[0][1]:
        raise ErroValidacao([f"Camada de microrregiões sem o campo '{campo}'. Campos: {', '.join(feicoes[0][1])}."])
    nomes = [a[campo] for _, a in feicoes]
    por_nome = {_sem_acento(n): n for n in nomes}
    erros = []
    for r in rs.respostas:
        reg = None
        if r.get("lon") is not None and r.get("lat") is not None:
            i = geo.ponto_em(feicoes, r["lon"], r["lat"])
            if i is not None:
                reg = nomes[i]
                if r.get("microrregiao") and _sem_acento(r["microrregiao"]) != _sem_acento(reg):
                    avisos.append(f"Questionário {r['id_questionario']}: informado '{r['microrregiao']}', mas as "
                                  f"coordenadas caem em '{reg}'; usada a localização.")
        if reg is None and r.get("microrregiao"):
            reg = por_nome.get(_sem_acento(r["microrregiao"]))
        if reg is None:
            erros.append(f"Questionário {r['id_questionario']} (linha {r['_linha']}): não foi possível associá-lo a "
                         f"uma microrregião da camada (nome '{r.get('microrregiao') or '—'}', coordenadas "
                         f"{r.get('lon')}, {r.get('lat')}).")
        r["regiao_atribuida"] = reg
    if erros:
        raise ErroValidacao(erros)
    props = pq.paerc_propriedades(rs.respostas, p)
    regs = pq.paerc_regioes(rs.respostas, p)
    com = {r["microrregiao"] for r in regs}
    for n in nomes:
        if n not in com:
            avisos.append(f"Microrregião '{n}' sem questionários: PAERC e risco ficam sem valor nela.")
    for r in regs:
        if r["n_questionarios"] < int(p["paerc_min_questionarios"]):
            avisos.append(f"Microrregião '{r['microrregiao']}': só {r['n_questionarios']} questionário(s) "
                          f"(mínimo recomendado {p['paerc_min_questionarios']}); PAERC pouco robusto.")
    valor = {r["microrregiao"]: r["PAERC"] for r in regs}
    return {"propriedades": props, "regioes": regs, "feicoes": feicoes, "campo": campo,
            "valor_por_regiao": valor, "n": len(rs.respostas)}


def _calcular_cenario(dados: dict, lat: np.ndarray, p: dict, ce, extra: dict) -> dict:
    tmin, tmax, prec = dados["tmin"], dados["tmax"], dados["prec"]
    et0 = ix.et0_hargreaves(tmin, tmax, lat)
    etc = et0 * p["kc_alface"]
    bal = ix.balanco(etc, prec)
    out = {"et0_anual": et0.sum(0), "etc_anual": etc.sum(0), "prec_anual": prec.sum(0),
           "deficit_anual": bal["deficit_mensal"].sum(0)}
    out["irrigacao_bruta"] = out["deficit_anual"] * 10.0 / p["eficiencia_irrigacao"]
    so = p.get("indice")
    comp = {}
    if so in (None, "isoc"):
        r = ix.isoc(tmax, p)
        out["isoc"], comp["isoc"] = r["indice"], r
        out["dias_tmax_acima_limiar"] = r["dias_quentes_ano"]
    if so in (None, "isdh"):
        r = ix.isdh(etc, prec, p)
        out["isdh"], comp["isdh"] = r["indice"], r
    if so in (None, "iscc"):
        r = ix.iscc(etc, prec, p)
        out["iscc"], comp["iscc"] = r["indice"], r
        out["pci"], out["erosividade_R"], out["isc"] = r["pci"], r["erosividade_R"], r["isc"]
    if so in (None, "issa"):
        if ce is not None:  # CE do solo medida: estresse salino contra os limiares da alface
            r = ix.issa(ce, etc, prec, p)
        else:               # só clima: suscetibilidade à salinização (balanço de sais FAO-29)
            r = ix.issa_suscetibilidade(etc, prec, p)
            for k in ("fator_concentracao_sais", "fracao_lixiviacao", "ece_agua_referencia", "ecw_critica"):
                out[k] = r[k]
        out["issa"], comp["issa"] = r["indice"], r
    pesos_usados = None
    if so is None:
        indices = {k: out[k] for k in INDICES}
        out["ameaca"], pesos_usados = ix.ameaca(indices, p["pesos_ameaca"])
        out["exposicao"] = extra["exposicao"]
        out["risco_potencial"] = out["ameaca"] * out["exposicao"]
    if so is None and extra.get("paerc") is not None:
        out["paerc"] = extra["paerc"]
        out["vulnerabilidade"] = 1.0 - out["paerc"]
        out["risco"] = out["ameaca"] * out["exposicao"] * out["vulnerabilidade"]
        out["risco_classes"] = ix.classificar(out["risco"], p["classes_limites"])
    if so == "isoc":  # o ISOC não usa o balanço hídrico
        for k in ("et0_anual", "etc_anual", "prec_anual", "deficit_anual", "irrigacao_bruta"):
            out.pop(k)
    for k in list(out):
        out[k] = np.where(dados["valido"], out[k], np.nan)
    for nome, c in comp.items():
        for d in ("I", "D", "C"):
            out[f"{nome}_{d}"] = np.where(dados["valido"], c[d], np.nan)
    return {"produtos": out, "pesos_ameaca_usados": pesos_usados}


def executar(caminho: str | Path, progresso=None, cancelado=None, indice: str | None = None) -> dict:
    """Executa o módulo de risco. Com `indice` ("isoc", "isdh", "iscc" ou "issa"), calcula só esse índice."""
    prog = _Progresso(progresso, cancelado)
    t = carregar(Path(caminho), indice)
    p = t["parametros"]
    saida = t["saida"]
    if saida.exists() and any(f.name not in ARQUIVOS_PREVIOS for f in saida.iterdir()):
        raise ErroValidacao([f"O diretório de saída '{saida}' já contém resultados; use um diretório vazio."])
    saida.mkdir(parents=True, exist_ok=True)
    previos = {f.name for f in saida.iterdir()}
    inicio = datetime.now(timezone.utc)
    try:
        r = _executar(t, saida, prog)
    except BaseException:
        for f in saida.iterdir():
            if f.name not in previos:
                shutil.rmtree(f) if f.is_dir() else f.unlink()
        raise
    r["manifesto"]["execucao"] = {"inicio_utc": inicio.isoformat(), "fim_utc": datetime.now(timezone.utc).isoformat()}
    (saida / "manifesto_risco.json").write_text(json.dumps(r["manifesto"], ensure_ascii=False, indent=2, default=str),
                                                encoding="utf-8")
    if p["gerar_zip"]:
        z = saida.parent / f"{saida.name}.zip"
        with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
            for f in sorted(saida.rglob("*")):
                if f.is_file():
                    zf.write(f, f.relative_to(saida.parent))
        (saida.parent / f"{z.name}.sha256").write_text(f"{sha256(z)}  {z.name}\n")
        r["zip"] = str(z)
    return r


def _media(a: np.ndarray) -> float | None:
    v = a[np.isfinite(a)]
    return float(v.mean()) if v.size else None


def _executar(t: dict, saida: Path, prog) -> dict:
    p = t["parametros"]
    prog(1, "Validando entradas do risco")
    prep = preparar(t)
    avisos = list(prep["avisos"])
    mp = prep["mapeamento"]
    comb = mp["manifesto"].get("combinacao", {})

    prog(5, "Lendo os rasters corrigidos")
    primeiro = next(iter(mp["arquivos"].values()))
    info = geo.inspecionar(primeiro)
    gt, W, H = info.gt, info.largura, info.altura
    dados = {}
    for cen in ("historico", "projecao"):
        d = {}
        for var in VARS:
            camadas = []
            for m in range(1, 13):
                i2 = geo.inspecionar(mp["arquivos"][(cen, var, m)])
                if (i2.largura, i2.altura) != (W, H) or i2.gt != gt:
                    raise ErroValidacao([f"Raster {mp['arquivos'][(cen, var, m)].name} fora da grade dos demais."])
                camadas.append(geo.ler_banda(mp["arquivos"][(cen, var, m)], 1)[0])
            d[var] = np.stack(camadas)
        d["valido"] = np.all(np.isfinite(np.concatenate([d[v] for v in VARS])), axis=0)
        dados[cen] = d
    lat = np.broadcast_to((gt.y0 + (np.arange(H) + 0.5) * gt.dy)[:, None], (H, W))
    valido = dados["historico"]["valido"] & dados["projecao"]["valido"]
    if not valido.any():
        raise ErroValidacao(["Nenhum pixel com os 36 meses válidos nos dois períodos."])

    prog(15, "Exposição, salinidade e PAERC")
    exp = t["exposicao"]
    if exp.get("tipo", "constante") == "constante":
        adocao = float(exp.get("adocao_conservacionista", p["adocao_conservacionista"]))
        exposicao = np.full((H, W), 1.0 - adocao)
        desc_exp = f"constante = 1 − adoção de sistemas conservacionistas ({adocao:.2f}) = {1 - adocao:.2f}"
    elif exp["tipo"] == "raster":
        exposicao = geo.reamostrar_para_grade(Path(exp["arquivo"]), gt, W, H, "bilinear")
        desc_exp = f"raster {Path(exp['arquivo']).name} reamostrado (bilinear) para a grade de 30\""
    else:
        fe = []
        for g, a in geo.ler_feicoes(Path(exp["arquivo"])):
            v = pq._num(a.get(exp["campo"]))
            if not isinstance(v, float):
                raise ErroValidacao([f"Exposição: valor inválido no campo '{exp['campo']}' ({a.get(exp['campo'])})."])
            fe.append((g, v))
        exposicao = geo.rasterizar_valores(fe, gt, W, H)
        desc_exp = f"polígonos {Path(exp['arquivo']).name}, campo '{exp['campo']}'"
    fora = np.isfinite(exposicao) & ((exposicao < 0) | (exposicao > 1))
    if fora.any():
        raise ErroValidacao([f"Exposição com {int(fora.sum())} pixel(is) fora de [0, 1]."])
    if np.any(valido & ~np.isfinite(exposicao)):
        avisos.append("Parte da área não tem valor de exposição; o risco fica sem valor nesses pixels.")

    ce = None
    if t["ce_salinidade"]:
        ce = geo.reamostrar_para_grade(t["ce_salinidade"], gt, W, H, "bilinear")
        if np.any(valido & ~np.isfinite(ce)):
            avisos.append("O raster de CE não cobre toda a área; o ISSA fica sem valor onde falta CE.")
    elif p.get("indice") in (None, "issa"):
        avisos.append("ISSA calculado como suscetibilidade climática à salinização (balanço de sais FAO-29), sem "
                      "dados de salinidade; ele indica onde o clima favorece o acúmulo de sais, não a salinidade "
                      "atual do solo." + ("" if p.get("indice") else " Seus componentes D e C usam o mesmo déficit do "
                      "ISDH, o que dá peso extra à seca na ameaça."))

    paerc_r = None
    pa_info = None
    if t["paerc"]:
        pa_info = _questionarios(t, p, avisos)
        fe = [(g, pa_info["valor_por_regiao"][a[pa_info["campo"]]]) for g, a in pa_info["feicoes"]
              if a[pa_info["campo"]] in pa_info["valor_por_regiao"]]
        paerc_r = geo.rasterizar_valores(fe, gt, W, H)
        if np.any(valido & ~np.isfinite(paerc_r)):
            avisos.append("Parte da área está fora das microrregiões com PAERC; nela só há risco potencial "
                          "(ameaça × exposição).")
    elif not p["somente_ameaca"]:
        avisos.append("Sem questionários do PAERC: calculado apenas o risco potencial (ameaça × exposição); "
                      "o risco climático completo exige o PAERC.")

    resultados = {}
    for i, cen in enumerate(("historico", "projecao")):
        prog(25 + 20 * i, f"Calculando índices – {cen}")
        dados[cen]["valido"] = valido
        resultados[cen] = _calcular_cenario(dados[cen], lat, p, ce, {"exposicao": exposicao, "paerc": paerc_r})
    pesos_usados = resultados["historico"]["pesos_ameaca_usados"]

    prog(65, "Gravando rasters e tabelas")
    arquivos = []
    tags_base = {"motor": f"motor_mapeamento.risco {__version__}", "modelo": comb.get("modelo"),
                 "ssp": comb.get("ssp"), "periodo_projecao": comb.get("periodo")}
    if p.get("indice"):
        tags_base["indice"] = p["indice"].upper()
        tags_base["pesos_IDC"] = json.dumps(p["pesos"][p["indice"]])
    rotulo = {"historico": "Historico_1970-2000",
              "projecao": f"{comb.get('periodo')}_{comb.get('ssp')}_{comb.get('modelo')}"}
    for cen, r in resultados.items():
        for nome, arr in r["produtos"].items():
            f = saida / "rasters" / cen / f"{rotulo[cen]}_{nome}.tif"
            geo.gravar_geotiff(f, arr, gt, 4326, NODATA, {**tags_base, "produto": nome, "cenario": cen}, nome)
            arquivos.append(f)
    for nome in ("isoc", "isdh", "iscc", "issa", "isoc_I", "isoc_D", "isoc_C", "isdh_I", "isdh_D", "isdh_C",
                 "iscc_I", "iscc_D", "iscc_C", "issa_I", "issa_D", "issa_C", "ecw_critica", "ameaca", "risco_potencial", "risco", "irrigacao_bruta",
                 "deficit_anual", "etc_anual"):
        a, b = resultados["historico"]["produtos"].get(nome), resultados["projecao"]["produtos"].get(nome)
        if a is not None and b is not None:
            f = saida / "rasters" / "variacao" / f"variacao_{nome}.tif"
            geo.gravar_geotiff(f, b - a, gt, 4326, NODATA, {**tags_base, "produto": f"variacao_{nome}"},
                               f"projeção − histórico: {nome}")
            arquivos.append(f)

    # Tabela-resumo por cenário (médias na área), no formato da Tabela 2 do modelo integrado.
    resumo = []
    for cen, r in resultados.items():
        pr = r["produtos"]
        linha = {"cenario": "Histórico 1970–2000" if cen == "historico" else
                 f"{comb.get('ssp')} {comb.get('periodo')} ({comb.get('modelo')})"}
        for k in ("et0_anual", "etc_anual", "prec_anual", "deficit_anual", "irrigacao_bruta", "dias_tmax_acima_limiar",
                  "pci", "erosividade_R", "isc", "fator_concentracao_sais", "fracao_lixiviacao", "ece_agua_referencia",
                  "ecw_critica", "isoc", "isdh", "iscc", "issa", "ameaca", "exposicao", "paerc",
                  "vulnerabilidade", "risco_potencial", "risco"):
            linha[k] = _media(pr[k]) if k in pr else None
        for k in INDICES:
            for c in "IDC":
                if f"{k}_{c}" in pr:
                    linha[f"{k}_{c}"] = _media(pr[f"{k}_{c}"])
        if "risco_classes" in pr:
            cl = pr["risco_classes"][np.isfinite(pr["risco_classes"])]
            for j, nomecl in enumerate(p["classes_nomes_pt"], start=1):
                linha[f"area_pct_{nomecl}"] = float(100 * (cl == j).mean()) if cl.size else None
        resumo.append(linha)
    base_irr = resumo[0]["irrigacao_bruta"]
    for l in resumo:
        l["variacao_irrigacao_pct"] = (100 * (l["irrigacao_bruta"] / base_irr - 1)) if base_irr else None

    tab = saida / "tabelas"
    tab.mkdir(parents=True, exist_ok=True)
    tabelas = {"resumo_cenarios.csv": resumo}
    if pa_info:
        tabelas["paerc_propriedades.csv"] = pa_info["propriedades"]
        tabelas["paerc_microrregioes.csv"] = pa_info["regioes"]
        # risco por microrregião (média dos pixels de cada polígono)
        idx = geo.rasterizar_valores([(g, i) for i, (g, _) in enumerate(pa_info["feicoes"])], gt, W, H)
        linhas = []
        for i, (_, a) in enumerate(pa_info["feicoes"]):
            sel = (idx == i) & valido
            nome = a[pa_info["campo"]]
            reg = next((x for x in pa_info["regioes"] if x["microrregiao"] == nome), {})
            for cen, r in resultados.items():
                pr = r["produtos"]
                risco = _media(np.where(sel, pr["risco"], np.nan))
                classe = None
                if risco is not None:
                    classe = p["classes_nomes_pt"][int(ix.classificar(np.array([risco]), p["classes_limites"])[0]) - 1]
                linhas.append({"microrregiao": nome, "cenario": cen, "n_pixels": int(sel.sum()),
                               "n_questionarios": reg.get("n_questionarios", 0), "paerc": reg.get("PAERC"),
                               "paerc_ic95_inf": reg.get("PAERC_ic95_inf"), "paerc_ic95_sup": reg.get("PAERC_ic95_sup"),
                               "ameaca": _media(np.where(sel, pr["ameaca"], np.nan)),
                               "exposicao": _media(np.where(sel, pr["exposicao"], np.nan)),
                               "risco": risco, "classe_risco": classe})
        tabelas["risco_microrregioes.csv"] = linhas
    for nome, linhas in tabelas.items():
        _csv(tab / nome, linhas)
        arquivos.append(tab / nome)

    mapas = {"gerados": False, "motivo": "desativado"}
    if p["gerar_mapas"]:
        try:
            from .mapas_risco import gerar_mapas
            mapas = gerar_mapas(saida, resultados, rotulo, comb, prep, p, pa_info, prog.faixa(70, 96))
            arquivos.extend(Path(x) for x in mapas.get("arquivos", []))
        except ImportError as exc:
            mapas = {"gerados": False, "motivo": f"PyQGIS indisponível: {exc}"}
            avisos.append("Mapas não gerados: PyQGIS indisponível neste ambiente.")

    prog(96, "Relatório e manifesto")
    from .relatorio_risco import escrever
    rel = escrever(saida, t, comb, resumo, pa_info, pesos_usados, desc_exp, avisos, mapas, bool(t["ce_salinidade"]))
    arquivos.append(rel)
    for nome in sorted(ARQUIVOS_PREVIOS):
        alvo = saida / nome
        if alvo.is_file():
            arquivos.append(alvo)
        elif alvo.is_dir():
            arquivos.extend(f for f in sorted(alvo.rglob("*")) if f.is_file())

    entradas_hash = {"mapeamento/manifesto.json": mp["manifesto_sha256"]}
    for (cen, var, m), f in sorted(mp["arquivos"].items()):
        entradas_hash[f"mapeamento/{cen}/{f.name}"] = sha256(f)
    for rot, f in (("ce_salinidade", t["ce_salinidade"]), ("exposicao", t["exposicao"].get("arquivo")),
                   ("area", prep["area_arquivo"])):
        if f:
            entradas_hash[f"{rot}/{Path(f).name}"] = sha256(Path(f))
    if t["paerc"]:
        for k in ("questionarios", "microrregioes"):
            entradas_hash[f"paerc_{k}/{Path(t['paerc'][k]).name}"] = sha256(Path(t["paerc"][k]))

    manifesto = {
        "motor": {"nome": "motor_mapeamento.risco (AdaptaHorts)", "versao": __version__},
        "interface": t["bruto"].get("interface", {"nome": "linha de comando", "versao": __version__}),
        "versoes_bibliotecas": _versoes(),
        "situacao": "concluído com avisos" if avisos else "concluído",
        "trabalho": t["bruto"], "parametros_efetivos": p, "fontes_dos_parametros": FONTES,
        "combinacao": comb, "pesos_ameaca_usados": pesos_usados, "exposicao": desc_exp,
        "issa_modo": "estresse (CE do solo medida)" if t["ce_salinidade"] else "suscetibilidade climática (FAO-29)",
        "indice": p.get("indice"),
        "equacao": (f"{p['indice'].upper()} = {p['pesos'][p['indice']]['I']}·I + {p['pesos'][p['indice']]['D']}·D + "
                    f"{p['pesos'][p['indice']]['C']}·C" if p.get("indice") else
                    "Risco = Ameaça × Exposição × (1 − PAERC); Ameaça = média ponderada de ISOC, ISDH, ISCC, ISSA"),
        "resumo_cenarios": resumo, "paerc_microrregioes": pa_info["regioes"] if pa_info else None,
        "mapas": {k: v for k, v in mapas.items() if k != "arquivos"}, "avisos": avisos,
        "entradas_sha256": entradas_hash,
        "saidas_sha256": {str(f.relative_to(saida)): sha256(f) for f in sorted(set(arquivos))},
        "nota_integridade": "SHA-256 garante integridade dos arquivos, não autoria.",
    }
    return {"situacao": manifesto["situacao"], "saida": str(saida), "avisos": avisos, "manifesto": manifesto,
            "relatorio": str(rel),
            "resumo": resumo, "paerc": pa_info, "mapas": mapas}
