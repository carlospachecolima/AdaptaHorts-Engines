"""Questionário PAERC como camada GeoPackage com formulário pronto para QGIS e QField.

Cada propriedade é um ponto; o formulário tem abas por dimensão (Identificação, Econômica,
Técnica, Institucional, Itens pendentes), listas de opções e respostas obrigatórias.
"""

from __future__ import annotations

from pathlib import Path

from osgeo import ogr
from qgis.core import (QgsAttributeEditorContainer, QgsAttributeEditorField, QgsEditFormConfig,
                       QgsEditorWidgetSetup, QgsFieldConstraints, QgsVectorLayer)

from .. import geo
from .paerc import QUESTOES

ABAS = {"ID": "Identificação", "CE": "Econômica (CE)", "CT": "Técnica (CT)", "CI": "Institucional (CI)",
        "PENDENTE": "Itens sem faixas (não pontuam)"}
OGR_TIPO = {"texto": ogr.OFTString, "numero": ogr.OFTReal, "inteiro": ogr.OFTInteger, "sim_nao": ogr.OFTString,
            "opcao": ogr.OFTString}
ROTULOS_OPCAO = {"inexistente": "Inexistente", "pendente": "Pendente/irregular", "valido": "Válido/atualizado"}


def criar_formulario_gpkg(destino: Path) -> Path:
    from ..layouts_qgis import iniciar_qgis
    iniciar_qgis()
    destino = Path(destino)
    destino.parent.mkdir(parents=True, exist_ok=True)
    drv = ogr.GetDriverByName("GPKG")
    if destino.exists():
        drv.DeleteDataSource(str(destino))
    ds = drv.CreateDataSource(str(destino))
    lyr = ds.CreateLayer("questionario_paerc", geo.srs_wgs84(), ogr.wkbPoint)
    for q in QUESTOES:
        lyr.CreateField(ogr.FieldDefn(q["campo"], OGR_TIPO[q["tipo"]]))
    ds = None

    camada = QgsVectorLayer(f"{destino}|layername=questionario_paerc", "Questionário PAERC", "ogr")
    if not camada.isValid():
        raise RuntimeError("Não foi possível abrir a camada do questionário.")
    campos = camada.fields()
    for q in QUESTOES:
        i = campos.indexOf(q["campo"])
        camada.setFieldAlias(i, q["pergunta"])
        if q["tipo"] == "sim_nao":
            camada.setEditorWidgetSetup(i, QgsEditorWidgetSetup("ValueMap", {"map": [{"Sim": "sim"}, {"Não": "não"}]}))
        elif q["tipo"] == "opcao":
            camada.setEditorWidgetSetup(i, QgsEditorWidgetSetup(
                "ValueMap", {"map": [{ROTULOS_OPCAO.get(k, k): k} for k in q["opcoes"]]}))
        elif q["tipo"] in ("inteiro", "numero") and q["campo"] not in ("lon", "lat"):
            camada.setEditorWidgetSetup(i, QgsEditorWidgetSetup(
                "Range", {"Min": 0, "Max": 10 ** 9, "Step": 1 if q["tipo"] == "inteiro" else 0.01,
                          "Precision": 0 if q["tipo"] == "inteiro" else 2, "AllowNull": True, "Style": "SpinBox"}))
        if q["obrigatorio"]:
            camada.setFieldConstraint(i, QgsFieldConstraints.ConstraintNotNull, QgsFieldConstraints.ConstraintStrengthHard)
    cfg = camada.editFormConfig()
    cfg.setLayout(QgsEditFormConfig.TabLayout)
    cfg.clearTabs()
    for dim, titulo in ABAS.items():
        aba = QgsAttributeEditorContainer(titulo, None)
        if hasattr(aba, "setType"):  # QGIS ≥ 3.32
            from qgis.core import Qgis
            aba.setType(Qgis.AttributeEditorContainerType.Tab)
        else:
            aba.setIsGroupBox(False)
        for q in QUESTOES:
            if q["dim"] == dim:
                aba.addChildElement(QgsAttributeEditorField(q["campo"], campos.indexOf(q["campo"]), aba))
        cfg.addTab(aba)
    camada.setEditFormConfig(cfg)
    msg = camada.saveStyleToDatabase("questionario_paerc", "Formulário do questionário PAERC (AdaptaHorts)",
                                     True, "")
    if msg:
        raise RuntimeError(f"Não foi possível gravar o formulário no GeoPackage: {msg}")
    del camada
    return destino
