"""Módulo de risco climático do AdaptaHorts (ameaça × exposição × vulnerabilidade/PAERC)."""
