"""Linha de comando.

    python -m motor_mapeamento validar trabalho.json
    python -m motor_mapeamento processar trabalho.json
    python -m motor_mapeamento modelo-planilha observados_modelo.xlsx
    python -m motor_mapeamento questionario-paerc questionario_paerc.xlsx   (.gpkg exige PyQGIS)
    python -m motor_mapeamento risco trabalho_risco.json
"""

from __future__ import annotations

import argparse
import sys

from .config import DecisaoNecessaria, ErroValidacao


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="motor_mapeamento", description="Motor de mapeamento climático AdaptaHorts")
    sub = ap.add_subparsers(dest="comando", required=True)
    for c, h in (("validar", "Validação preliminar, sem processar"), ("processar", "Processamento completo")):
        s = sub.add_parser(c, help=h)
        s.add_argument("trabalho", help="Arquivo JSON do trabalho")
    s = sub.add_parser("modelo-planilha", help="Gera a planilha-modelo de dados observados")
    s.add_argument("destino", help="Caminho .xlsx ou .csv")
    s = sub.add_parser("questionario-paerc", help="Gera o questionário PAERC (.xlsx ou .gpkg com formulário)")
    s.add_argument("destino", help="Caminho .xlsx ou .gpkg")
    s = sub.add_parser("risco", help="Risco climático a partir de uma pasta de resultados do mapeamento")
    s.add_argument("trabalho", help="Arquivo JSON do trabalho de risco")
    s.add_argument("--indice", choices=["isoc", "isdh", "iscc", "issa"],
                   help="Calcula só este índice (com os componentes I, D e C), sem exposição nem PAERC")
    a = ap.parse_args(argv)
    try:
        if a.comando == "validar":
            from .pipeline import validar
            r = validar(a.trabalho)
            meses: dict[str, list[int]] = {}
            for v, m in r["variaveis_meses"]:
                meses.setdefault(v, []).append(m)
            print(f"Situação: {r['situacao']}")
            print("Combinação: " + " · ".join(f"{k}={v}" for k, v in r["combinacao"].items()))
            for v, ms in meses.items():
                print(f"  {v}: meses {', '.join(map(str, ms))}")
            print(f"Estações: {len(r['estacoes'])}")
            for av in r["avisos"]:
                print(f"AVISO: {av}")
        elif a.comando == "processar":
            from .pipeline import processar
            r = processar(a.trabalho)
            print(f"Situação: {r['situacao']}\nSaída: {r['saida']}")
            if r.get("zip"):
                print(f"ZIP: {r['zip']}")
            for av in r["avisos"]:
                print(f"AVISO: {av}")
        elif a.comando == "modelo-planilha":
            from .observados import criar_modelo_planilha
            print(criar_modelo_planilha(a.destino))
        elif a.comando == "questionario-paerc":
            if a.destino.lower().endswith(".gpkg"):
                from .risco.formulario_qgis import criar_formulario_gpkg
                print(criar_formulario_gpkg(a.destino))
            else:
                from .risco.paerc import criar_modelo_xlsx
                print(criar_modelo_xlsx(a.destino))
        else:
            from .risco.pipeline_risco import executar
            r = executar(a.trabalho, indice=a.indice)
            print(f"Situação: {r['situacao']}\nSaída: {r['saida']}")
            for linha in r["resumo"]:
                itens = [f"{k} {linha[k]:.3f}" for k in ("isoc", "isdh", "iscc", "issa", "ameaca", "risco_potencial",
                                                         "risco") if linha.get(k) is not None]
                print(f"  {linha['cenario']}: " + " · ".join(itens))
            for av in r["avisos"]:
                print(f"AVISO: {av}")
    except DecisaoNecessaria as e:
        print("DECISÃO NECESSÁRIA:\n" + str(e), file=sys.stderr)
        return 3
    except ErroValidacao as e:
        print("ERROS DE VALIDAÇÃO (corrija e execute novamente):\n" + str(e), file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
