"""Layouts cartográficos bilíngues com PyQGIS (A4 paisagem, PDF e PNG a 300 dpi).

Funciona dentro do QGIS (complemento) ou de forma autônoma (sem interface gráfica).
"""

from __future__ import annotations

import os
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ.setdefault("GDAL_PAM_ENABLED", "NO")  # não criar .aux.xml ao lado dos rasters de saída

from qgis.core import (Qgis, QgsApplication, QgsBasicNumericFormat, QgsColorRampLegendNodeSettings, QgsColorRampShader, QgsCoordinateReferenceSystem,  # noqa: E402
                       QgsFillSymbol, QgsLayoutExporter, QgsLayoutItemLabel, QgsLayoutItemLegend,
                       QgsLayoutItemMap, QgsLayoutItemMapGrid, QgsLayoutItemPicture, QgsLayoutItemScaleBar,
                       QgsLayoutPoint, QgsLayoutSize, QgsLegendRenderer, QgsMapLayerLegendUtils, QgsLegendStyle, QgsPrintLayout,
                       QgsProject, QgsRasterLayer, QgsRasterShader, QgsRectangle, QgsScaleBarSettings,
                       QgsSingleBandPseudoColorRenderer, QgsTextFormat, QgsUnitTypes, QgsVectorLayer)
from osgeo import gdal  # noqa: E402
from qgis.PyQt.QtCore import Qt  # noqa: E402
from qgis.PyQt.QtGui import QColor, QFont  # noqa: E402

from . import __version__  # noqa: E402
from .config import MESES, VARIAVEIS  # noqa: E402

# ColorBrewer RdYlBu (11 classes), do vermelho ao azul.
RDYLBU = ["#a50026", "#d73027", "#f46d43", "#fdae61", "#fee090", "#ffffbf",
          "#e0f3f8", "#abd9e9", "#74add1", "#4575b4", "#313695"]

TEXTOS = {
    "pt": {"modelo": "Modelo", "cenario": "Cenário", "periodo": "Período", "historico": "Histórico corrigido",
           "fontes": "Fontes: WorldClim v2.1 (Fick & Hijmans, 2017){cmip}; correção regional (método Delta) com "
                     "{n} estação(ões) INMET/BDMEP em {l} local(is), fornecidas pelo usuário.",
           "tecnico": "SRC: WGS 84 (EPSG:4326) · Resolução: 30 segundos de arco (≈ 0,9 km no Equador) · "
                      "Motor AdaptaHorts v{v}",
           "titulo": "{var} — {mes}"},
    "en": {"modelo": "Model", "cenario": "Scenario", "periodo": "Period", "historico": "Bias-corrected historical",
           "fontes": "Sources: WorldClim v2.1 (Fick & Hijmans, 2017){cmip}; regional bias correction (Delta method) "
                     "with {n} INMET/BDMEP station(s) at {l} site(s), provided by the user.",
           "tecnico": "CRS: WGS 84 (EPSG:4326) · Resolution: 30 arc-seconds (≈ 0.9 km at the Equator) · "
                      "AdaptaHorts engine v{v}",
           "titulo": "{var} — {mes}"},
}

_APP = None


def iniciar_qgis() -> QgsApplication:
    global _APP
    app = QgsApplication.instance()
    if app is not None:
        return app
    QgsApplication.setPrefixPath(os.environ.get("QGIS_PREFIX_PATH", "/usr"), True)
    _APP = QgsApplication([], False)
    _APP.initQgis()
    return _APP


def _fmt(tamanho: float, negrito: bool = False) -> QgsTextFormat:
    f = QgsTextFormat()
    fonte = QFont("DejaVu Sans")
    fonte.setBold(negrito)
    f.setFont(fonte)
    f.setSize(tamanho)
    f.setSizeUnit(Qgis.RenderUnit.Points)
    f.setColor(QColor("#1a1a1a"))
    return f


def _rotulo(layout, texto, x, y, w, h, tamanho, negrito=False, alinh=Qt.AlignLeft) -> QgsLayoutItemLabel:
    lb = QgsLayoutItemLabel(layout)
    lb.setText(texto)
    lb.setTextFormat(_fmt(tamanho, negrito))
    lb.setHAlign(alinh)
    lb.setVAlign(Qt.AlignTop)
    layout.addLayoutItem(lb)
    lb.attemptMove(QgsLayoutPoint(x, y, QgsUnitTypes.LayoutMillimeters))
    lb.attemptResize(QgsLayoutSize(w, h, QgsUnitTypes.LayoutMillimeters))
    return lb


def aplicar_simbologia(camada: QgsRasterLayer, var: str, lim: dict) -> None:
    if lim.get("qml"):
        msg, ok = camada.loadNamedStyle(lim["qml"])
        if not ok:
            raise RuntimeError(f"Falha ao carregar o estilo QML {lim['qml']}: {msg}")
        return
    cores = RDYLBU[::-1] if VARIAVEIS[var]["tipo"] == "temperatura" else RDYLBU
    vmin, vmax = lim["min"], lim["max"]
    fn = QgsColorRampShader(vmin, vmax)
    fn.setColorRampType(QgsColorRampShader.Interpolated)
    n = len(cores)
    fn.setColorRampItemList([QgsColorRampShader.ColorRampItem(vmin + (vmax - vmin) * i / (n - 1), QColor(c),
                                                              f"{vmin + (vmax - vmin) * i / (n - 1):.1f}")
                             for i, c in enumerate(cores)])
    fn.setClip(False)
    num = QgsBasicNumericFormat()
    num.setNumberDecimalPlaces(1)
    num.setShowTrailingZeros(True)
    leg = QgsColorRampLegendNodeSettings()
    leg.setUseContinuousLegend(True)
    leg.setNumericFormat(num)
    fn.setLegendSettings(leg)
    sh = QgsRasterShader()
    sh.setRasterShaderFunction(fn)
    r = QgsSingleBandPseudoColorRenderer(camada.dataProvider(), 1, sh)
    r.setClassificationMin(vmin)
    r.setClassificationMax(vmax)
    camada.setRenderer(r)


def _intervalo_grade(ext: QgsRectangle) -> float:
    vao = max(ext.width(), ext.height())
    for iv in (0.05, 0.1, 0.2, 0.25, 0.5, 1, 2, 5, 10):
        if vao / iv <= 6:
            return iv
    return 20


def _seta_norte() -> str | None:
    for base in QgsApplication.svgPaths() + ["/usr/share/qgis/svg"]:
        p = Path(base) / "arrows" / "NorthArrow_02.svg"
        if p.exists():
            return str(p)
    return None


def criar_layout(projeto: QgsProject, camada: QgsRasterLayer, contorno: QgsVectorLayer, item: dict,
                 comb: dict, idioma: str, extensao: QgsRectangle) -> QgsPrintLayout:
    tx = TEXTOS[idioma]
    var, mes = item["variavel"], item["mes"]
    info = VARIAVEIS[var]
    unidade = info[f"unidade_{idioma}"]
    mes_nome = MESES[mes - 1][0 if idioma == "pt" else 1]
    lay = QgsPrintLayout(projeto)
    lay.initializeDefaults()  # A4 paisagem
    lay.setName(f"{item['nome']}_{idioma}")

    _rotulo(lay, tx["titulo"].format(var=info[idioma], mes=mes_nome), 10, 7, 277, 10, 18, True, Qt.AlignHCenter)
    if item["tipo"] == "projecao":
        sub = (f"{tx['modelo']}: {comb['modelo']}  ·  {tx['cenario']}: {comb['ssp']}  ·  "
               f"{tx['periodo']}: {comb['periodo']}")
    else:
        sub = f"{tx['historico']}  ·  {tx['periodo']}: 1970–2000"
    _rotulo(lay, sub, 10, 17, 277, 6, 10, False, Qt.AlignHCenter)

    mapa = QgsLayoutItemMap(lay)
    mapa.setCrs(QgsCoordinateReferenceSystem("EPSG:4326"))
    mapa.setLayers([contorno, camada])
    mapa.setKeepLayerSet(True)
    mapa.setFrameEnabled(True)
    lay.addLayoutItem(mapa)
    mapa.attemptMove(QgsLayoutPoint(14, 26, QgsUnitTypes.LayoutMillimeters))
    mapa.attemptResize(QgsLayoutSize(200, 160, QgsUnitTypes.LayoutMillimeters))
    mapa.zoomToExtent(extensao)

    grade = QgsLayoutItemMapGrid("grade", mapa)
    mapa.grids().addGrid(grade)
    iv = _intervalo_grade(mapa.extent())
    grade.setIntervalX(iv)
    grade.setIntervalY(iv)
    grade.setStyle(QgsLayoutItemMapGrid.Solid)
    sym = grade.lineSymbol()
    sym.setColor(QColor(0, 0, 0, 60))
    sym.setWidth(0.1)
    grade.setFrameStyle(QgsLayoutItemMapGrid.Zebra)
    grade.setFrameWidth(1.2)
    grade.setAnnotationEnabled(True)
    grade.setAnnotationFormat(QgsLayoutItemMapGrid.DecimalWithSuffix)
    grade.setAnnotationPrecision(2 if iv < 0.1 else (1 if iv < 1 else 0))
    grade.setAnnotationTextFormat(_fmt(7))
    for lado in (QgsLayoutItemMapGrid.Left, QgsLayoutItemMapGrid.Right):
        grade.setAnnotationDirection(QgsLayoutItemMapGrid.Vertical, lado)

    leg = QgsLayoutItemLegend(lay)
    leg.setLinkedMap(mapa)
    leg.setAutoUpdateModel(False)
    raiz = leg.model().rootGroup()
    raiz.clear()
    no = raiz.addLayer(camada)
    QgsLegendRenderer.setNodeLegendStyle(no, QgsLegendStyle.Hidden)
    nos = leg.model().layerLegendNodes(no)
    if len(nos) > 1:  # remove a linha "Band 1: ... (Gray)" e mantém só a rampa de cores
        QgsMapLayerLegendUtils.setLegendNodeOrder(no, list(range(1, len(nos))))
        leg.model().refreshLayerLegend(no)
    leg.setTitle(f"{info[idioma]}\n({unidade})")
    leg.rstyle(QgsLegendStyle.Title).setTextFormat(_fmt(10, True))
    leg.rstyle(QgsLegendStyle.SymbolLabel).setTextFormat(_fmt(8))
    leg.setSymbolHeight(45)
    leg.setSymbolWidth(6)
    lay.addLayoutItem(leg)
    leg.attemptMove(QgsLayoutPoint(222, 30, QgsUnitTypes.LayoutMillimeters))
    leg.refresh()

    seta = _seta_norte()
    if seta:
        pic = QgsLayoutItemPicture(lay)
        pic.setPicturePath(seta)
        lay.addLayoutItem(pic)
        pic.attemptMove(QgsLayoutPoint(232, 112, QgsUnitTypes.LayoutMillimeters))
        pic.attemptResize(QgsLayoutSize(14, 20, QgsUnitTypes.LayoutMillimeters))
    else:
        _rotulo(lay, "N\n▲", 232, 112, 14, 20, 14, True, Qt.AlignHCenter)

    esc = QgsLayoutItemScaleBar(lay)
    esc.setStyle("Single Box")
    esc.setLinkedMap(mapa)
    esc.setUnits(Qgis.DistanceUnit.Kilometers)
    esc.setUnitLabel("km")
    esc.setNumberOfSegmentsLeft(0)
    esc.setNumberOfSegments(2)
    esc.setSegmentSizeMode(QgsScaleBarSettings.SegmentSizeFitWidth)
    esc.setMinimumBarWidth(25)
    esc.setMaximumBarWidth(55)
    esc.setTextFormat(_fmt(7))
    lay.addLayoutItem(esc)
    esc.attemptMove(QgsLayoutPoint(222, 145, QgsUnitTypes.LayoutMillimeters))
    esc.update()

    cmip = f"; CMIP6 {comb['modelo']} {comb['ssp']} {comb['periodo']}" if item["tipo"] == "projecao" else ""
    _rotulo(lay, tx["fontes"].format(cmip=cmip, n=item["n_estacoes"], l=item["n_locais"]), 14, 190, 270, 8, 7)
    _rotulo(lay, tx["tecnico"].format(v=__version__), 14, 198, 270, 6, 7)
    return lay


def gerar_layouts(saida: Path, camadas: list[dict], prep, limites: dict, prog=None) -> dict:
    p = prep.trabalho.parametros
    comb = prep.combinacao
    iniciar_qgis()
    projeto = QgsProject()
    projeto.setCrs(QgsCoordinateReferenceSystem("EPSG:4326"))
    projeto.setEllipsoid("EPSG:7030")
    pasta_proj = saida / "projeto_qgis"
    pasta_proj.mkdir(parents=True, exist_ok=True)
    projeto.setFileName(str(pasta_proj / f"{comb['periodo']}_{comb['ssp']}_{comb['modelo']}.qgz"))
    projeto.writeEntryBool("Paths", "/Absolute", False)

    area_shp = pasta_proj / "area_estudo.gpkg"
    prep.area.salvar_gpkg(area_shp)
    contorno = QgsVectorLayer(str(area_shp), "Área de estudo", "ogr")
    if not contorno.isValid():
        raise RuntimeError("Não foi possível carregar a área de estudo no QGIS.")
    contorno.setRenderer(contorno.renderer().clone())
    contorno.renderer().setSymbol(QgsFillSymbol.createSimple(
        {"color": "0,0,0,0", "outline_color": "30,30,30,255", "outline_width": "0.5"}))
    projeto.addMapLayer(contorno)
    ext = contorno.extent()
    ext.grow(max(ext.width(), ext.height()) * 0.05)

    arquivos, n = [], 0
    pasta_mapas = saida / "mapas"
    raiz = projeto.layerTreeRoot()
    selecionadas = [c for c in camadas if c["tipo"] == "projecao" or p["mapas_historico"]]
    for i, item in enumerate(selecionadas):
        if prog is not None:
            prog(100.0 * i / max(1, len(selecionadas)), f"Mapas: {item['nome']}")
        cam = QgsRasterLayer(str(item["tif"]), item["nome"], "gdal")
        if not cam.isValid():
            raise RuntimeError(f"Raster inválido para o QGIS: {item['tif']}")
        aplicar_simbologia(cam, item["variavel"], limites[item["variavel"]])
        projeto.addMapLayer(cam, False)
        grupo = raiz.findGroup(item["variavel"]) or raiz.addGroup(item["variavel"])
        grupo.addLayer(cam)
        for idioma in p["idiomas"]:
            lay = criar_layout(projeto, cam, contorno, item, comb, idioma, ext)
            projeto.layoutManager().addLayout(lay)
            exp = QgsLayoutExporter(lay)
            destino = pasta_mapas / item["variavel"] / idioma
            destino.mkdir(parents=True, exist_ok=True)
            base = destino / f"{item['nome']}_{idioma}"
            if "pdf" in p["formatos_mapa"]:
                cfg = QgsLayoutExporter.PdfExportSettings()
                cfg.dpi = p["dpi"]
                cfg.rasterizeWholeImage = False
                cfg.exportMetadata = False
                r = exp.exportToPdf(str(base) + ".pdf", cfg)
                if r != QgsLayoutExporter.Success:
                    raise RuntimeError(f"Falha ao exportar PDF {base}.pdf (código {r}).")
                arquivos.append(str(base) + ".pdf")
            if "png" in p["formatos_mapa"]:
                cfg = QgsLayoutExporter.ImageExportSettings()
                cfg.dpi = p["dpi"]
                cfg.exportMetadata = False
                gdal.PushErrorHandler("CPLQuietErrorHandler")  # PNG não aceita georreferência embutida
                try:
                    r = exp.exportToImage(str(base) + ".png", cfg)
                finally:
                    gdal.PopErrorHandler()
                if r != QgsLayoutExporter.Success:
                    raise RuntimeError(f"Falha ao exportar PNG {base}.png (código {r}).")
                arquivos.append(str(base) + ".png")
            n += 1
    if p["salvar_projeto_qgis"]:
        if not projeto.write():
            raise RuntimeError("Falha ao salvar o projeto QGIS.")
        arquivos.append(projeto.fileName())
        arquivos.append(str(area_shp))
    return {"gerados": True, "n_mapas": n, "arquivos": arquivos, "qgis": Qgis.QGIS_VERSION,
            "pagina": "A4 paisagem", "dpi": p["dpi"]}
