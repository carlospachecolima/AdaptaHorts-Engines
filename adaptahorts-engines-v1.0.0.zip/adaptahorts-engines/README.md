# AdaptaHorts engines (v1.0.0)

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.XXXXXXX.svg)](https://doi.org/10.5281/zenodo.XXXXXXX)
![License: BSD-3-Clause](https://img.shields.io/badge/license-BSD--3--Clause-blue)

Python engines of **AdaptaHorts**, an open climate intelligence prototype for family-run vegetable crops developed at Embrapa Hortaliças (Embrapa Vegetables), Brazil. The engines turn published agronomic knowledge into auditable, low-cost AI tools for climate adaptation and climate justice in family agriculture.

| Engine | What it does | Folder |
|---|---|---|
| **PFBCIA v1.0.0** | Low-cost AI phenotyping: diagnoses climate-driven disorders from photographs of eight vegetable crops (lettuce, potato, sweet potato, onion, carrot, cowpea, arracacha, hot pepper), restricted to mean, minimum and maximum temperature, excess rainfall and drought. Knowledge base of 296 literature statements verified verbatim against 24 sources; three validation layers (literature check, runtime audit, statistical protocol against expert images). | [`engines/pfbcia_agent`](engines/pfbcia_agent) |
| **AIGIS Agent** | Prompt chain and PyQGIS functions for climate-scenario mapping (WorldClim CMIP6, INPE Eta-HadGEM2-ES) and thermal-vulnerability reclassification with the Thermal Severity Index. | [`engines/aigis_agent`](engines/aigis_agent) |
| **Recommendation Agent** | Deterministic rule engine linking climate-risk conditions (from indicators such as the Thermal Severity Index, aridity index and rainfall anomaly) to resilient management practices. | [`engines/recommendation_agent`](engines/recommendation_agent) |

Each engine has its own README (in Portuguese) with full usage instructions.

## Quick start

Requires Python 3.10+. The AIGIS map and vulnerability modes also require QGIS (PyQGIS); live PFBCIA runs require an API key for Anthropic, OpenAI or Gemini.

```bash
git clone https://github.com/carlospachecolima/adaptahorts-engines.git
cd adaptahorts-engines

# verify integrity of all engines
python3 verify_public.py

# PFBCIA: list crops and print a prompt chain without any API call
python3 engines/pfbcia_agent/pfbcia_agent.py --list-crops
python3 engines/pfbcia_agent/pfbcia_agent.py --crop cebola --context "Tmin 4 °C for 3 nights" --dry-run

# PFBCIA: live diagnosis of a photograph
export ANTHROPIC_API_KEY=...   # or OPENAI_API_KEY / GEMINI_API_KEY
python3 engines/pfbcia_agent/pfbcia_agent.py --crop batata --image photo.jpg --backend anthropic --out report.json

# AIGIS: generate the mapping prompt chain (no QGIS needed)
python3 engines/aigis_agent/aigis_agent.py chain --source worldclim_cmip6

# Recommendation Agent: practices for a thermal severity index of 7 and an aridity index of 0.4
python3 engines/recommendation_agent/recommendation_agent.py from-indicators --severity-index 7 --aridity-index 0.4
```

Run each script with `--help` for all options.

## Integrity (SHA-256)

Every engine folder contains `SHA256SUMS.txt` (SHA-256 of each file) and `verify_hashes.py`. The **aggregate fingerprint** of an engine is the SHA-256 of its `SHA256SUMS.txt`; any change to any file changes it.

| Engine | Aggregate SHA-256 |
|---|---|
| PFBCIA v1.0.0 | `d24ba1a20e3b245544049e773fa0365f3e9fbe9e0cc72aad9161741d4eb9b6a3` |
| AIGIS Agent | `f0c25f1dbb1ec7c2db21a1feaf340f0e90817a8c1c06b0066badae205f45f400` |
| Recommendation Agent | `3ec2a5de0839be2ee9be56aacbd8e8817f20fd6cc7959a0641652001af4f3e2c` |

`verify_public.py` checks every distributed file and the aggregate fingerprints. Third-party source texts and reference photographs used by PFBCIA are **not redistributed** here; they remain listed, with their hashes, in [`RESTRICTED_FILES.md`](RESTRICTED_FILES.md) and are available from the authors upon request.

## Status

This is a **verified first prototype**. The knowledge bases have been validated against the literature and the software has been verified; performance against expert scores will be reported crop by crop in companion studies that test this frozen version. Corrections will be released as new versions with new fingerprints.

## How to cite

Please cite the software (Zenodo DOI above) and the paper:

> M. R. Fontenelle, M. B. Braga, Í. M. R. Guedes, J. da Silva, F. A. Suinaga, and C. E. P. Lima, “AdaptaHorts: A prototype of literature-grounded AI agents for climate risk diagnosis in family-run vegetable crops,” submitted to *IEEE Access*, 2026.

A `CITATION.cff` file is provided; GitHub shows a "Cite this repository" button.

## Funding

National Council for Scientific and Technological Development (CNPq), Brazil — Call 18/2024, grant 313563/2025-0; Brazilian Agricultural Research Corporation (Embrapa) — project SEG 10.25.17.003.00.00, *Adaptation of Family Farming to Climate Change: Science and Innovation for Climate Justice and a Just Transition*.

## License

BSD 3-Clause — see [`LICENSE`](LICENSE). © 2026 Empresa Brasileira de Pesquisa Agropecuária (Embrapa).
