#!/usr/bin/env python3
"""Verify the integrity of the AdaptaHorts engines in this repository.

For each engine, every file listed in its SHA256SUMS.txt that is present is
re-hashed and compared. Files intentionally not redistributed (third-party
source texts and reference photographs of PFBCIA, see RESTRICTED_FILES.md)
are reported as "not distributed" and do not count as failures. The
aggregate fingerprint of each engine (SHA-256 of its SHA256SUMS.txt) is
recomputed and compared with the published value.

Usage:  python3 verify_public.py
Exit code 1 if any distributed file is altered or the manifest differs.
"""
import hashlib
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent / "engines"
EXPECTED = {
    "pfbcia_agent": "d24ba1a20e3b245544049e773fa0365f3e9fbe9e0cc72aad9161741d4eb9b6a3",
    "aigis_agent": "f0c25f1dbb1ec7c2db21a1feaf340f0e90817a8c1c06b0066badae205f45f400",
    "recommendation_agent": "3ec2a5de0839be2ee9be56aacbd8e8817f20fd6cc7959a0641652001af4f3e2c",
}
RESTRICTED = ("literature/texts/",)
IMG = (".jpg", ".jpeg", ".png")


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    failed = False
    for engine, expected in EXPECTED.items():
        base = ROOT / engine
        sums = base / "SHA256SUMS.txt"
        agg = sha256(sums)
        ok_n = miss_n = bad_n = 0
        for line in sums.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            digest, rel = line.split(maxsplit=1)
            rel = rel.strip().lstrip("*")
            p = base / rel
            if not p.exists():
                if rel.startswith(RESTRICTED) or (rel.startswith("reference/") and rel.lower().endswith(IMG)):
                    miss_n += 1
                    continue
                print(f"  MISSING  {engine}/{rel}")
                bad_n += 1
            elif sha256(p) != digest:
                print(f"  ALTERED  {engine}/{rel}")
                bad_n += 1
            else:
                ok_n += 1
        agg_ok = agg == expected
        status = "OK" if (bad_n == 0 and agg_ok) else "FAIL"
        print(f"[{status}] {engine}: {ok_n} files verified, {miss_n} not distributed, {bad_n} problems")
        print(f"       aggregate SHA-256 {agg} ({'matches' if agg_ok else 'DOES NOT match'} published value)")
        failed |= status == "FAIL"
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
