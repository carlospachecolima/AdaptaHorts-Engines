# Códigos hash — Recommendation Agent (proposição automatizada de sistemas resilientes)

Algoritmo: SHA-256. Gerados em 15/10/2026, sem alteração no código ou no README enviados.

## Hash do agente

SHA-256 do arquivo `SHA256SUMS.txt`, que lista o SHA-256 de cada arquivo do pacote:

```
3ec2a5de0839be2ee9be56aacbd8e8817f20fd6cc7959a0641652001af4f3e2c
```

## Arquivos

| Arquivo | SHA-256 |
|---|---|
| `README.md` | `bdd64e9c3fec4548f827f99164f4611dcd58214a7e8b6ebf0c81af46e7635b41` |
| `recommendation_agent.py` | `3e86086c0f2ad5d7b15df1971c5298d76cbff0b05e7501c5d2a4410e3d8b3ddf` |
| `verify_hashes.py` | `840dffaa9481485d803df64ce8c5d1594ae0995640300acfc05b1ffbb2c65652` |

## Arquivo original recebido

`recommendation_agent.zip`, como enviado (README.md + recommendation_agent.py):

```
4c26b36cfca5308d68b99c63e999790e7ecae4ac8ab45bb8ef01d4b00191f545
```

## Como verificar

```bash
python3 verify_hashes.py
```

Este arquivo (`HASHES.md`) não entra no cálculo, porque contém o próprio hash.
