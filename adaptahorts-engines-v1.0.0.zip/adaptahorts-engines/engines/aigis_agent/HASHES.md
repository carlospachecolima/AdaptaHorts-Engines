# Códigos hash — AIGIS Agent (motor de mapeamento automatizado)

Algoritmo: SHA-256. Gerados em 15/10/2026, sem alteração no código ou no README enviados.

## Hash do agente

SHA-256 do arquivo `SHA256SUMS.txt`, que lista o SHA-256 de cada arquivo do pacote:

```
f0c25f1dbb1ec7c2db21a1feaf340f0e90817a8c1c06b0066badae205f45f400
```

## Arquivos

| Arquivo | SHA-256 |
|---|---|
| `README.md` | `e6113304d9aa588f16e539df6bfb75a4b8ee5075c9cf7b60da8971cca3ae7477` |
| `aigis_agent.py` | `5d71b5d2215f718a52c4ba9f0e1c5f5ca7502b86704ce10e8bf2c027ca5bf45d` |
| `verify_hashes.py` | `23f072e1a453c2dfeb654045098b64091d07dcbe28f3579d81f0e1dcbba9597e` |

## Arquivo original recebido

`aigis_mapping_agent.zip`, como enviado (README.md + aigis_agent.py):

```
354ac9e402d2dc2c7cd6d2749ec6f37a5b804f67db4cbcf6a0687a3e7b4d5da9
```

## Como verificar

```bash
python3 verify_hashes.py
```

Este arquivo (`HASHES.md`) não entra no cálculo, porque contém o próprio hash.
