#!/usr/bin/env python3
"""
literature_check.py — Validação das bases de conhecimento contra a literatura
=============================================================================

Para cada perfil em crops/*.json verifica:

  1. ESCOPO CLIMÁTICO — todo fator atribuído a um sintoma pertence ao
     vocabulário único de climate_drivers.json (Tméd, Tmín, Tmáx,
     precipitação excessiva, seca). Qualquer outro fator reprova o perfil.
  2. LITERALIDADE — cada trecho citado existe palavra por palavra no texto
     da fonte (após normalizar espaços e quebras de linha).
  3. RASTREABILIDADE — cada atribuição sintoma → fator cita pelo menos uma
     afirmação verificada; atribuições "inferido" são contadas à parte.
  4. Diferenciais (fora do escopo), limiares e escala também precisam citar
     afirmações existentes.

Status possíveis: aprovado | aprovado_parcial (alguns sintomas ainda sem
fonte) | reprovado | pendente_fonte (perfil no escopo
climático, mas ainda sem trechos de fonte — não pode ser usado como
"verificado").

Uso:
    python3 literature_check.py [--crop cebola] [--out relatorio.json]
Sai com código 1 se algum perfil for reprovado.
"""

from __future__ import annotations

import argparse
import json
import re
import unicodedata
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DRIVERS = json.loads((ROOT / "climate_drivers.json").read_text(encoding="utf-8"))
VOCAB = set(DRIVERS["fatores"])


def normalize(text: str) -> str:
    text = unicodedata.normalize("NFC", text)
    text = re.sub(r"-\s*\n\s*", "-", text)
    return re.sub(r"\s+", " ", text).strip()


def check_profile(path: Path) -> dict:
    prof = json.loads(path.read_text(encoding="utf-8"))
    status_decl = prof.get("status_literatura")
    errors, warnings = [], []
    n_links = n_inferred = n_pending = 0

    # 1. escopo climático (vale para todos os perfis)
    for s in prof.get("symptoms", []):
        if not s.get("fatores"):
            errors.append(f"Sintoma '{s['id']}' sem nenhum fator climático.")
        for f in s.get("fatores", []):
            n_links += 1
            if f["fator"] not in VOCAB:
                errors.append(f"Sintoma '{s['id']}': fator '{f['fator']}' fora do escopo climático do motor.")
            if f.get("tipo") == "inferido":
                n_inferred += 1
            if f.get("tipo") == "pendente_fonte":
                n_pending += 1
    for l in prof.get("limiares", []):
        if l["fator"] not in VOCAB:
            errors.append(f"Limiar com fator '{l['fator']}' fora do escopo.")

    if status_decl not in ("verificado", "parcial"):
        if n_pending:
            warnings.append(f"{n_pending} atribuições sintoma → fator sem trecho de fonte (pendente_fonte).")
        return {"crop": prof["key"], "status": "reprovado" if errors else "pendente_fonte",
                "atribuicoes": n_links, "errors": errors, "warnings": warnings, "claims": {}}

    # 2. literalidade
    texts = {}
    for sid, s in prof.get("sources", {}).items():
        f = ROOT / s.get("text_file", "")
        if f.is_file():
            texts[sid] = normalize(f.read_text(encoding="utf-8"))
        else:
            errors.append(f"Fonte {sid}: arquivo de texto ausente ({f}).")
    claims = prof.get("claims", {})
    verified = {}
    for cid, c in claims.items():
        sid, q = c.get("source"), normalize(c.get("quote", ""))
        ok = sid in texts and len(q) >= 15 and q in texts[sid]
        verified[cid] = ok
        if not ok:
            errors.append(f"{cid}: trecho NÃO encontrado literalmente em {sid}: \"{c.get('quote','')[:80]}…\"")

    def need(ref: str, where: str):
        if ref not in claims:
            errors.append(f"{where}: cita afirmação inexistente {ref}.")
        used.add(ref)

    # 3. rastreabilidade
    used: set[str] = set()
    pending_syms = []
    for s in prof.get("symptoms", []):
        if s.get("status_evidencia") == "pendente_fonte":
            pending_syms.append(s["id"])
            continue
        for e in s.get("evidencias", []) + s.get("manejo", []):
            need(e, f"Sintoma '{s['id']}'")
        if not any(verified.get(e) for e in s.get("evidencias", [])):
            errors.append(f"Sintoma '{s['id']}' sem evidência verificada.")
        for f in s.get("fatores", []):
            for e in f.get("claims", []):
                need(e, f"Sintoma '{s['id']}' → {f['fator']}")
            if not any(verified.get(e) for e in f.get("claims", [])):
                errors.append(f"Atribuição '{s['id']}' → '{f['fator']}' sem trecho verificado.")
            if f.get("tipo") not in ("direto", "inferido"):
                errors.append(f"Atribuição '{s['id']}' → '{f['fator']}': tipo deve ser direto ou inferido.")
        ref = s.get("referencia_visual")
        if ref and not (ROOT / ref).is_file():
            warnings.append(f"Sintoma '{s['id']}': imagem de referência ausente ({ref}).")
    for d in prof.get("diferenciais", []):
        for e in d.get("evidencias", []) + ([d["risco_consumo"]] if d.get("risco_consumo") else []):
            need(e, f"Diferencial '{d['id']}'")
    for l in prof.get("limiares", []):
        for e in l.get("claims", []):
            need(e, f"Limiar {l['fator']}")
    for e in prof.get("score_scale", {}).get("evidencias", []) + prof.get("context_claims", []):
        need(e, "Escala/contexto")
    for cid in claims:
        if cid not in used:
            warnings.append(f"{cid}: afirmação verificada mas não usada.")
    if n_inferred:
        warnings.append(f"{n_inferred} atribuição(ões) do tipo 'inferido' — revisar com especialista.")

    if pending_syms:
        warnings.append(f"Sintomas ainda sem fonte verificada (pendente_fonte): {', '.join(pending_syms)}")
    sem_ref = [s["id"] for s in prof.get("symptoms", []) if not s.get("referencia_visual")]
    if sem_ref:
        warnings.append(f"Sintomas sem foto de referência para validação: {', '.join(sem_ref)}")

    return {
        "crop": prof["key"],
        "status": "reprovado" if errors else ("aprovado_parcial" if pending_syms else "aprovado"),
        "claims_verified": f"{sum(verified.values())}/{len(claims)}",
        "symptoms": len(prof.get("symptoms", [])),
        "symptoms_pendentes": len(pending_syms),
        "diferenciais": len(prof.get("diferenciais", [])),
        "atribuicoes": n_links, "inferidas": n_inferred,
        "errors": errors, "warnings": warnings, "claims": verified,
    }


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Valida as bases de conhecimento do PFBCIA contra a literatura.")
    ap.add_argument("--crop")
    ap.add_argument("--out", type=Path)
    a = ap.parse_args(argv)
    files = [ROOT / "crops" / f"{a.crop}.json"] if a.crop else sorted((ROOT / "crops").glob("*.json"))
    reports = [check_profile(f) for f in files]
    for r in reports:
        extra = (f" — afirmações {r['claims_verified']}, sintomas {r['symptoms']} ({r['symptoms_pendentes']} pendentes), diferenciais {r['diferenciais']}, "
                 f"atribuições {r['atribuicoes']} ({r['inferidas']} inferidas)") if "claims_verified" in r else \
                f" — atribuições {r['atribuicoes']}"
        print(f"[{r['status'].upper():>14}] {r['crop']}{extra}")
        for e in r["errors"]:
            print(f"    ERRO  {e}")
        for w in r["warnings"]:
            print(f"    aviso {w}")
    if a.out:
        a.out.write_text(json.dumps(reports, ensure_ascii=False, indent=2), encoding="utf-8")
    return 1 if any(r["status"] == "reprovado" for r in reports) else 0


if __name__ == "__main__":
    raise SystemExit(main())
