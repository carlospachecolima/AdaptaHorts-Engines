# Códigos hash — PFBCIA Agent v1.0.0

Algoritmo: SHA-256. Gerados em 15/10/2026.

## Hash do agente

Este é o hash agregado: o SHA-256 do arquivo `SHA256SUMS.txt`, que lista o SHA-256 de cada um dos 128 arquivos do pacote. Se qualquer arquivo mudar, este hash muda.

```
d24ba1a20e3b245544049e773fa0365f3e9fbe9e0cc72aad9161741d4eb9b6a3
```

## Componentes principais

| Arquivo | SHA-256 |
|---|---|
| `pfbcia_agent.py` | `24d195cbfc987510d4cd4923084cb1b4c2532ed517b77a83ed690e1694e26f77` |
| `literature_check.py` | `78cb51abc50c27429bfec38a4e951e2a42e8eade9d28fe1078513971c0b7936b` |
| `validate.py` | `1585cbb13d4e4f3e1e53f9a278cbae116e636c7299db4f227fd162366883f4bb` |
| `verify_hashes.py` | `b4ad81bd6a50f458c355ad5773f2b800737ff6bd0a10bffec6d33470ada7337b` |
| `climate_drivers.json` | `1c185e3356451793a6df20e5552243ecb702b6d9891c113a2f03524b8d5f4963` |
| `crops/alface.json` | `c22299c341a93cef94bd1815fc2620dfb5992415623058824310ee6d9b5382ef` |
| `crops/batata.json` | `50be0efc4879bc652427932aa9b4a18542fe08046f0d44fefc674b825447e9b7` |
| `crops/batata_doce.json` | `8de9c9bcb40a4b4ffe6bd950c18899f69c5711a39e3d11e158ab3e3e48fe0b92` |
| `crops/cebola.json` | `37ccd1b7155b023c6855f7252b6e22ad9c0db6bf39300abe3579425e9edcbcee` |
| `crops/cenoura.json` | `4c55bd656e8db388ccbda8051aaabd8ed66cad6a08cee0e7a5f3340dcb444f64` |
| `crops/feijao_caupi.json` | `429720f33cbb9c3e686e2360ecb67bd5d5eece6975b93fd153fdd52843521d71` |
| `crops/mandioquinha_salsa.json` | `1045bca1dbcb9b45b5c0be21daa5b455a3f4c25956bd9933bc11a3ef08c1075b` |
| `crops/pimenta.json` | `90da06db52310feebff8be00b8fa6d275dcc56af083534fcaf6f4e3acb519fb1` |

## Como verificar

```bash
python3 verify_hashes.py
```

O script confere cada arquivo contra `SHA256SUMS.txt` e imprime o hash agregado, que deve ser igual ao valor acima.
Este arquivo (`HASHES.md`) não entra no cálculo, porque contém o próprio hash.
