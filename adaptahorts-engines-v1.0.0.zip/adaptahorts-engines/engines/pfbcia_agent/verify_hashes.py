#!/usr/bin/env python3
"""
verify_hashes.py — Verifica a integridade do PFBCIA Agent (FAIR / reprodutibilidade)

Recalcula o SHA-256 de cada arquivo listado em SHA256SUMS.txt e o hash
agregado do agente (SHA-256 do próprio SHA256SUMS.txt). Sai com código 1
se qualquer arquivo estiver ausente ou alterado.

Uso:  python3 verify_hashes.py
"""
import hashlib
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    sums = ROOT / "SHA256SUMS.txt"
    bad = 0
    for line in sums.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        digest, rel = line.split("  ", 1)
        p = ROOT / rel
        if not p.is_file():
            print(f"AUSENTE   {rel}"); bad += 1
        elif sha256(p) != digest:
            print(f"ALTERADO  {rel}"); bad += 1
    print(f"Hash agregado do agente (SHA-256 de SHA256SUMS.txt): {sha256(sums)}")
    print("OK — todos os arquivos conferem." if not bad else f"FALHA — {bad} arquivo(s) com problema.")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
