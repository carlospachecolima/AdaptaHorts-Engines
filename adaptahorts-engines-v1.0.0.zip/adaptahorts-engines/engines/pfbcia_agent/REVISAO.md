# Revisão de 15/10/2026 (v0.2 → v0.3): restrição ao escopo climático

Critério adotado: o motor só considera efeitos da temperatura média, mínima e
máxima, da precipitação excessiva e das secas.

## Batata (perfil verificado, revisado)

| Item | v0.2 | v0.3 |
|---|---|---|
| Vocabulário | `calor`, `seca`, `encharcamento`, `desbalanco_hidrico`, `geada_granizo`, `nutricional`, `nao_climatico`, `indeterminado` | os 7 fatores únicos de `climate_drivers.json` |
| rachadura | desbalanço hídrico, calor, seca, nutricional | seca, precipitacao_excessiva, tmax_alta ("período muito quente"), tmed_alta. **Removido:** adubação nitrogenada |
| embonecamento | seca, calor, geada_granizo, nutricional | seca, tmed_alta (temperatura elevada do solo), tmin_baixa (geada). **Removidos:** granizo, nutrição |
| coração-oco | desbalanço hídrico, nutricional | seca, precipitacao_excessiva. **Removidos:** potássio, espaçamento |
| coração-preto | calor, não climático | tmax_alta ("forte calor na fase final da tuberização"). **Removido:** arejamento do armazém |
| unhadura | desbalanço hídrico, não climático | seca, precipitacao_excessiva. **Removidas:** pancadas |
| lenticelose | encharcamento, calor | precipitacao_excessiva, tmed_alta |
| mancha-chocolate | calor, seca | tmed_alta, seca |
| parte aérea sob calor, senescência precoce | calor | tmed_alta. A citação C03 foi ampliada para incluir "sob altas temperaturas" |
| **novo:** crescimento exuberante da parte aérea | — | tmed_alta (C05) e tmin_alta (C09, **inferido**: noites frias favorecem a tuberização) |
| esverdeamento, esfoladura, empedramento | sintomas com classe "não climático" ou "indeterminado" | passam a **diferenciais fora do escopo** |
| Limiares | — | Tméd ótima de 18–22 °C, noites frias e água na tuberização (C01, C02, C09, C10, D02) |
| Manifesto | `estresses_aceitos` | `fatores_aceitos`; a Figura 5 (esverdeamento) passa a esperar `fora_do_escopo` |

Ficaram 39 afirmações, todas verificadas literalmente (eram 36; entraram C09,
C10 e C11).

## Cebola (novo perfil verificado)

As fontes são as páginas da Ageitec *Clima* (Lima & Oliveira, 2022) e
*Desordens fisiológicas* (Oliveira, 2022; só a introdução). O perfil tem 26
afirmações, 9 sintomas, 2 diferenciais e 6 limiares.

| Sintoma | Fator(es) | Limiar ou trecho |
|---|---|---|
| bulbificação precoce | tmax_alta | > 35 °C na fase inicial (K11) |
| florescimento precoce (bolting) | tmed_baixa | 5–13 °C por ≥ 30 dias (K14) |
| pseudocaule grosso / falha no tombamento | tmin_baixa; precipitacao_excessiva | < 6 °C (K13); excesso de água antes da bulbificação (K23) |
| bulbificação deficiente por frio | tmed_baixa | cessa < 10 °C (K12) |
| crescimento foliar paralisado por frio | tmed_baixa; tmin_baixa (**inferido**) | cessa < 6 °C (K09) |
| queima foliar por geada | tmin_baixa | frio muito intenso ou prolongado (K20) |
| crescimento paralisado por seca | seca | veranicos, raiz superficial (K16, K18) |
| dano por encharcamento | precipitacao_excessiva | solo saturado > 12 h (K22) |
| ruptura das películas | precipitacao_excessiva | excesso de água no fim do ciclo (K24); manejo K25 |

Diferenciais fora do escopo: ausência de bulbificação por fotoperíodo e dano
por salinidade.

## Alface e batata-doce (revisados, pendentes de fonte)

- Atribuições não climáticas (por exemplo, deficiência de cálcio como causa)
  removidas. Na alface, o cálcio fica só como mecanismo do tipburn induzido
  pelo calor.
- Cada sintoma passou a ter fatores do vocabulário único, todos marcados como
  `pendente_fonte`.
- Pendoamento da alface por fotoperíodo passou a diferencial.
- O agente funciona com esses perfis, mas a auditoria informa
  `sem_base_verificada` e não traz citações.

## Alface: perfil parcial (atualização de 15/10/2026, 11h)

A fonte incorporada é HENZ, G. P.; SUINAGA, F. *Tipos de alface cultivados no
Brasil*. Embrapa Hortaliças, 2009 (Comunicado Técnico 75). O texto foi extraído
coluna por coluna, porque o PDF tem duas colunas. O perfil tem 11 afirmações,
todas verificadas.

| Sintoma | Fator | Trecho |
|---|---|---|
| pendoamento / florescimento precoce | tmed_alta | A03 ("temperaturas mais elevadas… pendoamento ocorre mais precocemente"), A04 ("regiões quentes") |
| **novo:** plantas menores com ciclo acelerado | tmed_alta | A03 |

- **Diferencial:** pendoamento por dias longos (A04, "ou com dias longos"), por
  ser efeito de fotoperíodo.
- **Manejo citado:**
  - cultivares tropicalizadas resistentes ao pendoamento para as latitudes de
    0° a 23° (A05);
  - mulching para um microclima mais favorável (A07);
  - estruturas tipo "guarda-chuva" com circulação de ar contra chuva
    concentrada e calor excessivo (A08, A09);
  - estruturas que concentram calor no inverno (A10).
- **Limiares:** só qualitativos ("climas amenos"), porque a fonte não dá
  valores.
- **Pendentes de fonte:** tipburn, clorose, necrose, murcha, senescência
  precoce e dossel desigual. O CT 75 não trata desses sintomas.
- **Removido:** a faixa de 17–21 °C do protótipo, que não aparece em S5.
- **Novo status `parcial` no motor:** os sintomas verificados são auditados com
  citação. Os pendentes geram um alerta de "atribuição não auditável".

## Cenoura: novo perfil verificado (atualização de 15/10/2026, 11h10)

As fontes são as páginas da Ageitec *Clima* (Lima, Makishima & Vieira, 2022) e
*Desordens fisiológicas* (Carvalho, Vieira & Silva, 2022). O perfil tem 25
afirmações, todas verificadas.

| Sintoma | Fator(es) | Limiar ou trecho |
|---|---|---|
| raízes curtas e de coloração deficiente | tmed_alta | > 21 °C; ótimo de 10–15 °C (N02) |
| ciclo reduzido, raízes pouco desenvolvidas | tmax_alta; tmed_alta (**inferido**) | > 30 °C, sem estatística especificada (N04) |
| florescimento precoce | tmed_baixa | frio associado a dias > 12 h (N05, R13); o fotoperíodo fica fora do escopo |
| rachadura | seca → precipitacao_excessiva | R03, R04. **Removido:** boro (R07) |
| ombro verde ou roxo | precipitacao_excessiva **ou** fora_do_escopo | chuvas torrenciais expõem a raiz (R10). Sem chuva no contexto, a causa é manejo |
| algodão (aerênquima) | precipitacao_excessiva | solos muito encharcados (R16) |
| falha de germinação | seca; tmax_alta e tmin_baixa (**inferidos**) | germinação entre 8 e 35 °C, ideal 20–30 °C (N06, N07) |

- **Diferencial:** raiz bifurcada (nematoides, insetos, solo pesado ou pedras).
- **Padrão de referência:** 5 figuras do PDF de desordens.
  - Na Figura 2, a legenda "RAIZ BIFURCADA", impressa dentro da foto, foi
    coberta com uma tarja preta para não entregar a resposta ao modelo.
  - A Figura 5 (algodão) tem baixa resolução (227 × 170 px).
- **Novo campo `permite_fora_do_escopo`:** usado em sintomas que podem ter
  causa climática ou de manejo, como o ombro verde ou roxo.

## Alface: perfil verificado completo (atualização de 15/10/2026, 11h20)

| Fonte | Trabalho | Uso no perfil |
|---|---|---|
| S8 | Lima et al. (2024), GRES 2(9) | experimento a 25/20 °C contra 30/25 °C; mecanismo do tipburn; 9 fotos de referência (Figuras 2, 3, 4A–C e 14a–d) |
| S9 | Lima et al. (2025), Cad. Pedagógico 22(11) | faixa de 15–25 °C; tabelas de vulnerabilidade de Tméd e Tmáx; Índice de Severidade Térmica; estratégias de adaptação |
| S10 | Fontenelle et al. (2026), Rev. DCS 23(90) | definições dos 7 sintomas do PFBCIA-alface; escala 1–5 publicada; critérios ρ ≥ 0,85 e MAD ≤ 1,50 |

**Afirmações e sintomas**

- O perfil passou de 11 para 50 afirmações, todas verificadas palavra por
  palavra. Os trechos foram extraídos por âncoras do texto da fonte, e a página
  citada é a página do PDF.
- Os 11 sintomas agora têm fonte. São 7 do PFBCIA-alface mais 4 novos:
  - perda de estande;
  - plantas menores com ciclo acelerado;
  - falha de germinação;
  - crescimento limitado por frio (< 15 °C).
- Há 4 atribuições marcadas como **inferidas**:
  - clorose → seca: a fonte diz que a ligação é "indireta";
  - murcha → tmax_alta e murcha → seca: a fonte fala em "alta transpiração",
    sem citar calor;
  - senescência → tmed_alta.

**Mudanças no motor**

- **Escala:** a escala 1–5 do protótipo foi substituída pela escala publicada
  (P08).
- **Classes de vulnerabilidade:** o motor agora tem um campo
  `classes_vulnerabilidade`. Com `--tmed` e `--tmax`, o agente classifica o
  período pelas Tabelas 2 e 3 de S9 e passa a classe ao modelo.
- **Validação (`validate.py`):**
  - aceita rótulos múltiplos (ex.: "tipburn|clorose");
  - aceita controle negativo (`nenhum`);
  - calcula a MAD da nota;
  - verifica os critérios de aprovação publicados.

**Mapas hídricos**

Os 9 mapas foram guardados em `reference/alface/mapas_hidricos/`, com
metadados, só como contexto. Há três pendências:
- existem duas versões do balanço hídrico da primavera, com faixas
  incompatíveis;
- é preciso confirmar a fórmula do % de atendimento, que chega a −99%;
- falta o texto publicado do método.

## Feijão-caupi: novo perfil verificado (atualização de 15/10/2026, 11h20)

As fontes são as páginas da Ageitec *Clima* (Bastos) e *Sistemas diferenciados
de cultivo* (Cardoso), da Embrapa Meio-Norte, migradas em 2021. O perfil tem 16
afirmações, todas verificadas.

| Sintoma | Fator(es) | Limiar ou trecho |
|---|---|---|
| abortamento de flores | tmax_alta; tmed_alta (**inferido**) | > 34 °C; > 35 °C no florescimento (F09, F10, F11) |
| floração atrasada e ciclo alongado | tmed_baixa | < 18 °C (F08) |
| crescimento vegetativo reduzido | seca | falta de água antes do florescimento (F03) |
| vagens e grãos mal formados | seca | do florescimento ao enchimento, perda de até 80 % (F04) |
| fungos nas vagens | precipitacao_excessiva | chuva na colheita (F05) |

- **Diferencial:** floração atrasada por fotoperíodo, em cultivares de dias
  curtos (F12).
- **Fora do escopo:** o vento (F13) entra só como contexto.
- **Limiares:**
  - temperatura: 18–34 °C;
  - temperatura mínima: 8–11 °C na germinação e 8–10 °C na floração inicial;
  - chuva: pelo menos 300 mm no ciclo.
- **Novo órgão:** `vagem`, incluído no motor.
- **Fotos de referência:** nenhuma, porque as fontes não trazem imagens.

## Batata-doce: perfil verificado (atualização de 15/10/2026, 11h35)

O perfil foi reconstruído do zero a partir de seis fontes. Tem 44 afirmações,
todas verificadas. Os artigos de duas colunas (Abewoy e Zhu) foram extraídos
por coluna.

| Fonte | Trabalho | Uso no perfil |
|---|---|---|
| S14 | Sistema de Produção de Batata-doce (Embrapa Hortaliças, 2021) | ideal 30/20 °C; média ótima de 25,5 °C para a raiz; tabela de partição por temperatura; demanda hídrica e período crítico; encharcamento; chicote; frio; foto de K. Raja Reddy |
| S15 | Fontenelle et al. (2026), edUCA 9 | persona; regra fenológica de 90–100 DAP; atributos visuais; escala 1–5 publicada; mecanismo da rachadura; notas humanas; critérios ρ/MAD |
| S16 | Abewoy (2023) | seca reduz ramas, entrenós e área foliar; o calor agrava a seca |
| S17 | Zhu (2025) | seca na iniciação forma raízes-lápis; perdas de 50–80 % (a salinidade fica fora do escopo) |
| S18 | Melo et al. (2021), BPD 245 | plantio horizontal das ramas e resiliência a altas temperaturas (manejo) |
| S19 | Pedroso & Ferreira (2023), Doc. 197 | contexto da agricultura familiar |

**Sintomas e fatores**

| Sintoma | Fator(es) |
|---|---|
| raiz fina, fibrosa ou lápis | tmed_alta; seca |
| raízes pequenas ou poucas | tmed_alta; seca; precipitacao_excessiva |
| constrições e formato irregular | tmed_alta e seca (**inferidos**) |
| rachadura de crescimento | seca → precipitacao_excessiva |
| raiz "chicote" | precipitacao_excessiva **ou** fora_do_escopo |
| ramas excessivas com poucas raízes | precipitacao_excessiva; tmed_alta |
| apodrecimento em solo encharcado | precipitacao_excessiva |
| ramas curtas por seca | seca |
| crescimento lento por frio | tmed_baixa |
| injúria por frio nas raízes | tmin_baixa |

**Outras mudanças**

- **Diferenciais:** rachadura por nematoide-das-galhas e dano por frio no
  armazenamento.
- **Removido:** a "descoloração da polpa", herdada do protótipo, porque nenhuma
  fonte a sustenta.
- **Escala:** passou a ser a escala 1–5 publicada no PFBCIA–batata-doce.

**Imagens de referência**

- **Conjunto real** (`reference/batata_doce/manifest.csv`):
  - Figura 1 de S14, de K. Raja Reddy: quatro regimes, com a faixa de rótulos de
    temperatura cortada. Os rótulos derivam da Tabela 2: 25/17 e 30/22 °C, sem
    distúrbio; 35/27 °C, raízes pequenas; 40/32 °C, raízes finas.
  - Foto do "chicote".
- **Conjunto sintético** (`reference/batata_doce/sintetico_educa/manifest.csv`):
  as 15 imagens de IA das Figuras 2–5 de S15, com as notas humanas publicadas
  (5, 4, 2, 1 por série e 5, 3, 1 na Figura 5). Os rótulos de temperatura foram
  cortados. As imagens servem só para testar ρ e MAD (E08).

**Mudança em `validate.py`**

- O rótulo `*` marca imagens que só têm nota. Elas ficam fora das métricas de
  defeito.
- O backend mock gera notas próximas às de referência, para testar o caminho
  de ρ e MAD.

## Cebola: complemento com *Desordens fisiológicas – Campo* (atualização de 15/10/2026, 11h40)

A fonte incorporada é a S20 (Oliveira, Ageitec, 2022). O perfil passou de 26
para 42 afirmações, todas verificadas.

**Sintomas que já existiam, agora reforçados**
- **Bulbificação precoce:** passou a citar a consequência, bulbos pequenos (K31,
  K32).
- **Florescimento precoce:** os bulbos de plantas florescidas são descartados
  (K34). Entrou também um manejo novo, evitar o excesso de adubação no início do
  ciclo quando há risco de frio (K35).
- **Pseudocaule grosso e bulbificação deficiente:**
  - plantas que formam só "charutos" (K27);
  - frio abaixo de 10 °C prejudica os bulbos (K28);
  - frio extremo abaixo de 6 °C engrossa o pseudocaule (K29).

**Novidades**
- **Sintoma novo:** bulbos duplos ou múltiplos, causados por excesso de umidade
  no solo (precipitacao_excessiva) **ou** fora do escopo. A fonte também cita o
  excesso de nitrogênio (K37).
- **Diferencial novo:** esverdecimento dos catáfilos, por exposição à luz (K39).
- **Padrão de referência:** 5 fotos de V. R. Oliveira, que são as primeiras da
  cebola. Quatro têm cerca de 226 × 170 px. A Figura 1 aceita três rótulos,
  porque a legenda descreve o pseudocaule grosso junto com a dificuldade de
  bulbificação, e o mesmo quadro pode vir de frio ou de fotoperíodo.

## Pimenta: novo perfil verificado (atualização de 15/10/2026, 11h50)

As fontes são as páginas da Ageitec *Clima* (Lima, Makishima & Ribeiro, 2022) e
*Irrigação* (Marouelli & Silva, 2022). O perfil tem 20 afirmações, todas
verificadas.

| Sintoma | Fator(es) | Limiar ou trecho |
|---|---|---|
| queda de flores e abortamento de frutos | tmax_alta; tmed_baixa; tmin_baixa (**inferido**); seca | > 35 °C com ar seco (G05); < 15 °C (G04); falta de água na floração e no pegamento (I02) |
| frutos pequenos | seca | fase reprodutiva (I07) |
| podridão apical | seca | I07 |
| injúria por frio | tmed_baixa; tmin_baixa | queda de folhas, flores e frutos; partes jovens murchas; crescimento lento (G08); geadas (G01) |
| frutos com coloração e pungência prejudicadas | tmed_baixa | G08 |
| dano por encharcamento | precipitacao_excessiva | solo sem aeração; Phytophthora (I03, I04) |
| falha de germinação | tmin_baixa; tmed_baixa (**inferido**) | solo ≤ 10 °C (G07) |

- **Diferenciais:**
  - estiolamento por falta de luz;
  - doenças que o clima favorece (fitóftora, oídio, antracnose, bacterioses,
    vira-cabeça). O motor não diagnostica a doença em si.
- **Fora do escopo:** a umidade relativa do ar não é um fator do motor. Ela
  entra só como nota, porque modula o efeito do calor: com ar úmido, a
  tolerância vai até 40 °C.
- **Novo órgão:** `fruto`, incluído no motor.
- **Fotos de referência:** nenhuma, porque as fotos da página de irrigação
  mostram equipamentos, não sintomas.

## Últimos materiais (atualização de 15/10/2026, 12h): v0.4.0

**Arquivos repetidos.** Dois arquivos eram idênticos a envios anteriores (mesmo
hash): *Desordens – Campo* (cebola) e o *Sistema de Produção de Batata-doce*.
Nenhum dos dois mudou o pacote.

### Batata: Sistema de Produção da Batata, 2ª ed., 2015 (S23)

O PDF repete o conteúdo várias vezes; usei só o primeiro bloco. O perfil passou
de 39 para 71 afirmações.

- **Limiares refinados:**
  - melhores produções com temperaturas amenas de 15–20 °C;
  - tuberização melhor com médias de 15–18 °C;
  - faixa ótima de 15–22 °C, com a maioria dos resultados entre 10 e 22 °C;
  - temperaturas acima de 25 °C têm prejudicado o cultivo de primavera/verão;
  - necessidade de água de 250–550 mm.
- **Inferências que viraram atribuição direta:**
  - noites acima de 22 °C reduzem significativamente a produção de tubérculos
    (H02), o que torna `tmin_alta` direto;
  - a unhadura passou a ter causa própria, "período seco no final da
    tuberização" (H10).

  Com isso, a batata ficou com **0 atribuições inferidas**.
- **Novos sintomas:**
  - vitiligo, por solo encharcado;
  - apodrecimento de tubérculos em solo encharcado;
  - gelatinizada (jajica), por geada forte no campo.
- **Novos diferenciais:**
  - fitotoxidez por herbicida, que imita embonecamento, clorose e necrose;
  - esfolamento mecânico;
  - sarna-comum, doença favorecida por falta de água no início da tuberização.
- **Fotos:** 16 novas fotos de C. A. Lopes. Conferi por hash perceptual que são
  diferentes das fotos da Ageitec. Entram coração-preto, mancha-chocolate,
  unhadura, vitiligo, despelamento, esfolamento e 4 fotos de herbicida. O
  manifesto da batata passou de 5 para 21 imagens.

### Cenoura: Sistemas de Produção nº 2, 2021 (S24)

O perfil passou de 25 para 38 afirmações.

- **Germinação:** acima de 35 °C ela é praticamente inibida (N10), o que torna
  `tmax_alta` direto na falha de germinação.
- **Faixa após a germinação:** o ótimo é 18–25 °C. Acima de 25 °C, o comprimento
  e a coloração ficam prejudicados. Esse valor diverge do limiar de 21 °C da
  Ageitec, e os dois ficam registrados.
- **Florescimento precoce:** mínimas noturnas de 10 °C ou menos induzem o
  florescimento (N12), com `tmin_baixa` direto.
- **Novo diferencial:** rachadura por deficiência de boro.
- **Fotos:** 8 novas. São florescimento, 3 raízes-padrão de cultivar usadas
  como controle negativo e 4 raízes deformadas por nematoide, que servem de
  diferencial da raiz bifurcada.
- **Distúrbios de pós-colheita:** murchamento, amargor e descoloração oxidativa
  ficaram fora, porque são de armazenamento.

### Mandioquinha-salsa: nova cultura, Sistemas de Produção nº 1, 2021 (S25)

O perfil tem 15 afirmações, 6 sintomas e 0 atribuições inferidas.

| Sintoma | Fator(es) | Trecho |
|---|---|---|
| florescimento precoce ("capitão") | seca; tmin_baixa | "induzido pela seca e pelo frio intenso" (Q06) |
| apodrecimento de mudas e falha de pegamento | tmed_alta; precipitacao_excessiva | "elevadas temperatura e precipitação" (Q08) |
| perda de folhas e falhas por geada | tmin_baixa | Q03 |
| apodrecimento por encharcamento | precipitacao_excessiva | Q09 |
| raízes comerciais reduzidas no sequeiro | seca | Q11 |
| perdas em verões quentes ou invernos frios | tmed_alta; tmed_baixa | Q02 |

- **Limiares:**
  - temperatura média anual de 15–18 °C;
  - extremos no Brasil de 0 a 30 °C, com anos a −5 °C e outros a 32 °C ou mais;
  - aptidão por altitude e UF (Tabela 4);
  - água: 600–1.000 mm.
- **Diferenciais:** raízes arredondadas por solo compactado e pigmentação
  própria de clone.
- **Tabela 6 (doenças):** a extração intercalou as colunas, então não usei a
  tabela como fonte.
- **Foto de referência:** uma (Figura 2, "capitão").

### Atribuições inferidas que ainda precisam de revisão (12 no total)

| Cultura | Atribuições inferidas |
|---|---|
| alface | clorose → seca; murcha → tmax_alta; murcha → seca; senescência → tmed_alta |
| batata-doce | constrições → tmed_alta; constrições → seca |
| cebola | crescimento foliar paralisado → tmin_baixa |
| cenoura | ciclo reduzido → tmed_alta; falha de germinação → tmin_baixa |
| pimenta | queda de flores → tmin_baixa; falha de germinação → tmed_baixa |
| feijão-caupi | abortamento de flores → tmed_alta |
