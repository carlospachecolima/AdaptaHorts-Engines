#!/usr/bin/env python3
"""
PFBCIA Agent — Plataforma de Fenotipagem de Baixo Custo com IA (v0.3)
=====================================================================

Motor único para todas as hortaliças do PFBCIA. Formaliza em código o método
de engenharia e encadeamento de prompts publicado pelo time de Inteligência
Climática da Embrapa Hortaliças (Fontenelle et al., 2026 — batata-doce,
Revista edUCA v.9; alface, Rev. Derecho y Cambio Social v.23(90)).

Escopo climático (v0.3)
-----------------------
O motor só atribui sintomas a cinco fatores, definidos em
climate_drivers.json e alinhados às variáveis do mapeamento AdaptaHorts:
temperatura média, mínima e máxima, precipitação excessiva e seca.
Fotoperíodo, nutrição, salinidade, manejo, colheita e armazenamento ficam
fora do escopo e aparecem só como diagnóstico diferencial
("fora_do_escopo"), para que o agente não atribua ao clima o que a
literatura atribui a outra causa.

Validação da literatura
-----------------------
* Cada cultura é um JSON em crops/. Em perfis "verificado", cada atribuição
  sintoma → fator cita trechos LITERAIS das fontes (conferidos por
  literature_check.py) e é marcada como "direto" ou "inferido".
* A cadeia de prompts restringe o modelo a esse vocabulário e aos limiares
  térmicos e hídricos da literatura.
* literature_audit confere cada resposta do modelo contra a base; a
  recomendação final vem das fontes, com citação.
* validate.py mede o desempenho contra fotos de especialista publicadas
  (bootstrap, 10.000 reamostragens, IC 95%).

Modos de uso
------------
  python3 pfbcia_agent.py --crop batata --context "..." --dry-run
  python3 pfbcia_agent.py --crop batata --image foto.jpg --backend anthropic --out r.json
  python3 pfbcia_agent.py --list-crops
"""

from __future__ import annotations

import argparse
import base64
import json
import mimetypes
import os
import re
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

ROOT = Path(__file__).resolve().parent
CROPS_DIR = ROOT / "crops"
VERSION = "1.0.0"
DRIVERS = json.loads((ROOT / "climate_drivers.json").read_text(encoding="utf-8"))
OUT_OF_SCOPE = DRIVERS["fora_do_escopo"]

ORGAO_LABEL = {
    "tuberculo_externo": "tubérculo — superfície (foto do tubérculo inteiro)",
    "tuberculo_interno": "tubérculo — interior (exige tubérculo CORTADO)",
    "parte_aerea": "parte aérea (folhas e hastes)",
    "planta_inteira": "planta inteira / lavoura",
    "folha": "folhas",
    "bulbo": "bulbo",
    "raiz": "raiz",
    "vagem": "vagens e grãos",
    "fruto": "frutos",
}


# ---------------------------------------------------------------------------
# Perfis de cultura
# ---------------------------------------------------------------------------

@dataclass
class CropProfile:
    data: dict

    @property
    def key(self) -> str: return self.data["key"]
    @property
    def display_name(self) -> str: return self.data["display_name"]
    @property
    def module(self) -> str: return self.data.get("module", "fenotipagem")
    @property
    def status(self) -> str: return self.data.get("status_literatura", "pendente_fonte")
    @property
    def verified(self) -> bool: return self.status in ("verificado", "parcial")
    @property
    def symptoms(self) -> list[dict]: return self.data.get("symptoms", [])
    @property
    def differentials(self) -> list[dict]: return self.data.get("diferenciais", [])
    @property
    def claims(self) -> dict: return self.data.get("claims", {})
    @property
    def sources(self) -> dict: return self.data.get("sources", {})

    def symptom(self, sid: str) -> dict | None:
        return next((s for s in self.symptoms if s["id"] == sid), None)

    def differential(self, sid: str) -> dict | None:
        return next((d for d in self.differentials if d["id"] == sid), None)

    def allowed_drivers(self, sid: str) -> list[str]:
        s = self.symptom(sid)
        if s:
            drv = [f["fator"] for f in s.get("fatores", [])]
            return drv + [OUT_OF_SCOPE] if s.get("permite_fora_do_escopo") else drv
        return [OUT_OF_SCOPE] if self.differential(sid) else []

    def score_text(self) -> str:
        sc = self.data.get("score_scale", {})
        return sc["texto"] if isinstance(sc, dict) else str(sc)

    # -- cadeia de prompts ---------------------------------------------------
    def build_chain(self, context: str) -> list[str]:
        def line(s, extra=""):
            t = f"- {s['id']}: {s.get('nome', s['id'])}"
            if s.get("visual"):
                t += f" — {s['visual']}"
            if s.get("orgao"):
                t += f" [órgão: {ORGAO_LABEL.get(s['orgao'], s['orgao'])}]"
            return t + extra
        checklist = "\n".join(line(s) for s in self.symptoms)
        diffs = "\n".join(line(d, f" (causa: {d.get('causa', '?')})") for d in self.differentials)
        ids = ", ".join(s["id"] for s in self.symptoms)
        dids = ", ".join(d["id"] for d in self.differentials)
        drivers = "\n".join(f"- {k}: {v['variavel']} — {v['sentido']}" for k, v in DRIVERS["fatores"].items())
        table = "\n".join(
            f"- {s['id']}: {', '.join(self.allowed_drivers(s['id']))}"
            + (" (atribuição ainda sem fonte verificada)" if s.get("status_evidencia") == "pendente_fonte" else "")
            for s in self.symptoms)
        limiares = "\n".join(f"- {l['fator']}: {l['descricao']}" for l in self.data.get("limiares", []))

        chain = [
            # 1. Persona, protocolo e escopo
            f"Você é {self.data['persona']}. Vamos avaliar, passo a passo, uma amostra de "
            f"{self.display_name} a partir da fotografia anexada, seguindo um protocolo de "
            "fenotipagem visual baseado em literatura técnica publicada. ESCOPO: este protocolo "
            "considera apenas efeitos da temperatura média, mínima e máxima, da precipitação "
            "excessiva e das secas. Não atribua causas fora desse escopo e não use conhecimento "
            "fora do protocolo. Responda em português, de forma objetiva e técnica.",

            # 2. Contexto, limiares e tipo de imagem
            f"Contexto informado pelo produtor ou pesquisador: \"{context.strip() or 'não informado'}\". "
            f"Referência agronômica: {self.data.get('phenology_note', '')}"
            + (f"\nLimiares climáticos da literatura para esta cultura:\n{limiares}" if limiares else "")
            + "\nResponda em duas linhas: (a) o que o contexto (inclusive dados de temperatura ou "
            "chuva, se houver) implica frente aos limiares; (b) o que a imagem mostra — escolha UM: "
            "tuberculo_inteiro, tuberculo_cortado, bulbo, raiz, vagem, fruto, folha, parte_aerea, planta_inteira, outro.",

            # 3. Checklist restrito
            "Examine a imagem e classifique CADA item como presente, ausente ou nao_avaliavel "
            "(nao_avaliavel quando o órgão necessário não está visível). Formato: "
            "'id: status — justificativa curta'. Use apenas estes ids.\n"
            f"Sintomas de estresse climático:\n{checklist}"
            + (f"\nDiagnósticos diferenciais FORA do escopo climático (marque se a imagem for "
               f"melhor explicada por eles):\n{diffs}" if diffs else ""),

            # 4. Diagnóstico diferencial + atribuição restrita
            "Diagnóstico. Escolha o defeito_principal: um id presente (sintoma ou diferencial) ou "
            "'nenhum'. Atribua então de 1 a 2 fatores climáticos, escolhendo SOMENTE entre os que a "
            "literatura associa a esse sintoma (tabela) e usando o contexto e os limiares para "
            f"desempatar. Se o defeito principal for um diferencial, responda ['{OUT_OF_SCOPE}'] — "
            "não atribua ao clima o que a literatura atribui a outra causa.\n"
            f"Sintoma → fatores aceitos pela literatura:\n{table}\n"
            f"Definição dos fatores:\n{drivers}",

            # 5. Nota
            f"Com base apenas nos sintomas presentes, atribua uma nota nesta escala: "
            f"{self.score_text()}. Responda com o número e uma frase de justificativa.",

            # 6. Síntese
            "Redija uma síntese ecofisiológica de até 120 palavras explicando como o(s) fator(es) "
            "climático(s) atribuído(s) produz(em) o sintoma observado, e uma recomendação prática de "
            "adaptação para o(a) agricultor(a) familiar.",

            # 7. JSON final
            "Consolide tudo em um único bloco JSON, SEM texto fora do JSON, com exatamente estas chaves: "
            '"tipo_imagem" (string), '
            f'"sintomas" (lista de ids presentes, entre: {ids}{", " + dids if dids else ""}), '
            '"nao_avaliaveis" (lista de ids), '
            '"defeito_principal" (id ou "nenhum"), '
            f'"fatores_climaticos" (lista com 1–2 fatores, ["{OUT_OF_SCOPE}"] ou []), '
            '"confianca" ("alta", "media" ou "baixa"), '
            '"nota" (inteiro 1–5), "sintese" (string), "recomendacao" (string).',
        ]
        return chain


def classify_vulnerability(profile: "CropProfile", tmed: float | None, tmax: float | None) -> dict | None:
    """Classes de vulnerabilidade térmica publicadas para a cultura (se houver)."""
    cv = profile.data.get("classes_vulnerabilidade")
    if not cv or (tmed is None and tmax is None):
        return None
    def cls(v, table):
        for lo, hi, name in table:
            if (lo is None or v > lo) and (hi is None or v <= hi):
                return name
        return None
    out = {"fonte": [ _cite(profile, c) for c in cv.get("fonte", []) ]}
    if tmed is not None and "tmed" in cv:
        out["tmed"] = {"valor": tmed, "classe": cls(tmed, cv["tmed"])}
    if tmax is not None and "tmax" in cv:
        out["tmax"] = {"valor": tmax, "classe": cls(tmax, cv["tmax"])}
    return out


def vulnerability_text(v: dict | None) -> str:
    if not v:
        return ""
    parts = [f"{k.upper()} = {v[k]['valor']} °C → vulnerabilidade {v[k]['classe']}" for k in ("tmed", "tmax") if k in v]
    return " [Classificação térmica publicada para a cultura: " + "; ".join(parts) + ".]"


def load_profiles(directory: Path = CROPS_DIR) -> dict[str, CropProfile]:
    profiles = {}
    for f in sorted(directory.glob("*.json")):
        d = json.loads(f.read_text(encoding="utf-8"))
        profiles[d["key"]] = CropProfile(d)
    return profiles


# ---------------------------------------------------------------------------
# Imagem
# ---------------------------------------------------------------------------

def load_image_b64(path: Path) -> tuple[str, str]:
    if not path.exists():
        raise FileNotFoundError(f"Imagem não encontrada: {path}")
    mime, _ = mimetypes.guess_type(str(path))
    if mime is None or not mime.startswith("image/"):
        raise ValueError(f"Tipo de imagem não reconhecido para {path} ({mime!r}). Use .jpg, .png ou .webp.")
    data = path.read_bytes()
    if len(data) > 15 * 1024 * 1024:
        raise ValueError("Imagem maior que 15 MB — reduza antes de enviar.")
    return base64.b64encode(data).decode("ascii"), mime


# ---------------------------------------------------------------------------
# Backends (importação tardia)
# ---------------------------------------------------------------------------

class BackendError(RuntimeError):
    pass


Runner = Callable[[list[str], str, str, str], list[dict]]


def run_chain_anthropic(chain, image_b64, mime, model):
    try:
        import anthropic
    except ImportError as e:
        raise BackendError("Biblioteca 'anthropic' não instalada: pip install anthropic") from e
    if not os.environ.get("ANTHROPIC_API_KEY"):
        raise BackendError("Defina ANTHROPIC_API_KEY.")
    client = anthropic.Anthropic()
    messages, transcript = [], []
    for i, prompt in enumerate(chain):
        content = []
        if i == 0:
            content.append({"type": "image", "source": {"type": "base64", "media_type": mime, "data": image_b64}})
        content.append({"type": "text", "text": prompt})
        messages.append({"role": "user", "content": content})
        resp = client.messages.create(model=model, max_tokens=1500, messages=messages)
        text = "".join(b.text for b in resp.content if getattr(b, "type", "") == "text")
        messages.append({"role": "assistant", "content": text})
        transcript.append({"step": i + 1, "prompt": prompt, "response": text})
    return transcript


def run_chain_openai(chain, image_b64, mime, model):
    try:
        from openai import OpenAI
    except ImportError as e:
        raise BackendError("Biblioteca 'openai' não instalada: pip install openai") from e
    if not os.environ.get("OPENAI_API_KEY"):
        raise BackendError("Defina OPENAI_API_KEY.")
    client = OpenAI()
    messages, transcript = [], []
    for i, prompt in enumerate(chain):
        content: list[dict] = [{"type": "text", "text": prompt}]
        if i == 0:
            content.insert(0, {"type": "image_url", "image_url": {"url": f"data:{mime};base64,{image_b64}"}})
        messages.append({"role": "user", "content": content})
        resp = client.chat.completions.create(model=model, messages=messages)
        text = resp.choices[0].message.content or ""
        messages.append({"role": "assistant", "content": text})
        transcript.append({"step": i + 1, "prompt": prompt, "response": text})
    return transcript


def run_chain_gemini(chain, image_b64, mime, model):
    try:
        import google.generativeai as genai
    except ImportError as e:
        raise BackendError("Biblioteca 'google-generativeai' não instalada: pip install google-generativeai") from e
    if not os.environ.get("GEMINI_API_KEY"):
        raise BackendError("Defina GEMINI_API_KEY.")
    genai.configure(api_key=os.environ["GEMINI_API_KEY"])
    chat = genai.GenerativeModel(model).start_chat(history=[])
    image_part = {"mime_type": mime, "data": base64.b64decode(image_b64)}
    transcript = []
    for i, prompt in enumerate(chain):
        resp = chat.send_message([image_part, prompt] if i == 0 else [prompt])
        transcript.append({"step": i + 1, "prompt": prompt, "response": resp.text})
    return transcript


BACKENDS: dict[str, tuple[Runner, str]] = {
    "anthropic": (run_chain_anthropic, "claude-sonnet-5-5"),
    "openai": (run_chain_openai, "gpt-4o"),
    "gemini": (run_chain_gemini, "gemini-2.0-flash"),
}


# ---------------------------------------------------------------------------
# Relatório final e auditoria de literatura
# ---------------------------------------------------------------------------

def extract_final_report(transcript: list[dict]) -> dict:
    last = transcript[-1]["response"]
    m = re.search(r"\{.*\}", last, re.S)
    if m:
        try:
            return json.loads(m.group(0))
        except json.JSONDecodeError:
            pass
    return {"sintomas": [], "nota": None, "sintese": last.strip(), "recomendacao": "",
            "_aviso": "JSON final não interpretável; revise o texto bruto em 'sintese'."}


def _cite(profile: CropProfile, cid: str) -> dict:
    c = profile.claims[cid]
    return {"id": cid, "fonte": c["source"], "pagina": c.get("page"), "trecho": c["quote"]}


def _normalize_drivers(report: dict) -> list[str]:
    f = report.get("fatores_climaticos")
    if f is None and report.get("estresse_climatico"):  # compatibilidade v0.2
        f = [report["estresse_climatico"]]
    if isinstance(f, str):
        f = [f]
    return [x for x in (f or []) if isinstance(x, str) and x != "nenhum"]


def literature_audit(profile: CropProfile, report: dict) -> dict:
    """Confere o diagnóstico do modelo contra a base de evidências e o escopo climático."""
    flags: list[str] = []
    vocab = set(DRIVERS["fatores"]) | {OUT_OF_SCOPE}
    drivers = _normalize_drivers(report)
    report["fatores_climaticos"] = drivers

    out_scope = [d for d in drivers if d not in vocab]
    if out_scope:
        flags.append(f"Fatores fora do escopo climático do motor descartados: {out_scope}")
    drivers = [d for d in drivers if d in vocab]

    known = {s["id"] for s in profile.symptoms} | {d["id"] for d in profile.differentials}
    present = [s for s in (report.get("sintomas") or []) if isinstance(s, str)]
    unknown = [s for s in present if s not in known]
    if unknown:
        flags.append(f"Sintomas fora do vocabulário descartados: {unknown}")
    present = [s for s in present if s in known]

    main = report.get("defeito_principal") or "nenhum"
    if main != "nenhum" and main not in present:
        flags.append(f"defeito_principal '{main}' não consta entre os sintomas presentes.")

    allowed: set[str] = set()
    for sid in ([main] if main in known else present):
        allowed.update(profile.allowed_drivers(sid))
    drivers_ok = None
    if drivers:
        bad = [d for d in drivers if allowed and d not in allowed]
        if bad:
            flags.append(f"Atribuição {bad} SEM respaldo na literatura para '{main}' (aceitos: {sorted(allowed)}).")
        drivers_ok = not bad
    elif main != "nenhum":
        flags.append("Nenhum fator climático atribuído ao defeito principal.")

    tipo = (report.get("tipo_imagem") or "").lower()
    for sid in present:
        s = profile.symptom(sid) or profile.differential(sid)
        if s.get("orgao") == "tuberculo_interno" and tipo and "cortado" not in tipo:
            flags.append(f"'{sid}' é defeito interno, mas a imagem foi classificada como '{tipo}'.")

    if not profile.verified:
        return {"status": "sem_base_verificada", "alertas": flags,
                "atribuicao_respaldada": drivers_ok,
                "motivo": "Perfil ainda sem trechos de fonte verificados; checagens de escopo e "
                          "vocabulário aplicadas, mas sem citações."}

    evid, manejo, risco, ligacoes = [], [], [], []
    for sid in present:
        s = profile.symptom(sid) or profile.differential(sid)
        evid += [{"sintoma": sid, **_cite(profile, c)} for c in s.get("evidencias", [])]
        manejo += [c for c in s.get("manejo", []) if c not in manejo]
        if s.get("risco_consumo"):
            risco.append({"sintoma": sid, **_cite(profile, s["risco_consumo"])})
    main_sym = profile.symptom(main)
    if main_sym and main_sym.get("status_evidencia") == "pendente_fonte":
        flags.append(f"'{main}' ainda não tem fonte verificada; atribuição não auditável.")
    if main_sym:
        for f in main_sym.get("fatores", []):
            if f["fator"] in drivers:
                ligacoes.append({"fator": f["fator"], "tipo": f["tipo"], "nota": f.get("nota"),
                                 "trechos": [_cite(profile, c) for c in f["claims"]]})
    limiares = [l for l in profile.data.get("limiares", []) if l["fator"] in drivers]

    return {
        "status": "consistente" if not flags else "com_alertas",
        "alertas": flags,
        "atribuicao_respaldada": drivers_ok,
        "fatores_aceitos_para_o_defeito": sorted(allowed),
        "base_da_atribuicao": ligacoes,
        "limiares_relevantes": [{"fator": l["fator"], "descricao": l["descricao"],
                                 "trechos": [_cite(profile, c) for c in l["claims"]]} for l in limiares],
        "recomendacoes_da_literatura": [_cite(profile, c) for c in manejo],
        "riscos_ao_consumo": risco,
        "evidencias": evid,
        "fontes": {k: v["citation"] + " " + v["url"] for k, v in profile.sources.items()},
    }


def build_adaptahorts_submission(profile, context, report, audit, backend_label) -> dict:
    metrics = []
    if report.get("nota") is not None:
        metrics.append({"k": "nota (1–5)", "v": str(report["nota"])})
    if report.get("defeito_principal"):
        metrics.append({"k": "defeito principal", "v": report["defeito_principal"]})
    if report.get("fatores_climaticos"):
        metrics.append({"k": "fatores climáticos", "v": ", ".join(report["fatores_climaticos"])})
    metrics.append({"k": "auditoria de literatura", "v": audit.get("status", "")})
    metrics.append({"k": "modelo utilizado", "v": backend_label})

    summary = report.get("sintese") or ""
    lit = audit.get("recomendacoes_da_literatura") or []
    if lit:
        summary += " Manejo (literatura): " + " ".join(f"{c['trecho']} [{c['fonte']}]." for c in lit)
    return {
        "title": f"Fenotipagem assistida por IA — {profile.display_name}",
        "authors": "(preencher — pesquisador(a) responsável pela amostra)",
        "venue": f"AdaptaHorts — contribuição via PFBCIA Agent v{VERSION}",
        "module": profile.module,
        "doi": "",
        "summary": summary.strip()[:900],
        "metrics": metrics,
        "references": list((audit.get("fontes") or {}).values()),
    }


def diagnose(profile: CropProfile, image: Path, context: str, runner: Runner, model: str,
             backend_label: str, tmed: float | None = None, tmax: float | None = None) -> dict:
    """Executa a cadeia completa para uma imagem e devolve o payload final."""
    vuln = classify_vulnerability(profile, tmed, tmax)
    context = context + vulnerability_text(vuln)
    chain = profile.build_chain(context)
    image_b64, mime = load_image_b64(image)
    transcript = runner(chain, image_b64, mime, model)
    report = extract_final_report(transcript)
    audit = literature_audit(profile, report)
    return {
        "agent_version": VERSION,
        "crop": profile.key,
        "image": str(image),
        "context": context,
        "backend": backend_label,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "chain_transcript": transcript,
        "diagnosis": report,
        "vulnerabilidade_termica": vuln,
        "literature_audit": audit,
        "adaptahorts_submission": build_adaptahorts_submission(profile, context, report, audit, backend_label),
    }


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> int:
    profiles = load_profiles()
    ap = argparse.ArgumentParser(description="PFBCIA Agent — fenotipagem por IA generativa com auditoria de literatura.")
    ap.add_argument("--crop", choices=sorted(profiles))
    ap.add_argument("--image", type=Path)
    ap.add_argument("--context", default="")
    ap.add_argument("--backend", choices=sorted(BACKENDS))
    ap.add_argument("--model")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--out", type=Path)
    ap.add_argument("--tmed", type=float, help="Temperatura média do período (°C), opcional.")
    ap.add_argument("--tmax", type=float, help="Temperatura máxima do período (°C), opcional.")
    ap.add_argument("--list-crops", action="store_true")
    a = ap.parse_args(argv)

    if a.list_crops:
        for k, p in profiles.items():
            print(f"{k:20s} {p.status:12s} {len(p.symptoms):2d} sintomas  {len(p.differentials)} diferenciais")
        return 0
    if not a.crop:
        ap.error("--crop é obrigatório.")
    profile = profiles[a.crop]

    if a.dry_run or a.backend is None:
        _emit({
            "agent_version": VERSION, "crop": profile.key, "context": a.context,
            "literature_status": profile.status,
            "note": "Modo --dry-run: cole estes prompts, em ordem, numa conversa com uma IA "
                    "multimodal, anexando a foto no primeiro turno.",
            "vulnerabilidade_termica": classify_vulnerability(profile, a.tmed, a.tmax),
            "prompt_chain": profile.build_chain(a.context + vulnerability_text(classify_vulnerability(profile, a.tmed, a.tmax))),
        }, a.out)
        return 0

    if a.image is None:
        ap.error("--image é obrigatório quando um --backend é usado.")
    runner, default_model = BACKENDS[a.backend]
    model = a.model or default_model
    try:
        payload = diagnose(profile, a.image, a.context, runner, model, f"{a.backend}:{model}", a.tmed, a.tmax)
    except (BackendError, FileNotFoundError, ValueError) as e:
        print(f"Erro: {e}", file=sys.stderr)
        return 1
    _emit(payload, a.out)
    return 0


def _emit(payload: dict, out: Path | None) -> None:
    text = json.dumps(payload, ensure_ascii=False, indent=2)
    if out:
        out.write_text(text, encoding="utf-8")
        print(f"Resultado salvo em {out}", file=sys.stderr)
    else:
        print(text)


if __name__ == "__main__":
    raise SystemExit(main())
