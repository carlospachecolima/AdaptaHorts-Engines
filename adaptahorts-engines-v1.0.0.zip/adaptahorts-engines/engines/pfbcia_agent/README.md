# PFBCIA Agent v1.0.0: motor único de fenotipagem climática para hortaliças

Este é um motor único para todas as hortaliças do PFBCIA: cada cultura é um
arquivo JSON em `crops/`, e o código é o mesmo para todas. O motor formaliza o
método de engenharia e encadeamento de prompts dos artigos PFBCIA (Fontenelle et
al., 2026) e acrescenta validação da literatura, sem painel humano.

## Escopo climático

O motor só atribui sintomas a fatores climáticos definidos em
`climate_drivers.json`, e esse vocabulário é o mesmo para todas as culturas:

| Fator | Variável | WorldClim / AdaptaHorts |
|---|---|---|
| `tmed_alta`, `tmed_baixa` | temperatura média | BIO1 / tavg |
| `tmax_alta` | temperatura máxima | BIO5 / tmax |
| `tmin_alta`, `tmin_baixa` | temperatura mínima (noites quentes; frio intenso, geada) | BIO6 / tmin |
| `precipitacao_excessiva` | chuvas intensas ou prolongadas, solo encharcado | prec |
| `seca` | veranicos, déficit hídrico | prec |

Algumas causas ficam fora do escopo: fotoperíodo, nutrição, salinidade, manejo,
colheita, armazenamento e granizo. Elas entram apenas como diagnóstico
diferencial (`fora_do_escopo`). Assim, quando a imagem mostra um defeito de
outra origem (por exemplo, batata esverdeada pela luz), o agente reconhece o
defeito, mas não o atribui ao clima.

## Validação em três camadas

1. **Literatura → base de conhecimento** (`literature_check.py`). O verificador
   confere três coisas:
   - todo trecho citado existe palavra por palavra na fonte;
   - toda atribuição sintoma → fator cita pelo menos um trecho verificado;
   - todo fator pertence ao escopo climático.

   Cada atribuição é marcada como `direto` ou `inferido`.
2. **Literatura → diagnóstico** (`literature_audit`). O modelo só pode escolher
   fatores que a literatura associa ao sintoma. A auditoria sinaliza:
   - fator fora do escopo;
   - atribuição sem respaldo;
   - defeito interno marcado em foto inteira.

   O relatório devolve os trechos que sustentam a atribuição, os limiares
   relevantes e o manejo citado nas fontes.
3. **Fotos de especialista → desempenho** (`validate.py`). O script calcula
   acurácia, κ de Cohen, acurácia do fator climático e ρ de Spearman da nota,
   com bootstrap de 10.000 reamostragens (IC 95%, reamostragem por imagem) e
   repetibilidade entre réplicas.

## Culturas

São 8 culturas, todas com base verificada. No total, o pacote tem 296
afirmações conferidas palavra por palavra, 69 sintomas e 19 diferenciais.

| Cultura | Afirmações | Sintomas | Diferenciais | Fotos reais | Atribuições inferidas | Fontes |
|---|---|---|---|---|---|---|
| batata | 71 | 13 | 6 | 21 | 0 | Ageitec *Clima* e *Defeitos fisiológicos* (2022); Sistema de Produção da Batata (2015) |
| alface | 50 | 11 | 1 | 9 (+ 9 mapas hídricos) | 4 | CT 75 (2009); Lima et al. (2024, GRES); Lima et al. (2025, Cad. Pedagógico); Fontenelle et al. (2026, Rev. DCS) |
| batata_doce | 44 | 10 | 2 | 5 (+ 15 sintéticas com nota humana) | 2 | Sistema de Produção (2021); Fontenelle et al. (2026, edUCA); Abewoy (2023); Zhu (2025); BPD 245; Doc. 197 |
| cebola | 42 | 10 | 3 | 5 | 1 | Ageitec *Clima*, *Desordens fisiológicas* e *Desordens – Campo* (2022) |
| cenoura | 38 | 7 | 2 | 13 | 2 | Ageitec *Clima* e *Desordens fisiológicas* (2022); Sistemas de Produção nº 2 (2021) |
| pimenta | 20 | 7 | 2 | 0 | 2 | Ageitec *Clima* e *Irrigação* (2022) |
| feijao_caupi | 16 | 5 | 1 | 0 | 1 | Ageitec/Embrapa Meio-Norte *Clima* e *Sistemas diferenciados de cultivo* (2021) |
| mandioquinha_salsa | 15 | 6 | 2 | 1 | 0 | Sistemas de Produção nº 1 (2021) |

O detalhe das mudanças está em `REVISAO.md`.

## Uso

```bash
python3 literature_check.py                      # valida todas as bases (exit 1 se reprovar)
python3 pfbcia_agent.py --list-crops
python3 pfbcia_agent.py --crop cebola --context "Tmín 4 °C por 3 noites, julho" --dry-run

export ANTHROPIC_API_KEY=...                     # ou OPENAI_API_KEY / GEMINI_API_KEY
python3 pfbcia_agent.py --crop batata --image foto.jpg --backend anthropic --out r.json
python3 pfbcia_agent.py --crop alface --image foto.jpg --tmed 31 --tmax 36 --backend anthropic   # classes de vulnerabilidade publicadas
python3 validate.py --crop batata --backend anthropic --replicates 3 \
        --results-dir resultados/batata --out validacao_batata
python3 validate.py --crop batata --backend mock     # testa só o pipeline
python3 validate.py --crop batata_doce --manifest reference/batata_doce/sintetico_educa/manifest.csv --backend anthropic --replicates 3   # reproduz a validação de notas do artigo
```

## Como adicionar uma hortaliça

1. Coloque o texto de cada fonte em `literature/texts/` e registre-o em `sources`.
2. Em `claims`, transcreva os trechos literais com a página.
3. Em `symptoms`, preencha para cada sintoma:
   - descrição visual e órgão;
   - `fatores` (somente do vocabulário), cada um com `claims` e `tipo`;
   - `evidencias` e `manejo`.
4. Em `diferenciais`, registre o que a fonte atribui a causas não climáticas.
5. Em `limiares`, registre os valores de temperatura e chuva citados.
6. Rode `literature_check.py --crop <cultura>` até o perfil ser aprovado.
7. Coloque as fotos de especialista em `reference/<cultura>/`, preencha o
   `manifest.csv` e rode `validate.py`.

## Limitações

- **Tamanho dos conjuntos de referência:** com 0 a 21 fotos por cultura, os ICs
  do bootstrap ficam largos. Os números atuais testam o protocolo, não medem
  desempenho. A meta é de pelo menos 10 fotos legendadas por classe.
- **Culturas sem foto ou com uma só:** pimenta e feijão-caupi não têm nenhuma.
  A mandioquinha-salsa tem uma (o "capitão", com 203 × 188 px).
- **Fotos de baixa resolução:** quatro fotos da cebola e uma da cenoura (o
  algodão) têm cerca de 220 × 170 px.
- **Controles negativos:** fotos sem distúrbio existem para alface (25/20 °C),
  batata-doce (25/17 e 30/22 °C) e cenoura (padrões de cultivar).
- **Diferenciais visualmente parecidos:** as fotos de fitotoxidez por herbicida
  e de nematoide (batata e cenoura) testam se o agente evita atribuir ao clima o
  que tem outra causa.
- **Atribuições inferidas:** são 12 no total, listadas por cultura em
  `REVISAO.md`, e merecem revisão de especialista.
- **Estatística térmica não especificada:** quando a fonte não diz se o valor é
  média, mínima ou máxima, "altas temperaturas" foi lido como `tmed_alta`, e
  "forte calor" ou "muito quente" como `tmax_alta`.
- **Limiares divergentes:** algumas fontes dão valores diferentes para o mesmo
  efeito. Os dois valores ficam registrados, como na cenoura (> 21 °C contra
  > 25 °C) e na batata (faixas de 15–20, 15–22 e 18–22 °C).
- **Escala de notas:** alface e batata-doce usam escalas publicadas. Nas demais
  culturas, os níveis 2 a 4 são uma proposta operacional.
- **Fotos da Embrapa:** são usadas como padrão interno. Verifique a licença antes
  de publicar o pacote.
