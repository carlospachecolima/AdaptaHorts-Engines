#!/usr/bin/env python3
"""
validate.py — Validação do PFBCIA Agent contra fotos de especialista publicadas
===============================================================================

Método (sem painel humano): as figuras publicadas em fontes técnicas, com
legenda dada pelo especialista, são o padrão de referência. O agente
diagnostica cada imagem sem ver a legenda; as concordâncias são medidas e
os intervalos de confiança são estimados por bootstrap não paramétrico
(padrão: 10.000 reamostragens, IC 95% por percentis).

Métricas
  - acuracia_defeito      defeito_principal == rótulo do especialista
  - deteccao_defeito      rótulo do especialista está entre os sintomas marcados
  - kappa_cohen_defeito   concordância corrigida pelo acaso (defeito principal)
  - acuracia_fator        todos os fatores climáticos atribuídos ∈ fatores que a
                          literatura aceita para o defeito de referência
                          (ou "fora_do_escopo" para diferenciais)
  - auditoria_consistente fração de diagnósticos sem alertas na auditoria
  - mad_nota              desvio absoluto médio entre nota do agente e do especialista
  - spearman_nota         ρ entre nota do agente e nota do especialista (se a
                          coluna nota_especialista estiver preenchida)

Com --replicates k, cada imagem é diagnosticada k vezes (os modelos são
estocásticos); o bootstrap reamostra IMAGENS (cluster), mantendo juntas
as réplicas de cada uma, e também se reporta a repetibilidade.

Uso
  python3 validate.py --crop batata --backend anthropic --replicates 3
  python3 validate.py --crop batata --backend mock          # teste do pipeline
  python3 validate.py --crop batata --from-results resultados/   # reaproveita JSONs
"""

from __future__ import annotations

import argparse
import csv
import json
import random
import statistics
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import pfbcia_agent as agent

ROOT = Path(__file__).resolve().parent


# ---------------------------------------------------------------------------
# Métricas
# ---------------------------------------------------------------------------

def cohen_kappa(y_true: list[str], y_pred: list[str]) -> float | None:
    n = len(y_true)
    if n == 0:
        return None
    po = sum(a == b for a, b in zip(y_true, y_pred)) / n
    ct, cp = Counter(y_true), Counter(y_pred)
    pe = sum(ct[k] * cp.get(k, 0) for k in ct) / (n * n)
    if pe == 1:
        return 1.0 if po == 1 else None
    return (po - pe) / (1 - pe)


def spearman(x: list[float], y: list[float]) -> float | None:
    if len(x) < 3:
        return None
    def ranks(v):
        order = sorted(range(len(v)), key=lambda i: v[i])
        r = [0.0] * len(v)
        i = 0
        while i < len(v):
            j = i
            while j + 1 < len(v) and v[order[j + 1]] == v[order[i]]:
                j += 1
            for k in range(i, j + 1):
                r[order[k]] = (i + j) / 2 + 1
            i = j + 1
        return r
    rx, ry = ranks(x), ranks(y)
    if statistics.pstdev(rx) == 0 or statistics.pstdev(ry) == 0:
        return None
    return statistics.correlation(rx, ry)


def compute(rows: list[dict]) -> dict:
    """rows: uma linha por diagnóstico (imagem × réplica)."""
    all_rows = rows
    # rótulo "*": imagem só com nota de especialista — fica fora das métricas de defeito/fator
    rows = [r for r in rows if r["refs"] != ["*"]]
    if not rows:
        out = {k: None for k in ("acuracia_defeito", "deteccao_defeito", "kappa_cohen_defeito",
                                  "acuracia_fator", "auditoria_consistente")}
        rows = []
    # rótulos múltiplos aceitos ("tipburn|clorose"); o primeiro é o principal para o kappa
    yt = [r["refs"][0] for r in rows]
    yp = [r["refs"][0] if r["pred"] in r["refs"] else r["pred"] for r in rows]

    def detect(r):
        if r["refs"] == ["nenhum"]:
            return not [s for s in r["sintomas"] if s != "nenhum"]
        return any(x in r["sintomas"] for x in r["refs"])

    def fator_ok(r):
        if not r["aceitos"]:          # referência sem distúrbio: nenhum fator deve ser atribuído
            return not r["fatores"]
        return bool(r["fatores"]) and all(f in r["aceitos"] for f in r["fatores"])

    if rows:
      out = {
        "acuracia_defeito": sum(r["pred"] in r["refs"] for r in rows) / len(rows),
        "deteccao_defeito": sum(detect(r) for r in rows) / len(rows),
        "kappa_cohen_defeito": cohen_kappa(yt, yp),
        "acuracia_fator": sum(fator_ok(r) for r in rows) / len(rows),
        "auditoria_consistente": sum(r["audit"] == "consistente" for r in rows) / len(rows),
      }
    rows = all_rows
    pairs = [(r["nota"], r["nota_ref"]) for r in rows
             if isinstance(r.get("nota"), (int, float)) and r.get("nota_ref") is not None]
    out["spearman_nota"] = spearman([p[0] for p in pairs], [p[1] for p in pairs]) if pairs else None
    out["mad_nota"] = (sum(abs(p[0] - p[1]) for p in pairs) / len(pairs)) if pairs else None
    return out


def bootstrap(rows: list[dict], iterations: int, seed: int, alpha: float = 0.05) -> dict:
    rng = random.Random(seed)
    by_img: dict[str, list[dict]] = {}
    for r in rows:
        by_img.setdefault(r["imagem"], []).append(r)
    imgs = list(by_img)
    samples: dict[str, list[float]] = {}
    for _ in range(iterations):
        draw = [r for img in rng.choices(imgs, k=len(imgs)) for r in by_img[img]]
        for k, v in compute(draw).items():
            if v is not None:
                samples.setdefault(k, []).append(v)
    ci = {}
    for k, vals in samples.items():
        vals.sort()
        lo = vals[int((alpha / 2) * len(vals))]
        hi = vals[min(len(vals) - 1, int((1 - alpha / 2) * len(vals)))]
        ci[k] = {"ic95": [round(lo, 3), round(hi, 3)], "reamostras_validas": len(vals)}
    return ci


# ---------------------------------------------------------------------------
# Execução
# ---------------------------------------------------------------------------

def read_manifest(path: Path) -> list[dict]:
    with path.open(encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        r["fatores_aceitos"] = [s for s in r["fatores_aceitos"].split("|") if s]
        r["nota_especialista"] = float(r["nota_especialista"]) if r.get("nota_especialista") else None
    return rows


def make_mock_runner(truth: dict, profile: agent.CropProfile, error_rate: float, rng: random.Random):
    """Backend simulado para testar o pipeline (NÃO é validação do modelo)."""
    ids = [s["id"] for s in profile.symptoms] + [d["id"] for d in profile.differentials]
    def runner(chain, image_b64, mime, model):
        label, accepted = truth["label"].split("|")[0], truth["accepted"]
        if label == "*":
            label = rng.choice(ids); accepted = profile.allowed_drivers(label)
        if rng.random() < error_rate:
            label = rng.choice([i for i in ids if i != label])
            accepted = profile.allowed_drivers(label)
        s = profile.symptom(label) or profile.differential(label) or {}
        orgao = s.get("orgao", "")
        if label == "nenhum":
            final = {"tipo_imagem": "planta_inteira", "sintomas": [], "nao_avaliaveis": [],
                     "defeito_principal": "nenhum", "fatores_climaticos": [], "confianca": "media",
                     "nota": int(truth["nota"]) if truth.get("nota") is not None else 5,
                     "sintese": "(mock)", "recomendacao": "(mock)"}
            return [{"step": i + 1, "prompt": p, "response": "(mock)"} for i, p in enumerate(chain[:-1])] + \
                   [{"step": len(chain), "prompt": chain[-1], "response": json.dumps(final, ensure_ascii=False)}]
        final = {
            "tipo_imagem": "tuberculo_cortado" if orgao == "tuberculo_interno" else "tuberculo_inteiro",
            "sintomas": [label], "nao_avaliaveis": [], "defeito_principal": label,
            "fatores_climaticos": accepted[:1], "confianca": "media",
            "nota": (max(1, min(5, int(truth["nota"]) + rng.choice([-1, 0, 0, 1])))
                     if truth.get("nota") is not None else rng.randint(1, 4)),
            "sintese": "(mock)", "recomendacao": "(mock)",
        }
        return [{"step": i + 1, "prompt": p, "response": "(mock)"} for i, p in enumerate(chain[:-1])] + \
               [{"step": len(chain), "prompt": chain[-1], "response": json.dumps(final, ensure_ascii=False)}]
    return runner


def to_row(item: dict, payload: dict, rep: int) -> dict:
    d = payload["diagnosis"]
    return {
        "imagem": item["imagem"], "replica": rep,
        "ref": item["rotulo_especialista"], "refs": item["rotulo_especialista"].split("|"),
        "aceitos": item["fatores_aceitos"],
        "nota_ref": item["nota_especialista"],
        "pred": d.get("defeito_principal") or "nenhum",
        "sintomas": d.get("sintomas") or [],
        "fatores": d.get("fatores_climaticos") or [],
        "nota": d.get("nota"),
        "audit": payload["literature_audit"].get("status"),
        "alertas": payload["literature_audit"].get("alertas", []),
    }


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Validação do PFBCIA Agent contra fotos de especialista.")
    ap.add_argument("--crop", required=True)
    ap.add_argument("--manifest", type=Path, help="Padrão: reference/<crop>/manifest.csv")
    ap.add_argument("--backend", choices=sorted(agent.BACKENDS) + ["mock"])
    ap.add_argument("--model")
    ap.add_argument("--replicates", type=int, default=1)
    ap.add_argument("--iterations", type=int, default=10_000)
    ap.add_argument("--seed", type=int, default=20261015)
    ap.add_argument("--mock-error-rate", type=float, default=0.0)
    ap.add_argument("--results-dir", type=Path, help="Salva (ou, com --from-results, lê) um JSON por diagnóstico.")
    ap.add_argument("--from-results", action="store_true")
    ap.add_argument("--out", type=Path, help="Prefixo dos relatórios (.json e .md).")
    a = ap.parse_args(argv)

    profile = agent.load_profiles()[a.crop]
    manifest = a.manifest or ROOT / "reference" / a.crop / "manifest.csv"
    if not manifest.is_file() or not (items := read_manifest(manifest)):
        print(f"Sem imagens de referência para '{a.crop}' ({manifest}). Adicione fotos legendadas "
              "por especialistas e preencha o manifest.csv.", file=sys.stderr)
        return 2
    img_dir = manifest.parent
    rng = random.Random(a.seed)
    if a.results_dir:
        a.results_dir.mkdir(parents=True, exist_ok=True)

    rows = []
    for item in items:
        for rep in range(1, a.replicates + 1):
            cache = a.results_dir / f"{Path(item['imagem']).stem}_r{rep}.json" if a.results_dir else None
            if a.from_results:
                payload = json.loads(cache.read_text(encoding="utf-8"))
            else:
                if a.backend == "mock":
                    runner, model = make_mock_runner(
                        {"label": item["rotulo_especialista"], "accepted": item["fatores_aceitos"],
                         "nota": item["nota_especialista"]},
                        profile, a.mock_error_rate, rng), "mock"
                elif a.backend:
                    runner, default = agent.BACKENDS[a.backend]
                    model = a.model or default
                else:
                    ap.error("Informe --backend ou --from-results.")
                payload = agent.diagnose(profile, img_dir / item["imagem"], item.get("contexto", ""),
                                         runner, model, f"{a.backend}:{model}")
                if cache:
                    cache.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            rows.append(to_row(item, payload, rep))
            print(f"  {item['imagem']:28s} r{rep}  ref={rows[-1]['ref']:14s} pred={rows[-1]['pred']:14s} "
                  f"fatores={','.join(rows[-1]['fatores']) or '-':28s} auditoria={rows[-1]['audit']}", file=sys.stderr)

    point = compute(rows)
    ci = bootstrap(rows, a.iterations, a.seed)
    repet = None
    if a.replicates > 1:
        by = {}
        for r in rows:
            by.setdefault(r["imagem"], []).append(r["pred"])
        repet = sum(Counter(v).most_common(1)[0][1] / len(v) for v in by.values()) / len(by)

    n_img = len(items)
    result = {
        "crop": a.crop, "agent_version": agent.VERSION,
        "backend": a.backend or "from-results", "model": a.model,
        "gerado_em": datetime.now(timezone.utc).isoformat(),
        "padrao_referencia": str(manifest.relative_to(ROOT)) if manifest.is_relative_to(ROOT) else str(manifest),
        "n_imagens": n_img, "replicas": a.replicates,
        "bootstrap": {"iteracoes": a.iterations, "semente": a.seed, "metodo": "percentil, reamostragem por imagem"},
        "metricas": {k: {"estimativa": None if v is None else round(v, 3), **ci.get(k, {})} for k, v in point.items()},
        "repetibilidade_defeito": None if repet is None else round(repet, 3),
        "aviso_tamanho_amostral": (
            f"Apenas {n_img} imagens de referência: os ICs são largos e servem como teste do "
            "protocolo, não como evidência de desempenho. Amplie o manifesto com mais fotos "
            "legendadas por especialistas (alvo: ≥ 10 por classe de defeito)."
        ) if n_img < 30 else None,
        "criterios_aprovacao": {
            "spearman_nota_min": 0.85, "mad_nota_max": 1.50,
            "fonte": "Limiares de Fontenelle et al. (2025a), conforme relatados em Fontenelle et al. (2026), "
                     "Rev. Derecho y Cambio Social 23(90), p. 18 (alface, P09) e Fontenelle et al. (2026), Rev. edUCA 9, e370 (batata-doce, E12).",
            "atendidos": (None if point.get("spearman_nota") is None else
                          bool(point["spearman_nota"] >= 0.85 and point["mad_nota"] <= 1.50)),
        },
        "diagnosticos": rows,
    }
    if a.backend == "mock":
        result["aviso_mock"] = "Backend simulado — estes números testam o pipeline, não o modelo."

    md = render_md(result, profile)
    if a.out:
        a.out.with_suffix(".json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        a.out.with_suffix(".md").write_text(md, encoding="utf-8")
        print(f"Relatórios: {a.out.with_suffix('.json')} e {a.out.with_suffix('.md')}", file=sys.stderr)
    print(md)
    return 0


def render_md(r: dict, profile) -> str:
    L = [f"# Validação PFBCIA — {profile.display_name}", "",
         f"Agente v{r['agent_version']} · backend `{r['backend']}` · {r['n_imagens']} imagens × "
         f"{r['replicas']} réplica(s) · bootstrap {r['bootstrap']['iteracoes']} iterações (IC 95%)", ""]
    if r.get("aviso_mock"):
        L += [f"> **{r['aviso_mock']}**", ""]
    if r.get("aviso_tamanho_amostral"):
        L += [f"> {r['aviso_tamanho_amostral']}", ""]
    L += ["| Métrica | Estimativa | IC 95% |", "|---|---|---|"]
    for k, v in r["metricas"].items():
        est = "—" if v["estimativa"] is None else f"{v['estimativa']:.3f}"
        ic = f"{v['ic95'][0]:.3f} – {v['ic95'][1]:.3f}" if "ic95" in v else "—"
        L.append(f"| {k} | {est} | {ic} |")
    c = r.get("criterios_aprovacao") or {}
    if c:
        st = "sem notas de especialista no manifesto" if c.get("atendidos") is None else ("ATENDIDOS" if c["atendidos"] else "NÃO atendidos")
        L += ["", f"Critérios de aprovação (ρ ≥ {c['spearman_nota_min']} e MAD ≤ {c['mad_nota_max']}): {st}. Fonte: {c['fonte']}"]
    if r.get("repetibilidade_defeito") is not None:
        L += ["", f"Repetibilidade do defeito principal entre réplicas: {r['repetibilidade_defeito']:.3f}"]
    L += ["", "| Imagem | Réplica | Especialista | Agente | Fatores climáticos | Auditoria |", "|---|---|---|---|---|---|"]
    for d in r["diagnosticos"]:
        L.append(f"| {d['imagem']} | {d['replica']} | {d['ref']} | {d['pred']} | {', '.join(d['fatores'])} | {d['audit']} |")
    return "\n".join(L) + "\n"


if __name__ == "__main__":
    raise SystemExit(main())
