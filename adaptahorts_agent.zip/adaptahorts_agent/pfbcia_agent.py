#!/usr/bin/env python3
"""
PFBCIA Agent — Plataforma de Fenotipagem de Baixo Custo com IA (protótipo)
============================================================================

Formaliza, como uma ferramenta reutilizável de linha de comando, o método de
"engenharia e encadeamento de prompts" (prompt engineering / prompt chaining)
já validado e publicado pelo time de Inteligência Climática da Embrapa
Hortaliças:

  - Fontenelle, M.R. et al. (2026). PFBCIA – Sweet Potato: Low-Cost
    AI-Powered Phenotyping Platform from Prompt Engineering to Climate
    Justice: Thermal Stress. Revista edUCA, v.9.
  - Fontenelle, M.R. et al. (2026). Low-Cost Lettuce Phenotyping Platforms
    Powered by Generative AI. Revista de Derecho y Cambio Social, v.23(90).

A ideia é a mesma dos dois papers: uma pessoa envia uma foto de uma planta
(hoje: alface ou batata-doce) sob possível estresse térmico/hídrico, mais um
punhado de metadados mínimos (idade da cultura, cor de polpa, condição de
cultivo), e um modelo de IA generativa multimodal percorre uma cadeia de
prompts especializados — persona, contexto fenológico, classificação de
sintomas, nota de tolerância térmica (1 a 5) e síntese ecofisiológica — até
produzir um relatório estruturado.

Este script NÃO substitui o julgamento humano nem foi validado
estatisticamente por si só (essa validação, com correlação de Spearman e
Desvio Absoluto Médio frente a especialistas, é o que os papers acima
reportam para o método em si). Ele formaliza o MESMO método em código,
para que deixe de depender de copiar e colar prompts manualmente a cada
novo caso.

MODOS DE USO
------------
1) --dry-run (não precisa de nenhuma chave de API nem biblioteca externa):
   gera e imprime/salva a cadeia de prompts exatamente como seria enviada,
   para quem preferir colar manualmente no ChatGPT, Gemini ou Claude.

2) --backend anthropic|openai|gemini (precisa da respectiva biblioteca e de
   uma chave de API no ambiente): executa a cadeia de fato, turno a turno,
   contra o modelo escolhido, e produz um relatório estruturado em JSON.

Em qualquer um dos dois modos, o resultado final inclui um bloco
"adaptahorts_submission" já formatado nos campos do formulário de
contribuição do AdaptaHorts (título, resumo, métricas) — pronto para colar
lá, ou para uma futura integração automática.

Princípios FAIR: este script é feito para ser versionado e depositado (ex.:
Zenodo), como os demais scripts do grupo, e para ser lido e adaptado por
outras pessoas — não só executado.
"""

from __future__ import annotations

import argparse
import base64
import json
import mimetypes
import os
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


# ---------------------------------------------------------------------------
# Perfis de cultura: cada um encapsula o conhecimento agronômico específico
# que os papers publicados usam para instruir o modelo de IA.
# ---------------------------------------------------------------------------

@dataclass
class CropProfile:
    key: str
    display_name: str
    module: str  # etapa do pipeline do AdaptaHorts
    persona: str
    phenology_note: str
    symptom_checklist: list[str]
    score_scale: str
    chain_steps: list[str] = field(default_factory=list)

    def build_chain(self, context: str) -> list[str]:
        """Monta a cadeia de prompts (prompt chaining) para esta cultura."""
        symptoms = "; ".join(self.symptom_checklist)
        return [
            # 1. Persona
            (
                f"Você é {self.persona}. Vamos avaliar, passo a passo, uma "
                f"planta de {self.display_name} a partir de uma fotografia, "
                "seguindo um protocolo estruturado de fenotipagem visual. "
                "Responda sempre em português, de forma objetiva e técnica."
            ),
            # 2. Contexto fenológico / condição de cultivo
            (
                "Contexto fornecido pelo produtor ou pesquisador sobre esta "
                f"amostra: \"{context.strip() or 'não informado'}\". "
                f"Observação agronômica relevante para esta cultura: "
                f"{self.phenology_note} "
                "Antes de prosseguir, resuma em uma frase o que esse "
                "contexto implica para a interpretação da imagem."
            ),
            # 3. Classificação visual de sintomas
            (
                "Agora examine a imagem anexada e classifique a presença ou "
                "ausência de cada um destes sinais, com uma justificativa "
                f"curta para cada um: {symptoms}. "
                "Liste sua resposta em formato 'sintoma: presente/ausente — "
                "justificativa'."
            ),
            # 4. Nota / ranking
            (
                "Com base exclusivamente nos sintomas identificados acima, "
                f"atribua uma nota nesta escala: {self.score_scale}. "
                "Responda apenas com o número da nota e uma frase de "
                "justificativa direta."
            ),
            # 5. Síntese ecofisiológica
            (
                "Redija uma síntese ecofisiológica de até 120 palavras "
                "explicando o provável mecanismo de estresse por trás dos "
                "sintomas observados (ex.: regulação osmótica, estresse "
                "oxidativo, força de dreno, balanço hormonal), e uma "
                "recomendação prática de manejo para mitigar o problema."
            ),
            # 6. Relatório estruturado final
            (
                "Por fim, consolide tudo isso em um único bloco JSON, "
                "SEM nenhum texto fora do JSON, com exatamente estas "
                'chaves: "sintomas" (lista de strings), "nota" (inteiro), '
                '"sintese" (string) e "recomendacao" (string).'
            ),
        ]


CROP_PROFILES: dict[str, CropProfile] = {
    "alface": CropProfile(
        key="alface",
        display_name="alface (Lactuca sativa)",
        module="fenotipagem",
        persona=(
            "uma engenheira agrônoma com doutorado em fisiologia de estresse "
            "térmico em hortaliças, especialista em alface"
        ),
        phenology_note=(
            "Sob temperaturas acima do intervalo ideal de 17–21°C, cultivares "
            "não tropicalizadas tendem a apresentar pendoamento precoce, "
            "queima-de-bordas (tipburn) associada a deficiência de cálcio, "
            "clorose e necrose foliar generalizada."
        ),
        symptom_checklist=[
            "tipburn (queima-de-bordas)",
            "clorose",
            "necrose",
            "murcha",
            "senescência precoce",
            "pendoamento (bolting)",
            "desenvolvimento desigual do dossel",
        ],
        score_scale=(
            "1 = estresse severo / rejeição comercial; 2 = estresse "
            "moderado a severo; 3 = estresse moderado, com deficit de "
            "qualidade comercial; 4 = bom, sintomas leves; 5 = excelente "
            "termotolerância aparente"
        ),
    ),
    "batata_doce": CropProfile(
        key="batata_doce",
        display_name="batata-doce (Ipomoea batatas), raiz tuberosa",
        module="fenotipagem",
        persona=(
            "um engenheiro agrônomo com doutorado em ecofisiologia de "
            "raízes e tubérculos, especialista em batata-doce"
        ),
        phenology_note=(
            "O enchimento das raízes tuberosas ocorre tipicamente antes de "
            "90–100 dias após o plantio (DAP); sob estresse térmico severo, "
            "espera-se deficit crônico de força de dreno, raízes finas, "
            "fibrosas ou de formato cordiforme, com baixo acúmulo de amido."
        ),
        symptom_checklist=[
            "raiz fina/fibrosa (stringy)",
            "formato cordiforme irregular",
            "rachaduras",
            "descoloração da polpa",
            "baixo calibre comercial",
            "sinais de deficit hídrico associado",
        ],
        score_scale=(
            "1 = rejeição comercial; 2 = deficit crônico de força de dreno; "
            "3 = moderado; 4 = bom; 5 = excelente, calibre e formato "
            "comerciais"
        ),
    ),
}


# ---------------------------------------------------------------------------
# Utilidades de imagem
# ---------------------------------------------------------------------------

def load_image_b64(path: Path) -> tuple[str, str]:
    """Retorna (base64, mime_type) para o arquivo de imagem informado."""
    if not path.exists():
        raise FileNotFoundError(f"Imagem não encontrada: {path}")
    mime, _ = mimetypes.guess_type(str(path))
    if mime is None or not mime.startswith("image/"):
        raise ValueError(
            f"Não foi possível determinar um tipo de imagem válido para "
            f"{path} (mime detectado: {mime!r}). Use .jpg, .jpeg, .png ou .webp."
        )
    data = path.read_bytes()
    if len(data) > 15 * 1024 * 1024:
        raise ValueError("Imagem maior que 15 MB — reduza antes de enviar.")
    return base64.b64encode(data).decode("ascii"), mime


# ---------------------------------------------------------------------------
# Backends de IA generativa (importação tardia — cada um só é exigido se
# de fato selecionado via --backend).
# ---------------------------------------------------------------------------

class BackendError(RuntimeError):
    pass


def run_chain_anthropic(chain: list[str], image_b64: str, mime: str, model: str) -> list[dict]:
    try:
        import anthropic
    except ImportError as e:
        raise BackendError(
            "Biblioteca 'anthropic' não instalada. Rode: pip install anthropic"
        ) from e
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        raise BackendError("Defina a variável de ambiente ANTHROPIC_API_KEY.")

    client = anthropic.Anthropic(api_key=api_key)
    messages: list[dict] = []
    transcript = []
    for i, prompt in enumerate(chain):
        content: list[dict] = []
        if i == 0:
            content.append(
                {
                    "type": "image",
                    "source": {"type": "base64", "media_type": mime, "data": image_b64},
                }
            )
        content.append({"type": "text", "text": prompt})
        messages.append({"role": "user", "content": content})
        resp = client.messages.create(
            model=model, max_tokens=1024, messages=messages
        )
        text = "".join(b.text for b in resp.content if getattr(b, "type", "") == "text")
        messages.append({"role": "assistant", "content": text})
        transcript.append({"step": i + 1, "prompt": prompt, "response": text})
    return transcript


def run_chain_openai(chain: list[str], image_b64: str, mime: str, model: str) -> list[dict]:
    try:
        from openai import OpenAI
    except ImportError as e:
        raise BackendError(
            "Biblioteca 'openai' não instalada. Rode: pip install openai"
        ) from e
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        raise BackendError("Defina a variável de ambiente OPENAI_API_KEY.")

    client = OpenAI(api_key=api_key)
    messages: list[dict] = []
    transcript = []
    for i, prompt in enumerate(chain):
        content: list[dict] = [{"type": "text", "text": prompt}]
        if i == 0:
            content.insert(
                0,
                {
                    "type": "image_url",
                    "image_url": {"url": f"data:{mime};base64,{image_b64}"},
                },
            )
        messages.append({"role": "user", "content": content})
        resp = client.chat.completions.create(model=model, messages=messages)
        text = resp.choices[0].message.content or ""
        messages.append({"role": "assistant", "content": text})
        transcript.append({"step": i + 1, "prompt": prompt, "response": text})
    return transcript


def run_chain_gemini(chain: list[str], image_b64: str, mime: str, model: str) -> list[dict]:
    try:
        import google.generativeai as genai
    except ImportError as e:
        raise BackendError(
            "Biblioteca 'google-generativeai' não instalada. "
            "Rode: pip install google-generativeai"
        ) from e
    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        raise BackendError("Defina a variável de ambiente GEMINI_API_KEY.")

    genai.configure(api_key=api_key)
    gmodel = genai.GenerativeModel(model)
    chat = gmodel.start_chat(history=[])
    image_part = {"mime_type": mime, "data": base64.b64decode(image_b64)}
    transcript = []
    for i, prompt in enumerate(chain):
        parts: list[Any] = [image_part, prompt] if i == 0 else [prompt]
        resp = chat.send_message(parts)
        text = resp.text
        transcript.append({"step": i + 1, "prompt": prompt, "response": text})
    return transcript


BACKENDS = {
    "anthropic": (run_chain_anthropic, "claude-sonnet-4-5"),
    "openai": (run_chain_openai, "gpt-4o"),
    "gemini": (run_chain_gemini, "gemini-2.0-flash"),
}


# ---------------------------------------------------------------------------
# Extração do relatório final + empacotamento para o AdaptaHorts
# ---------------------------------------------------------------------------

def extract_final_report(transcript: list[dict]) -> dict:
    """Tenta parsear o bloco JSON produzido no último passo da cadeia."""
    last = transcript[-1]["response"].strip()
    # Alguns modelos ainda envolvem o JSON em ```json ... ``` — removemos.
    if last.startswith("```"):
        last = last.strip("`")
        if last.lower().startswith("json"):
            last = last[4:]
    try:
        return json.loads(last)
    except json.JSONDecodeError:
        return {
            "sintomas": [],
            "nota": None,
            "sintese": last,
            "recomendacao": "",
            "_aviso": "Não foi possível interpretar o JSON final automaticamente; "
                       "revise o texto bruto em 'sintese'.",
        }


def build_adaptahorts_submission(
    crop: CropProfile, context: str, report: dict, backend_label: str
) -> dict:
    nota = report.get("nota")
    sintomas = report.get("sintomas") or []
    metrics = []
    if nota is not None:
        metrics.append({"k": "nota de termotolerância (1–5)", "v": str(nota)})
    metrics.append({"k": "sintomas identificados", "v": str(len(sintomas))})
    metrics.append({"k": "modelo utilizado", "v": backend_label})

    title = f"Fenotipagem assistida por IA — {crop.display_name}"
    summary = report.get("sintese") or ""
    if report.get("recomendacao"):
        summary = f"{summary} Recomendação: {report['recomendacao']}"

    return {
        "title": title,
        "authors": "(preencher — pesquisador(a) responsável pela amostra)",
        "venue": "AdaptaHorts — contribuição via PFBCIA Agent",
        "module": crop.module,
        "doi": "",
        "summary": summary.strip()[:600],
        "metrics": metrics,
    }


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description=(
            "PFBCIA Agent — formaliza o método de fenotipagem por IA "
            "generativa (Fontenelle et al., 2026) em uma ferramenta de "
            "linha de comando, com saída pronta para o AdaptaHorts."
        )
    )
    parser.add_argument(
        "--crop", choices=sorted(CROP_PROFILES), required=True,
        help="Cultura a avaliar.",
    )
    parser.add_argument(
        "--image", type=Path, required=False,
        help="Caminho da fotografia (obrigatório fora do modo --dry-run).",
    )
    parser.add_argument(
        "--context", type=str, default="",
        help="Contexto da amostra (idade da planta, condição de cultivo, etc.).",
    )
    parser.add_argument(
        "--backend", choices=sorted(BACKENDS), default=None,
        help="Motor de IA a usar. Omitido junto com --dry-run apenas exporta os prompts.",
    )
    parser.add_argument(
        "--model", type=str, default=None,
        help="Sobrescreve o modelo padrão do backend escolhido.",
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Não chama nenhuma API — apenas gera e exibe a cadeia de prompts.",
    )
    parser.add_argument(
        "--out", type=Path, default=None,
        help="Caminho do arquivo JSON de saída (padrão: imprime no terminal).",
    )
    args = parser.parse_args(argv)

    crop = CROP_PROFILES[args.crop]
    chain = crop.build_chain(args.context)

    if args.dry_run or args.backend is None:
        payload = {
            "crop": crop.key,
            "context": args.context,
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "note": (
                "Modo --dry-run: nenhuma chamada de IA foi feita. Cole estes "
                "prompts, em ordem, numa conversa com o ChatGPT, Gemini ou "
                "Claude, anexando a foto no primeiro turno."
            ),
            "prompt_chain": chain,
        }
        _emit(payload, args.out)
        return 0

    if args.image is None:
        parser.error("--image é obrigatório quando um --backend é usado.")

    try:
        image_b64, mime = load_image_b64(args.image)
        runner, default_model = BACKENDS[args.backend]
        model = args.model or default_model
        transcript = runner(chain, image_b64, mime, model)
    except (BackendError, FileNotFoundError, ValueError) as e:
        print(f"Erro: {e}", file=sys.stderr)
        return 1

    report = extract_final_report(transcript)
    submission = build_adaptahorts_submission(crop, args.context, report, f"{args.backend}:{model}")

    payload = {
        "crop": crop.key,
        "context": args.context,
        "backend": args.backend,
        "model": model,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "chain_transcript": transcript,
        "diagnosis": report,
        "adaptahorts_submission": submission,
    }
    _emit(payload, args.out)
    return 0


def _emit(payload: dict, out: Path | None) -> None:
    text = json.dumps(payload, ensure_ascii=False, indent=2)
    if out:
        out.write_text(text, encoding="utf-8")
        print(f"Resultado salvo em {out}", file=sys.stderr)
    else:
        print(text)


if __name__ == "__main__":
    raise SystemExit(main())
