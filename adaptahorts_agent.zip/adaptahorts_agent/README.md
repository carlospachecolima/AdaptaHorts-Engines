# PFBCIA Agent (protótipo)

Ferramenta de linha de comando que formaliza, em código, o método de
**engenharia e encadeamento de prompts** já publicado pelo time de
Inteligência Climática da Embrapa Hortaliças para fenotipagem assistida
por IA:

- Fontenelle, M.R. et al. (2026). *PFBCIA – Sweet Potato: Low-Cost
  AI-Powered Phenotyping Platform from Prompt Engineering to Climate
  Justice: Thermal Stress.* Revista edUCA, v.9.
- Fontenelle, M.R. et al. (2026). *Low-Cost Lettuce Phenotyping Platforms
  Powered by Generative AI.* Revista de Derecho y Cambio Social, v.23(90).

Hoje cobre **alface** e **batata-doce** (os dois casos já validados nos
papers, com correlação de Spearman acima de 0,85 frente a especialistas
humanos). Adicionar uma nova cultura é criar um novo `CropProfile` em
`pfbcia_agent.py` — não é preciso mexer no resto do código.

## Por que isso existe

O AdaptaHorts (a plataforma web) descreve esse método nos resumos dos dois
artigos, mas hoje ele só existe como um processo manual: alguém copia os
prompts do artigo e cola, um por um, numa conversa com o ChatGPT ou o
Gemini. Este script faz exatamente essa cadeia de prompts, só que de forma
reprodutível e com uma saída já pronta para virar uma contribuição no
AdaptaHorts.

## Uso rápido — sem nenhuma chave de API

```bash
python3 pfbcia_agent.py --crop alface \
  --context "45 dias após transplantio, cultivo protegido, onda de calor" \
  --dry-run
```

Isso imprime a cadeia de 5–6 prompts pronta para colar manualmente numa
conversa com qualquer IA generativa multimodal (anexando a foto no
primeiro turno). Nenhuma biblioteca externa é necessária para este modo.

## Uso completo — chamando a IA de fato

Requer a biblioteca do backend escolhido e uma chave de API definida como
variável de ambiente:

```bash
pip install anthropic        # ou: openai / google-generativeai
export ANTHROPIC_API_KEY=...  # ou OPENAI_API_KEY / GEMINI_API_KEY

python3 pfbcia_agent.py \
  --crop batata_doce \
  --image foto_raiz.jpg \
  --context "95 DAP, polpa laranja, cultivo sequeiro" \
  --backend anthropic \
  --out resultado.json
```

O `resultado.json` traz:

- `chain_transcript`: cada prompt enviado e a resposta correspondente (a
  trilha de auditoria completa da cadeia);
- `diagnosis`: os sintomas identificados, a nota de 1 a 5, a síntese
  ecofisiológica e a recomendação de manejo;
- `adaptahorts_submission`: os mesmos campos já formatados como título,
  módulo do pipeline, resumo e métricas — no formato que o formulário de
  contribuição do AdaptaHorts espera.

## Limitações conhecidas (protótipo)

- Não foi validado estatisticamente por si só — a validação (ρ de Spearman,
  MAD) é a que os papers acima já reportam para o método; este script
  apenas o executa de forma automatizada.
- Não envia a contribuição para o AdaptaHorts automaticamente — hoje é um
  passo manual (copiar o bloco `adaptahorts_submission` para o formulário).
  Automatizar esse último passo depende de uma API de submissão própria,
  o que está descrito na nota técnica de hospedagem institucional.
- Cobre só alface e batata-doce por enquanto.
