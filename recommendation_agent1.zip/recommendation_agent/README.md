# Recommendation Agent (protótipo)

Terceiro motor da mesma família do **PFBCIA Agent** (fenotipagem) e do
**AIGIS Agent** (mapeamento de cenários climáticos), formalizando em código
a etapa 5 do pipeline do AdaptaHorts — **"Proposição Automatizada de
Sistemas Resilientes"** — hoje descrita na plataforma como roteiro futuro:
"IA + modelos + dados + conhecimento local, gerando recomendações de
sistemas produtivos adaptados a cada território."

## O que ele faz

Recebe uma ou mais **condições de risco** (temperatura extrema/alta,
escassez hídrica extrema/alta, excesso de chuva — e outras que você queira
adicionar) e devolve as **práticas agrícolas recomendadas**, priorizadas
pelo número de riscos simultâneos que cada prática ajuda a mitigar. Isso
torna explícito, por exemplo, por que o SPDH/NTVF e os Sistemas
Agroflorestais aparecem em quase todas as combinações: são práticas de
"benefício múltiplo".

## Regras-base (fornecidas)

| Condição de risco | Práticas recomendadas |
|---|---|
| Temperatura extrema | Cultivo em ambiente controlado |
| Temperatura alta | SPDH/NTVF, Bioinsumos, SAF |
| Escassez hídrica extrema | Cultivo hidropônico, Reúso de água |
| Escassez hídrica alta | Cultivo hidropônico, Reúso de água, Irrigação por gotejamento, Manejo de irrigação, SPDH/NTVF, Mulching plástico, SAF |
| Excesso de chuva | SPDH/NTVF, SAF, Cultivo em ambiente protegido |

## Condições e práticas sugeridas por este agente

Como pedido, acrescentei um segundo conjunto — **claramente marcado como
sugestão** (`suggested=True` em cada `RiskCondition`/`Practice`, e
visível no campo `derivation_hint`/`evidence` de cada uma) — por analogia
com riscos já mencionados nos artigos e na própria página do AdaptaHorts:

| Condição sugerida | Práticas sugeridas | Por quê |
|---|---|---|
| Geada / frio extremo | Cultivo em ambiente protegido, Cultivares tolerantes ao frio, Mulching plástico | Simetria com o risco de calor extremo; regiões serranas do estudo de severidade térmica da alface também sofrem com frio. |
| Salinização do solo/água | Reúso de água, Manejo de drenagem e salinidade, SAF | O próprio artigo-guarda-chuva do AdaptaHorts cita intrusão salina na foz do Baixo São Francisco como fonte de escassez hídrica *qualitativa*. |
| Pragas/doenças favorecidas por calor e umidade | Manejo integrado de pragas, Bioinsumos, SAF | O artigo de severidade térmica da alface cita a faixa de 22-26°C + CO2 elevado favorecendo *Allophoma tropica*. |
| Degradação / erosão do solo | SPDH/NTVF, SAF, Adubação orgânica/verde | Consequência natural de excesso de chuva + solo descoberto; já mitigada pelas mesmas práticas de plantio direto. |
| Baixa fertilidade do solo | Bioinsumos, Adubação orgânica/verde, SAF | Reduz a resiliência da cultura a outros estresses; prática recorrente na literatura agroecológica. |

Use `--core-only` em qualquer comando para ignorar essas sugestões e
trabalhar só com as cinco regras originais. Edite os dicionários
`CONDITIONS`, `PRACTICES`, `CORE_RULES` e `SUGGESTED_RULES` em
`recommendation_agent.py` para adicionar, remover ou corrigir qualquer
entrada — nenhuma regra está "escondida" no código.

## Uso rápido

```bash
# Ver todas as condições e práticas conhecidas
python3 recommendation_agent.py list

# Recomendar práticas para um território com dois riscos simultâneos
python3 recommendation_agent.py recommend \
  --conditions temperatura_alta escassez_hidrica_alta \
  --territory "Baixo São Francisco (SE-AL)"

# Mesma coisa, mas usando só as 5 regras originais (sem as sugestões)
python3 recommendation_agent.py recommend \
  --conditions temperatura_alta escassez_hidrica_alta --core-only

# Com contexto completo: localização, cultura(s), fase fenológica e período
python3 recommendation_agent.py recommend \
  --conditions temperatura_alta escassez_hidrica_alta \
  --territory "Baixo São Francisco (SE-AL)" \
  --lat -9.62 --lon -37.15 \
  --crops alface batata-doce \
  --phenological-stage floracao \
  --period longo_prazo
```

## Contexto da consulta: localização, cultura, fase fenológica e período

`--lat`/`--lon`, `--crops`, `--phenological-stage` (`implantacao`,
`vegetativo`, `floracao`, `frutificacao_enchimento`,
`colheita_pos_colheita`) e `--period` (`presente`, `curto_prazo` até 2040,
`medio_prazo` 2041–2070, `longo_prazo` 2071–2100) são aceitos em `recommend`
e em `from-indicators`, e entram no título/resumo/métricas do bloco
`adaptahorts_submission`.

**Importante**: nenhum desses campos é usado para *inferir* a condição de
risco automaticamente — este protótipo não tem nenhuma fonte de dados
climáticos gridados acoplada a ele (isso é papel do AIGIS Agent). Eles são
metadados descritivos que identificam o território, a cultura e o momento
do ciclo produtivo a que a recomendação se refere. As condições de risco
continuam vindo de `--conditions` (indicadas manualmente) ou de
`from-indicators` (derivadas de números como o Índice de Severidade
Térmica). Quem quiser ligar `--lat`/`--lon` a um risco real precisa antes
gerar o mapa/estatística correspondente com o AIGIS Agent para aquele
ponto, e então informar a condição resultante aqui.

## Encadeando com o AIGIS Agent

O comando `from-indicators` traduz números que o **AIGIS Agent** já produz
— ou que você tenha de outra fonte — diretamente em condições de risco,
fechando o pipeline território → cenário climático → risco → prática:

```bash
python3 recommendation_agent.py from-indicators \
  --severity-index 8 \
  --aridity-index 0.35 \
  --territory "Semiárido SE-AL" \
  --out recomendacao.json
```

- `--severity-index`: Índice de Severidade Térmica (escala 2-9) calculado
  pelo AIGIS Agent (`combine_severity_index`). >=7 vira "temperatura
  extrema"; 5-6 vira "temperatura alta".
- `--aridity-index`: Índice de Aridez (P/ETP, classes UNCCD) — o mesmo tipo
  de indicador citado no AdaptaHorts para o Baixo São Francisco
  (0,55 → 0,38, de subúmido seco a semiárido). <0,20 vira "escassez
  hídrica extrema"; 0,20–0,65 vira "escassez hídrica alta".
- `--precip-anomaly-pct` e `--tmin`: heurísticas simples (não extraídas de
  um artigo específico) para excesso de chuva e frio/geada — ajuste os
  limiares em `condition_from_precip_anomaly`/`condition_from_tmin`
  conforme a região.

O `resultado.json` de `recommend` e `from-indicators` já traz um bloco
`adaptahorts_submission` formatado para o módulo "Proposição Automatizada
de Sistemas Resilientes" do formulário de contribuição do AdaptaHorts.

## Limitações conhecidas (protótipo)

- É um motor de regras explícitas, não um modelo estatístico ou de IA —
  a "automação" está em aplicar as regras e priorizar por benefício
  múltiplo de forma consistente e auditável, não em aprender novas regras
  a partir de dados.
- Os limiares numéricos de `derive_conditions` (Índice de Severidade
  Térmica, Índice de Aridez, anomalia de chuva, Tmin) são pontos de partida
  razoáveis, não valores calibrados e validados estatisticamente para
  hortaliças — ajuste-os com apoio de especialistas antes de usar em
  decisões reais.
- As condições e práticas "sugeridas" são exatamente isso — sugestões para
  revisão humana, não achados de um artigo publicado. Estão claramente
  marcadas (`suggested=True`) e podem ser removidas com `--core-only`.
- Não considera custo, escala de produção nem viabilidade econômica de cada
  prática — apenas o pareamento risco → prática.
