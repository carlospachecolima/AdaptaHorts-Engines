#!/usr/bin/env python3
"""
Recommendation Agent — Motor de Proposição Automatizada de Sistemas
Resilientes (protótipo)
============================================================================

Formaliza, em código, um motor de recomendação baseado em regras que liga
condições de risco climático (térmico e hídrico) a práticas agrícolas de
adaptação — o equivalente à etapa 5 do pipeline do AdaptaHorts,
"Proposição Automatizada de Sistemas Resilientes", hoje descrita na
plataforma como roteiro futuro: "IA + modelos + dados + conhecimento local,
gerando recomendações de sistemas produtivos adaptados a cada território."

Este é o terceiro motor da mesma família dos outros dois já formalizados
para o AdaptaHorts:

  - PFBCIA Agent: fenotipagem assistida por IA (alface, batata-doce).
  - AIGIS Agent: mapeamento de cenários climáticos e vulnerabilidade
    térmica (WorldClim/CMIP6 e INPE/ETA-HadGEM2-ES).
  - Recommendation Agent (este arquivo): a partir de uma condição de risco
    — ou dos próprios números que o AIGIS Agent produz (Índice de
    Severidade Térmica, Índice de Aridez, anomalia de chuva) — recomenda um
    conjunto de práticas agrícolas priorizadas.

REGRAS-BASE (fornecidas diretamente para este protótipo):

  temperatura extrema        -> cultivo em ambiente controlado
  temperatura alta           -> SPDH/NTVF, bioinsumos, SAF
  escassez hídrica extrema   -> cultivo hidropônico, reúso de água
  escassez hídrica alta      -> cultivo hidropônico, reúso de água,
                                 irrigação por gotejamento, manejo de
                                 irrigação, SPDH/NTVF, mulching plástico, SAF
  excesso de chuva           -> SPDH/NTVF, SAF, cultivo em ambiente protegido

Além dessas cinco, o módulo inclui um segundo conjunto de condições e
regras SUGERIDAS (marcadas explicitamente como tal, com `suggested=True`),
propostas por analogia com os riscos já discutidos nos artigos e na própria
página do AdaptaHorts (geada/frio, salinização no estuário do Baixo São
Francisco, pragas favorecidas por calor e umidade, erosão e baixa
fertilidade do solo). Elas ficam desligadas por padrão apenas na listagem
"core"; use `--include-suggested` (ligado por padrão no `recommend`) para
considerá-las, ou edite/remova o que não fizer sentido para o seu contexto
— este é um protótipo para validação humana, não uma lista fechada.

Princípios FAIR: como os demais agentes desta família, feito para ser
versionado e lido por outras pessoas — não só executado.
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


# ---------------------------------------------------------------------------
# Vocabulário: condições de risco e práticas de adaptação.
# ---------------------------------------------------------------------------

@dataclass
class RiskCondition:
    key: str
    label: str
    category: str          # "termico" | "hidrico" | "excesso_agua" | "solo" | "biotico"
    severity_rank: int      # 1 (baixo) .. 4 (extremo) — usado apenas para exibição
    description: str
    derivation_hint: str    # como estimar essa condição a partir de indicadores quantitativos
    suggested: bool = False  # False = condição fornecida originalmente; True = sugestão deste agente


@dataclass
class Practice:
    key: str
    label: str
    description: str
    adaptahorts_module: str   # etapa do pipeline do AdaptaHorts (ver módulos do ecossistema)
    evidence: str = ""         # referência/observação, quando disponível
    suggested: bool = False


CONDITIONS: dict[str, RiskCondition] = {
    "temperatura_extrema": RiskCondition(
        key="temperatura_extrema", label="Temperatura extrema", category="termico",
        severity_rank=4,
        description="Temperaturas muito acima da faixa ideal da cultura, com risco de dano direto ao tecido vegetal.",
        derivation_hint="Ex.: Índice de Severidade Térmica (IS, AIGIS Agent) em 7-9, ou Tmax projetada > 35°C na maior parte do ciclo.",
    ),
    "temperatura_alta": RiskCondition(
        key="temperatura_alta", label="Temperatura alta", category="termico",
        severity_rank=3,
        description="Temperaturas acima do ideal, com estresse térmico moderado a significativo mas sem dano agudo imediato.",
        derivation_hint="Ex.: Índice de Severidade Térmica (IS, AIGIS Agent) em 5-6.",
    ),
    "escassez_hidrica_extrema": RiskCondition(
        key="escassez_hidrica_extrema", label="Escassez hídrica extrema", category="hidrico",
        severity_rank=4,
        description="Disponibilidade hídrica insuficiente para manter a cultura em condições convencionais de sequeiro ou irrigação comum.",
        derivation_hint="Ex.: Índice de Aridez (P/ETP) < 0,20 (classes árido/hiperárido, UNCCD), ou vazão/reservatório abaixo do crítico.",
    ),
    "escassez_hidrica_alta": RiskCondition(
        key="escassez_hidrica_alta", label="Escassez hídrica alta", category="hidrico",
        severity_rank=3,
        description="Disponibilidade hídrica reduzida, exigindo uso mais eficiente da água mas ainda viável com manejo adequado.",
        derivation_hint="Ex.: Índice de Aridez (P/ETP) entre 0,20 e 0,65 (classes semiárido/subúmido seco, UNCCD).",
    ),
    "excesso_chuva": RiskCondition(
        key="excesso_chuva", label="Excesso de chuva", category="excesso_agua",
        severity_rank=3,
        description="Precipitação acima do normal, com risco de encharcamento, doenças fúngicas e perda de solo.",
        derivation_hint="Ex.: anomalia de precipitação projetada/observada >= +30% sobre a normal climatológica.",
    ),
    # --- condições sugeridas por este agente (não fornecidas originalmente) ---
    "geada_frio_extremo": RiskCondition(
        key="geada_frio_extremo", label="Geada / frio extremo", category="termico",
        severity_rank=4,
        description="Temperaturas muito abaixo do ideal, com risco de geada e dano por frio.",
        derivation_hint="Ex.: Tmin projetada/observada abaixo do limiar crítico da cultura por vários dias seguidos.",
        suggested=True,
    ),
    "salinizacao_solo_agua": RiskCondition(
        key="salinizacao_solo_agua", label="Salinização do solo ou da água", category="hidrico",
        severity_rank=3,
        description="Qualidade da água ou do solo comprometida por sais, comum em regiões costeiras/estuarinas sob intrusão salina.",
        derivation_hint="Ex.: condutividade elétrica da água/solo acima do limiar da cultura; relevante no baixo curso de rios com intrusão salina.",
        suggested=True,
    ),
    "pragas_doencas_calor_umidade": RiskCondition(
        key="pragas_doencas_calor_umidade", label="Pressão de pragas/doenças favorecida por calor e umidade", category="biotico",
        severity_rank=2,
        description="Combinação de temperatura e umidade que favorece a emergência ou intensificação de fitopatógenos.",
        derivation_hint="Ex.: dias com Tmed entre 22-26°C e alta umidade/CO2, faixa associada a maior pressão fúngica em alface.",
        suggested=True,
    ),
    "degradacao_erosao_solo": RiskCondition(
        key="degradacao_erosao_solo", label="Degradação / erosão do solo", category="solo",
        severity_rank=2,
        description="Perda de solo e de estrutura física associada a chuvas intensas, preparo convencional ou baixa cobertura vegetal.",
        derivation_hint="Ex.: histórico de chuvas erosivas + solo descoberto por longos períodos do ciclo.",
        suggested=True,
    ),
    "baixa_fertilidade_solo": RiskCondition(
        key="baixa_fertilidade_solo", label="Baixa fertilidade do solo", category="solo",
        severity_rank=2,
        description="Solo com baixa disponibilidade de nutrientes e matéria orgânica, limitando a resiliência da cultura a outros estresses.",
        derivation_hint="Ex.: análise de solo com baixo teor de matéria orgânica/CTC.",
        suggested=True,
    ),
}


PRACTICES: dict[str, Practice] = {
    "cultivo_ambiente_controlado": Practice(
        key="cultivo_ambiente_controlado", label="Cultivo em ambiente controlado",
        description="Estufa ou câmara com climatização ativa (resfriamento/aquecimento) para desacoplar a cultura da temperatura externa.",
        adaptahorts_module="boas-praticas",
    ),
    "spdh_ntvf": Practice(
        key="spdh_ntvf", label="Sistema de Plantio Direto de Hortaliças (SPDH/NTVF)",
        description="Plantio direto sobre palhada/cobertura morta, reduzindo temperatura do solo, evaporação e erosão.",
        adaptahorts_module="boas-praticas",
        evidence="AdaptaHorts reporta -4,26°C de temperatura do solo e até 25% de economia de água de irrigação com o NTVF.",
    ),
    "bioinsumos": Practice(
        key="bioinsumos", label="Bioinsumos",
        description="Biofertilizantes e bioinsumos que fortalecem a planta frente a estresses abióticos e bióticos.",
        adaptahorts_module="boas-praticas",
        evidence="Fontenelle et al. (2026) observaram alface tratada com biofertilizante Hortbio vencendo em 4 de 5 pares sob estresse térmico, frente à adubação mineral.",
    ),
    "saf": Practice(
        key="saf", label="Sistemas Agroflorestais (SAF)",
        description="Consórcio com espécies arbóreas/arbustivas, gerando sombreamento, quebra-vento, ciclagem de nutrientes e diversificação.",
        adaptahorts_module="boas-praticas",
    ),
    "cultivo_hidroponico": Practice(
        key="cultivo_hidroponico", label="Cultivo hidropônico",
        description="Sistema sem solo com recirculação de solução nutritiva, com uso da água muito mais eficiente que o cultivo convencional.",
        adaptahorts_module="boas-praticas",
    ),
    "reuso_agua": Practice(
        key="reuso_agua", label="Reúso de água (ReAqua)",
        description="Reaproveitamento de água (ex.: efluentes tratados, água de drenagem) para reduzir a dependência de fontes primárias.",
        adaptahorts_module="boas-praticas",
    ),
    "irrigacao_gotejamento": Practice(
        key="irrigacao_gotejamento", label="Irrigação por gotejamento",
        description="Aplicação localizada de água diretamente na zona radicular, reduzindo perdas por evaporação e escoamento.",
        adaptahorts_module="boas-praticas",
    ),
    "manejo_irrigacao": Practice(
        key="manejo_irrigacao", label="Manejo de irrigação",
        description="Programação da irrigação por turno de rega, tensiômetro/sensor de umidade ou balanço hídrico, evitando déficit e desperdício.",
        adaptahorts_module="boas-praticas",
    ),
    "mulching_plastico": Practice(
        key="mulching_plastico", label="Mulching plástico",
        description="Cobertura plástica do solo que reduz evaporação, controla plantas espontâneas e modula a temperatura do solo.",
        adaptahorts_module="boas-praticas",
    ),
    "cultivo_ambiente_protegido": Practice(
        key="cultivo_ambiente_protegido", label="Cultivo em ambiente protegido",
        description="Estufa ou túnel sem climatização ativa, principalmente para proteger a cultura do excesso de chuva/granizo/vento.",
        adaptahorts_module="boas-praticas",
    ),
    # --- práticas associadas apenas às condições sugeridas ---
    "cultivares_tolerantes_frio": Practice(
        key="cultivares_tolerantes_frio", label="Cultivares tolerantes ao frio",
        description="Escolha de material genético mais tolerante a baixas temperaturas para reduzir o risco de dano por frio/geada.",
        adaptahorts_module="boas-praticas", suggested=True,
    ),
    "drenagem_manejo_salinidade": Practice(
        key="drenagem_manejo_salinidade", label="Manejo de drenagem e salinidade",
        description="Sistemas de drenagem e correção/lavagem de sais para manter o solo e a água dentro de limites aceitáveis à cultura.",
        adaptahorts_module="boas-praticas", suggested=True,
    ),
    "manejo_integrado_pragas": Practice(
        key="manejo_integrado_pragas", label="Manejo integrado de pragas e doenças",
        description="Monitoramento, controle biológico e rotação de culturas para reduzir a pressão de pragas/doenças favorecidas pelo clima.",
        adaptahorts_module="boas-praticas", suggested=True,
    ),
    "adubacao_organica_verde": Practice(
        key="adubacao_organica_verde", label="Adubação orgânica / verde",
        description="Incorporação de matéria orgânica e adubos verdes para recompor fertilidade e estrutura do solo.",
        adaptahorts_module="boas-praticas", suggested=True,
    ),
}


# ---------------------------------------------------------------------------
# Base de regras: condição de risco -> práticas recomendadas.
# ---------------------------------------------------------------------------

CORE_RULES: dict[str, list[str]] = {
    "temperatura_extrema": ["cultivo_ambiente_controlado"],
    "temperatura_alta": ["spdh_ntvf", "bioinsumos", "saf"],
    "escassez_hidrica_extrema": ["cultivo_hidroponico", "reuso_agua"],
    "escassez_hidrica_alta": [
        "cultivo_hidroponico", "reuso_agua", "irrigacao_gotejamento",
        "manejo_irrigacao", "spdh_ntvf", "mulching_plastico", "saf",
    ],
    "excesso_chuva": ["spdh_ntvf", "saf", "cultivo_ambiente_protegido"],
}

SUGGESTED_RULES: dict[str, list[str]] = {
    "geada_frio_extremo": [
        "cultivo_ambiente_protegido", "cultivares_tolerantes_frio", "mulching_plastico",
    ],
    "salinizacao_solo_agua": ["reuso_agua", "drenagem_manejo_salinidade", "saf"],
    "pragas_doencas_calor_umidade": ["manejo_integrado_pragas", "bioinsumos", "saf"],
    "degradacao_erosao_solo": ["spdh_ntvf", "saf", "adubacao_organica_verde"],
    "baixa_fertilidade_solo": ["bioinsumos", "adubacao_organica_verde", "saf"],
}


def all_rules(include_suggested: bool = True) -> dict[str, list[str]]:
    rules = dict(CORE_RULES)
    if include_suggested:
        rules.update(SUGGESTED_RULES)
    return rules


# ---------------------------------------------------------------------------
# Motor de recomendação: recebe uma lista de condições de risco já
# identificadas (ex.: pelo AIGIS Agent, por leitura de campo, ou por
# conhecimento local) e devolve as práticas recomendadas, priorizadas pelo
# número de condições simultâneas que cada prática endereça — práticas de
# "múltiplo benefício" (SAF, SPDH/NTVF, bioinsumos) tendem a subir no
# ranking quando vários riscos coincidem no mesmo território.
# ---------------------------------------------------------------------------

def recommend(condition_keys: list[str], include_suggested: bool = True) -> dict[str, Any]:
    rules = all_rules(include_suggested)
    unknown = [c for c in condition_keys if c not in CONDITIONS]
    if unknown:
        raise ValueError(f"Condição(ões) desconhecida(s): {unknown}. "
                          f"Use o comando 'list' para ver as condições disponíveis.")

    per_condition = {}
    practice_hits: dict[str, list[str]] = {}
    for ck in condition_keys:
        practice_keys = rules.get(ck, [])
        per_condition[ck] = {
            "condition": CONDITIONS[ck].label,
            "suggested_condition": CONDITIONS[ck].suggested,
            "practices": practice_keys,
        }
        for pk in practice_keys:
            practice_hits.setdefault(pk, []).append(ck)

    ranked = sorted(
        practice_hits.items(),
        key=lambda kv: (-len(kv[1]), PRACTICES[kv[0]].label),
    )
    consolidated = [
        {
            "practice": PRACTICES[pk].label,
            "key": pk,
            "addresses": [CONDITIONS[c].label for c in conds],
            "co_benefit_count": len(conds),
            "description": PRACTICES[pk].description,
            "evidence": PRACTICES[pk].evidence,
            "suggested_practice": PRACTICES[pk].suggested,
        }
        for pk, conds in ranked
    ]

    return {
        "input_conditions": condition_keys,
        "include_suggested_rules": include_suggested,
        "per_condition": per_condition,
        "consolidated_recommendation": consolidated,
    }


# ---------------------------------------------------------------------------
# Pontes com o AIGIS Agent: derivam condições de risco a partir de
# indicadores quantitativos já produzidos pelo motor de mapeamento, para que
# os três agentes (fenotipagem, mapeamento, recomendação) possam ser
# encadeados em um único pipeline território -> risco -> prática.
# ---------------------------------------------------------------------------

def condition_from_severity_index(is_value: int) -> str | None:
    """Índice de Severidade Térmica (IS, escala 2-9, ver AIGIS Agent /
    Lima et al., 2025) -> condição de risco térmico."""
    if is_value is None:
        return None
    if is_value >= 7:
        return "temperatura_extrema"
    if is_value >= 5:
        return "temperatura_alta"
    return None


def condition_from_aridity_index(ai_value: float) -> str | None:
    """Índice de Aridez (P/ETP, classes UNCCD, citado no AdaptaHorts para o
    Baixo São Francisco) -> condição de risco hídrico."""
    if ai_value is None:
        return None
    if ai_value < 0.20:
        return "escassez_hidrica_extrema"
    if ai_value < 0.65:
        return "escassez_hidrica_alta"
    return None


def condition_from_precip_anomaly(pct: float) -> str | None:
    """Heurística simples (não extraída de um artigo específico): anomalia
    percentual de precipitação frente à normal climatológica -> excesso de
    chuva. Ajuste o limiar (`threshold_pct`) para a região de interesse."""
    if pct is None:
        return None
    if pct >= 30.0:
        return "excesso_chuva"
    return None


def condition_from_tmin(tmin_c: float, frost_threshold_c: float = 5.0) -> str | None:
    """Heurística simples: temperatura mínima abaixo de um limiar de risco
    de frio/geada -> condição sugerida 'geada_frio_extremo'."""
    if tmin_c is None:
        return None
    if tmin_c <= frost_threshold_c:
        return "geada_frio_extremo"
    return None


def derive_conditions(severity_index: int | None = None,
                       aridity_index: float | None = None,
                       precip_anomaly_pct: float | None = None,
                       tmin_c: float | None = None) -> list[str]:
    derived = [
        condition_from_severity_index(severity_index),
        condition_from_aridity_index(aridity_index),
        condition_from_precip_anomaly(precip_anomaly_pct),
        condition_from_tmin(tmin_c),
    ]
    return [c for c in derived if c is not None]


# ---------------------------------------------------------------------------
# Contexto da consulta: localização, cultura(s), fase fenológica e horizonte
# temporal. Este agente NÃO deriva condições de risco a partir de latitude/
# longitude — não há, neste protótipo, nenhuma fonte de dados climáticos
# gridados acoplada a ele (isso é papel do AIGIS Agent). Os campos abaixo são
# metadados descritivos: identificam o território, a cultura e o momento do
# ciclo produtivo a que a recomendação se refere, e alimentam o título/
# resumo do bloco de submissão para o AdaptaHorts. Quem estiver de posse de
# mapas do AIGIS Agent (ou de outra fonte) ainda precisa informar as
# condições de risco via `--conditions` / `--severity-index` / etc.
# ---------------------------------------------------------------------------

PHENOLOGICAL_STAGES: dict[str, str] = {
    "implantacao": "Implantação / muda",
    "vegetativo": "Vegetativo",
    "floracao": "Florescimento",
    "frutificacao_enchimento": "Frutificação / enchimento",
    "colheita_pos_colheita": "Colheita / pós-colheita",
}

PERIODS: dict[str, str] = {
    "presente": "Presente (observado)",
    "curto_prazo": "Curto prazo (até 2040)",
    "medio_prazo": "Médio prazo (2041–2070)",
    "longo_prazo": "Longo prazo (2071–2100)",
}


@dataclass
class QueryContext:
    territory: str = "território não informado"
    lat: float | None = None
    lon: float | None = None
    crops: list[str] = field(default_factory=list)
    phenological_stage: str | None = None   # chave de PHENOLOGICAL_STAGES
    period: str | None = None                # chave de PERIODS

    def location_label(self) -> str | None:
        if self.lat is None or self.lon is None:
            return None
        return f"{self.lat:.4f}, {self.lon:.4f}"

    def crops_label(self) -> str | None:
        return ", ".join(self.crops) if self.crops else None

    def phenological_label(self) -> str | None:
        if not self.phenological_stage:
            return None
        return PHENOLOGICAL_STAGES.get(self.phenological_stage, self.phenological_stage)

    def period_label(self) -> str | None:
        if not self.period:
            return None
        return PERIODS.get(self.period, self.period)

    def as_dict(self) -> dict[str, Any]:
        return {
            "territory": self.territory,
            "lat": self.lat,
            "lon": self.lon,
            "location_label": self.location_label(),
            "crops": self.crops,
            "phenological_stage": self.phenological_stage,
            "phenological_label": self.phenological_label(),
            "period": self.period,
            "period_label": self.period_label(),
        }


# ---------------------------------------------------------------------------
# Bloco de submissão formatado para o AdaptaHorts (módulo 5 do pipeline:
# "Proposição Automatizada de Sistemas Resilientes").
# ---------------------------------------------------------------------------

def build_adaptahorts_submission(result: dict[str, Any], context: QueryContext) -> dict:
    n_conditions = len(result["input_conditions"])
    n_practices = len(result["consolidated_recommendation"])
    top = result["consolidated_recommendation"][:3]
    top_labels = ", ".join(p["practice"] for p in top)

    descriptors = []
    if context.crops_label():
        descriptors.append(f"cultura(s): {context.crops_label()}")
    if context.phenological_label():
        descriptors.append(f"fase fenológica: {context.phenological_label()}")
    if context.period_label():
        descriptors.append(f"período: {context.period_label()}")
    if context.location_label():
        descriptors.append(f"coordenadas: {context.location_label()}")
    descriptor_text = f" ({'; '.join(descriptors)})" if descriptors else ""

    summary = (
        f"Recomendação automatizada de sistemas produtivos resilientes para "
        f"{context.territory}{descriptor_text}, a partir de {n_conditions} "
        f"condição(ões) de risco identificada(s). Práticas priorizadas por "
        f"benefício múltiplo: {top_labels}."
    )
    metrics = [
        {"k": "condições de risco consideradas", "v": str(n_conditions)},
        {"k": "práticas recomendadas", "v": str(n_practices)},
    ]
    if top:
        metrics.append({"k": "prática de maior benefício múltiplo", "v": top[0]["practice"]})
    if context.crops_label():
        metrics.append({"k": "cultura(s)", "v": context.crops_label()})
    if context.phenological_label():
        metrics.append({"k": "fase fenológica", "v": context.phenological_label()})
    if context.period_label():
        metrics.append({"k": "período", "v": context.period_label()})
    if context.location_label():
        metrics.append({"k": "coordenadas (lat, lon)", "v": context.location_label()})

    return {
        "title": f"Proposição automatizada de sistemas resilientes — {context.territory}",
        "authors": "(preencher — pesquisador(a) responsável pela análise)",
        "venue": "AdaptaHorts — contribuição via Recommendation Agent",
        "module": "proposicao",
        "doi": "",
        "summary": summary,
        "metrics": metrics,
    }


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def cmd_list(args: argparse.Namespace) -> int:
    payload = {
        "conditions": [
            {"key": c.key, "label": c.label, "category": c.category,
             "severity_rank": c.severity_rank, "description": c.description,
             "derivation_hint": c.derivation_hint, "suggested": c.suggested}
            for c in CONDITIONS.values()
        ],
        "practices": [
            {"key": p.key, "label": p.label, "description": p.description,
             "adaptahorts_module": p.adaptahorts_module, "evidence": p.evidence,
             "suggested": p.suggested}
            for p in PRACTICES.values()
        ],
    }
    _emit(payload, args.out)
    return 0


def _context_from_args(args: argparse.Namespace) -> QueryContext:
    if args.phenological_stage and args.phenological_stage not in PHENOLOGICAL_STAGES:
        raise ValueError(f"Fase fenológica desconhecida: '{args.phenological_stage}'. "
                          f"Opções: {list(PHENOLOGICAL_STAGES)}")
    if args.period and args.period not in PERIODS:
        raise ValueError(f"Período desconhecido: '{args.period}'. Opções: {list(PERIODS)}")
    return QueryContext(
        territory=args.territory,
        lat=args.lat,
        lon=args.lon,
        crops=list(args.crops) if args.crops else [],
        phenological_stage=args.phenological_stage,
        period=args.period,
    )


def cmd_recommend(args: argparse.Namespace) -> int:
    try:
        context = _context_from_args(args)
        result = recommend(args.conditions, include_suggested=not args.core_only)
    except ValueError as e:
        print(f"Erro: {e}", file=sys.stderr)
        return 1
    result["context"] = context.as_dict()
    result["territory"] = context.territory
    result["generated_at"] = datetime.now(timezone.utc).isoformat()
    result["adaptahorts_submission"] = build_adaptahorts_submission(result, context)
    _emit(result, args.out)
    return 0


def cmd_from_indicators(args: argparse.Namespace) -> int:
    try:
        context = _context_from_args(args)
    except ValueError as e:
        print(f"Erro: {e}", file=sys.stderr)
        return 1

    conditions = derive_conditions(
        severity_index=args.severity_index,
        aridity_index=args.aridity_index,
        precip_anomaly_pct=args.precip_anomaly_pct,
        tmin_c=args.tmin,
    )
    if not conditions:
        print("Nenhuma condição de risco foi derivada dos indicadores informados "
              "(valores dentro da faixa considerada segura). Nada a recomendar.",
              file=sys.stderr)
        payload = {
            "context": context.as_dict(),
            "territory": context.territory,
            "derived_conditions": [],
            "consolidated_recommendation": [],
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }
        _emit(payload, args.out)
        return 0

    result = recommend(conditions, include_suggested=not args.core_only)
    result["derived_conditions"] = conditions
    result["context"] = context.as_dict()
    result["territory"] = context.territory
    result["generated_at"] = datetime.now(timezone.utc).isoformat()
    result["adaptahorts_submission"] = build_adaptahorts_submission(result, context)
    _emit(result, args.out)
    return 0


def _emit(payload: dict, out: Path | None) -> None:
    text = json.dumps(payload, ensure_ascii=False, indent=2, default=str)
    if out:
        out.write_text(text, encoding="utf-8")
        print(f"Resultado salvo em {out}", file=sys.stderr)
    else:
        print(text)


def _add_context_args(p: argparse.ArgumentParser) -> None:
    """Argumentos de contexto da consulta, comuns a `recommend` e
    `from-indicators`: localização, cultura(s), fase fenológica e período.
    Ver o comentário em cima de `QueryContext` — nenhum deles é usado para
    inferir risco automaticamente; são metadados descritivos."""
    p.add_argument("--territory", type=str, default="território não informado",
                    help="Nome/descrição do território (ex.: 'Baixo São Francisco (SE-AL)').")
    p.add_argument("--lat", type=float, default=None, help="Latitude do território (opcional).")
    p.add_argument("--lon", type=float, default=None, help="Longitude do território (opcional).")
    p.add_argument("--crops", nargs="*", default=None,
                    help="Cultura(s) produzida(s) no território (opcional). Ex.: --crops alface batata-doce")
    p.add_argument("--phenological-stage", choices=sorted(PHENOLOGICAL_STAGES), default=None,
                    help="Fase fenológica predominante no momento da consulta (opcional).")
    p.add_argument("--period", choices=sorted(PERIODS), default=None,
                    help="Horizonte temporal da consulta: presente ou um período futuro projetado (opcional).")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Recommendation Agent — motor de proposição automatizada de "
            "sistemas resilientes (etapa 5 do pipeline do AdaptaHorts), "
            "ligando condições de risco climático a práticas de adaptação."
        )
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_list = sub.add_parser("list", help="Lista as condições de risco e práticas conhecidas.")
    p_list.add_argument("--out", type=Path, default=None)
    p_list.set_defaults(func=cmd_list)

    p_rec = sub.add_parser("recommend", help="Recomenda práticas a partir de condições de risco já identificadas.")
    p_rec.add_argument("--conditions", nargs="+", required=True,
                        help="Chaves das condições de risco (ver 'list'). Ex.: temperatura_alta escassez_hidrica_alta")
    _add_context_args(p_rec)
    p_rec.add_argument("--core-only", action="store_true",
                        help="Considera apenas as 5 regras originais, ignorando as condições/práticas sugeridas por este agente.")
    p_rec.add_argument("--out", type=Path, default=None)
    p_rec.set_defaults(func=cmd_recommend)

    p_ind = sub.add_parser(
        "from-indicators",
        help="Deriva condições de risco a partir de indicadores quantitativos (ex.: saída do AIGIS Agent) e recomenda práticas.",
    )
    p_ind.add_argument("--severity-index", type=int, default=None,
                        help="Índice de Severidade Térmica (2-9), do AIGIS Agent.")
    p_ind.add_argument("--aridity-index", type=float, default=None,
                        help="Índice de Aridez (P/ETP).")
    p_ind.add_argument("--precip-anomaly-pct", type=float, default=None,
                        help="Anomalia percentual de precipitação frente à normal climatológica.")
    p_ind.add_argument("--tmin", type=float, default=None,
                        help="Temperatura mínima (°C), para risco de frio/geada (condição sugerida).")
    _add_context_args(p_ind)
    p_ind.add_argument("--core-only", action="store_true")
    p_ind.add_argument("--out", type=Path, default=None)
    p_ind.set_defaults(func=cmd_from_indicators)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
